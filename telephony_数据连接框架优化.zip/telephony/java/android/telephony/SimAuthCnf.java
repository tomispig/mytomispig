/******************************************************************************
 * *(C) Copyright 2008 ZTE Ltd.
 * * All Rights Reserved
 * ******************************************************************************/

/* code update
===============================================================================
When              Who            Why
-----------  ----------   ---------------------------------
2010-10-29   Ganhuiliang     Create this file for USIM auth
===============================================================================
*/

package android.telephony;

import android.os.Bundle;

public class SimAuthCnf {
    public String sres;
    public String kc;

    public SimAuthCnf() {
        this.sres = null;
        this.kc = null;
    }

    public SimAuthCnf(Bundle bundle) {
        this.sres = bundle.getString("sres");
        this.kc = bundle.getString("kc");
    }

    public void fillInNotifierBundle(Bundle m) {
        m.putString("sres", sres);
        m.putString("kc", kc);
    }
    
    public String toString() {
        return super.toString() +
            " sres: " + sres +
            " kc: " + kc;
    }
}

