package android.telephony;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.database.Cursor;
import android.provider.MediaStore;

import java.io.FileDescriptor;
import java.io.IOException;

import java.lang.ref.WeakReference;

/**
 * The VTManager class is used for operating video telephony engine
 * video telephony is a 3G specific feature, the APIs only runable 
 * for 3G compatilbe terminals.
 * {@hide}
 */
public class VTManager
{
    private final static String TAG = "VTManager";
    private static final int    USER_INPUT_LENGTH = 100;
    /**
     * Defines  Local config const
     */

    /**
     * Defines the video source. These constants are used with 
     * {@link VTManager#setVideoSource(int)}.
     */

    public final class VideoSource {
        /* Do not change these values without updating their counterparts
        */
        private VideoSource() {}
        public static final int DEFAULT = 0;
        /** Camera video source */
        public static final int CAMERA_MAIN = 1;
        public static final int CAMERA_SECONDARY = 2;
        public static final int CAMERA_NONE = 3;
        public static final int CAMERA_FILE = 4;
        public static final int UNKNOWN = 5;

    }


    /**
     * Defines incomming data type.
     */
    public final class IncommingDataType {
        public static final int DEFAULT = 0;
        public static final int PICTURE= 1;
        public static final int MESSAGE= 2;
        public static final int RAWDATA= 3;
        public static final int USERINPUT= 4;
    }

    /**
     * Defines video telephony msg type. 
     */
    public final class EventType {
        public static final int EVENT_UNKNOWN =0;
        public static final int EVENT_INFO=1;
        public static final int EVENT_ERROR =2;
        public static final int EVENT_CMDCOMP =3;
    }

    /**
     * Defines video telephony error type. 
     * App must handle this error message.
     */
    public final class ErrorType {
        public static final int UNKNOWN=       0;
        public static final int INVALID_STATE =     1;
        public static final int INVALID_DEVICE =    2;
        public static final int INVALID_SURFACE =   3;
        public static final int DEVICE_OPEN_FAIL =  4;
        public static final int CONNECTION_FAIL =   5;
        public static final int RECORDING_FAIL =    6;
        public static final int OPENING_CAMERA_FAIL =    7;
        public static final int CLOSING_CAMERA_FAIL =    8;
        public static final int REPLACING_CAMERA_FAIL =    9;

    }

    public final class RecordingType {
        public static final int LOCAL_REMOTE_AUDIO 		=       0;
        public static final int REMOTE_AUDIO 			=       1;
        public static final int REMOTE_VIDEO 			=       2;
        public static final int LOCAL_REMOTE_AUDIO_REMOTE_VIDEO	=       3;
    }

    public final class AudioEncoderType {
        public static final int AUDIO_ENCODER_AMR_NB	=       0;
    }

    public final class VideoEncoderType {
        public static final int VIDEO_ENCODER_NONE	=       -1;
    }

    public final class OutputFormat {
        public static final int OUTPUT_FORMAT_AMR_NB	=       0;
    }


    /**
     * Defines video telephony information message type. App can ignore this. 
     */
    public final class InfoType {
        public static final int UNKNOWN=       0;
        public static final int CONNECTED=     1;
        public static final int DISCONNECTED=  2;
        public static final int REMOTE_AUDIO_OPENED=       3;
        public static final int REMOTE_VIDEO_OPENED=       4;
        public static final int USER_INPUT_INCOMMING=       5;
        public static final int DISCONNECT_REQ=  6;
        public static final int SIGNAL_WEAK =  7;
        public static final int REMOTE_CAMERA_OPENED =  8;
        public static final int REMOTE_CAMERA_CLOSED =  9;
    }

    /**
     * Defines video telephony information message type. App can ignore this. 
     */
    public final class CmdType {
        public static final int INIT =       0;
        public static final int CONNECT=       1;
        public static final int DISCONNECT=       2;
        public static final int RELEASE=       3;
    }

    private int mNativeContext; // accessed by native methods
    private int mListenerContext; // accessed by native methods
    private Surface mLocalSurface; // accessed by native methods
    private Surface mRemoteSurface; // accessed by native methods
    private SurfaceHolder mLocalSurfaceHolder;
    private SurfaceHolder mRemoteSurfaceHolder;
    private EventHandler mEventHandler;

    static {
        System.loadLibrary("vtengine_jni");
        native_init();
    }

    /**
     * Default constructor. 
     * When done with the VTManager, you should call  {@link #release()},
     * to free the resources. If not released, next MediaPlayer instances may
     * result in an exception.
     */

    public VTManager() 
    {
        mOnInfoListener=null;
        mOnErrorListener=null;
        mLocalSurface=null;
        mRemoteSurface=null;

        Looper looper;
        if ((looper = Looper.myLooper()) != null) {
            mEventHandler = new EventHandler(this, looper);
        } else if ((looper = Looper.getMainLooper()) != null) {
            mEventHandler = new EventHandler(this, looper);
        } else {
            mEventHandler = null;
        }

        //weak reference 
        native_setup(new WeakReference<VTManager>(this));
    }

    @Override
    protected void finalize() { native_finalize(); }

    /**
     * Sets the Surface to use for displaying the video portion of remote.
     * call this before connect() . Set a null as surface will 
     * result in no display
     * @param sh SurfaceHolder to use for video display
     * 
     */
    public void setLocalDisplay(SurfaceHolder sh)
    {
        mLocalSurfaceHolder = sh;
	if(sh == null)
		mLocalSurface = null;
	else
		mLocalSurface = sh.getSurface();
        setVTLocalSurface();
        Log.v(TAG,"setLocalDisplay Succeed. " );
    }

    

    /**
     * Sets the Surface to use for displaying the video portion of local.
     * call this before connect() or connectAsync(). Set a null as surface will 
     * result in no display
     * @param sh SurfaceHolder to use for video display
     * 
     */

    public void setRemoteDisplay(SurfaceHolder sh)
    {
        mRemoteSurfaceHolder = sh;
	if(sh == null)
		mRemoteSurface = null;
	else
		mRemoteSurface = sh.getSurface();
        setVTRemoteSurface();
        Log.v(TAG,"setRemoteDisplay Succeed." );
    }

    private native void setVTLocalSurface();

    private native void setVTRemoteSurface();

    public native void _init();

    /**
     * connect remote side, asynchronously. Call this after
     * setVideoTelephonyDevice() or disconnect(), and before any other method that might
     * throw IllegalStateException in this class.
     * 
     * After setting the telephony device,auido source ,video source and display surface, you need to
     * call connect(). connect() will blocks until video telephony connection is ready.
     * if local surface is set,view finder will be started.
     * 
     * @throws IllegalStateException if it is called
     * in an order other than the one specified above
     */
    public void connect()
    {
	_init();
    }
    private native void _connect() throws IllegalStateException;

    /**
     * disconnect thelephony call. 
     * @throws IllegalStateException if it is called
     * in an order other than the one specified above
     */
    public void disconnect()
    {
	_disconnect();
    }

    public native void _disconnect() throws IllegalStateException ;


    /**
     * Releases resources associated with this VTManager object.
     * It is considered good practice to call this method when you're
     * done using the VTManager. 
     */
    public native void _release() ;

    /**
     * Gets the volume of remote voice.
     * This API is recommended for get the output volume of remote audio streams
     * within an application.
     * @return volume scalar (0-100)
     */
    public native int getVolume();


    /**
     * Sets the volume of remote voice.
     * This API is recommended for balancing the output of remote audio streams
     * within an application.
     * @param Volume  volume scalar (0-100)
     */
    public native void setVolume(int Volume);

    /**
     * Get the Mute status of the Local voice.
     * This API is recommended for get the mute status of the input audio
     * within an application.
     * @return true for mute and false for unmute
     */
    public native boolean getMute();

    /**
     * Mute the Local voice.
     * This API is recommended for mute the input audio
     * within an application.
     * calling this method will cause the far end can not hear your voice
     * @param Mute  true for mute and false for unmute
     */
    public native void setMute(boolean Mute);

    /**
     * Get the Mute status of the remote voice.
     * This API is recommended for get the mute status of the output audio
     * within an application.
     * @return true for mute and false for unmute
     */
    public native boolean getRemoteMute();


    /**
     * Mute the Remote voice.
     * This API is recommended for mute the output audio
     * within an application.
     * calling this method will cause you can not hear the far end voice
     * @param Mute  true for mute and false for unmute
     */
    public native void setRemoteMute(boolean Mute);

    /**
     * Sets the video source to be used for VT.  If this method is not
     * called, default video source is used. this method should be called
     * after setLocalDisplay()
     * 
     * @see VideoSource
     * @throws IllegalStateException if it is called after start
     */ 

    public native void setVideoSource(int vsource, String path);

    /**
     * Sets the camera parameter for VT. 
     * 
     * @param key key name for the parameter 
     *
     * @param value the string value of the parameter
     *
     * @throws IllegalStateException if it is called after start
     */ 

    public native void setCameraParameter(String key, String value);

    /**
     * Send user input keyboard to the peer terminal.
     *
     * @param user_input user input string, which will be wrapped by H.245
     *                   UserInputIndication message and be sent to the peer.
     *                   Notes: the length of user_input should not more than 100.
     *                   otherwise, the strings that after 100 will be dicarded.
     * @throws IllegalStateException if it is called before start 
     */
    public void sendUserInput(String user_input) throws IllegalStateException
    {
        // if UserInput is NULL or length is equal 0, return directly.
        if (user_input == null || user_input.trim()=="")
        {
            return;
        }
        // Insure the UserInput max length is not more than 100.
        if (user_input.length() > USER_INPUT_LENGTH-1)
        {
            String subStr = user_input.substring(0,USER_INPUT_LENGTH-1);
            _sendUserInput(subStr);
        }
        else
        {
            _sendUserInput(user_input);
        }
        return;
    }
    private native void _sendUserInput(String user_input);


    /**
     * Start the VT recording with the specified parameters.
     *
     * @param recordingType recording type, which is a value of RecordingType
     * @param filePath the place where the recorded data is stored
     * @param audioEncoder audio Encoder type, which is a value of AudioEncoderType
     * @param videoEncoder video Encoder type, which is a value of VideoEncoderType
     * @param outputFormat the format of the output file, which is a value of OutputFormat
     *
     * @return 0 means success to start, -1 means fail to start
     */

    public int startRecording(int recordingType, String filePath, int audioEncoder, int videoEncoder, int outputFormat)
    {
	if(recordingType != RecordingType.LOCAL_REMOTE_AUDIO) //currently, we just support one type
		return -1;

	if(audioEncoder != AudioEncoderType.AUDIO_ENCODER_AMR_NB) //currently, we just support one type
		return -1;

	if(videoEncoder != VideoEncoderType.VIDEO_ENCODER_NONE) //currently, we do'nt support video encoder
		return -1;

	if(outputFormat != OutputFormat.OUTPUT_FORMAT_AMR_NB) //currently, we just support one type
		return -1;

	return _startRecording(recordingType,filePath,audioEncoder,videoEncoder,outputFormat);
    }

    private native int _startRecording(int recordingType, String filePath, int audioEncoder, int videoEncoder, int outputFormat);

    /**
     * Stop the VT recording
     *
     * @return 0 means success to start, -1 means fail to start
     */

    public int stopRecording()
    {
	return _stopRecording();
    }

    private native int _stopRecording();

    /**
     * Interface definition for a callback to be invoked when vt engine
     * report an error.
     */ 
    public interface OnErrorListener
    {
        boolean onError(VTManager vtm, int what, int extra);
    }

    private OnErrorListener mOnErrorListener;

    /**
     * Register OnErrorListener callback
     * @param l the callback that will be run
     */
    public void setOnErrorListener(OnErrorListener l)
    {
        mOnErrorListener=l;

    }

    /**
     * Interface definition for a callback to be invoked when vt engine
     * report an info event.
     */ 
    public interface OnInfoListener
    {
        boolean onInfo(VTManager vtm, int what, int extra, Object obj);
    }
    private OnInfoListener mOnInfoListener;
    /**
     * Register OnInfoListener callback
     * @param l the callback that will be run
     */
    public void setOnInfoListener(OnInfoListener l)
    {
        mOnInfoListener=l;

    }

    /**
     * Interface definition for a callback to be invoked when vt engine
     * command completed.
     */ 
    public interface OnCmdCompListener
    {
        boolean onCmdComp(VTManager vtm, int what, int extra);
    }
    private OnCmdCompListener mOnCmdCompListener;
    /**
     * Register OnCmdCompListener callback
     * @param l the callback that will be run
     */
    public void setOnCmdCompListener(OnCmdCompListener l)
    {
        mOnCmdCompListener=l;

    }

    /**
     * Called from native code when an interesting event happens.  This method
     * just uses the EventHandler system to post the event back to the main app thread.
     * We use a weak reference to the original VTManager object so that the native
     * code is safe from the Java object disappearing from underneath it.  (This is
     * the cookie passed to native_setup().)
     */
    private static void postEventFromNative(Object vtmanager_ref,
                                            int what, int arg1, int arg2, String str)
    {
        VTManager vtm = (VTManager)((WeakReference)vtmanager_ref).get();
        if (vtm == null) {
            return;
        }

        if (vtm.mEventHandler != null) {
            Message m = vtm.mEventHandler.obtainMessage(what, arg1, arg2, str);
            vtm.mEventHandler.sendMessage(m);
        }
    }

    private class EventHandler extends Handler
    {
        private VTManager mVTM;

        public EventHandler(VTManager vtm, Looper looper) {
            super(looper);
            mVTM= vtm;
        }

        @Override
        public void handleMessage(Message msg) {
            if (mVTM.mNativeContext == 0) {
                Log.w(TAG, "VTManager went away with unhandled events");
                return;
            }

            boolean error_was_handled = false;
            switch(msg.what) {
            case EventType.EVENT_INFO:
                if (mOnInfoListener != null)
                    mOnInfoListener.onInfo(mVTM,msg.arg1,msg.arg2, msg.obj);
                return;

            case EventType.EVENT_ERROR:
                Log.e(TAG, "Error (" + msg.arg1 + "," + msg.arg2 + ")");
		if (mOnErrorListener != null) {
                    error_was_handled = mOnErrorListener.onError(mVTM, msg.arg1, msg.arg2);
                }
                return;
                
            case EventType.EVENT_CMDCOMP:
                Log.e(TAG, "cmd complet (" + msg.arg1 + "," + msg.arg2 + ")");

                if (mOnCmdCompListener != null) {
                    error_was_handled = mOnCmdCompListener.onCmdComp(mVTM, msg.arg1, msg.arg2);
                }
		if(msg.arg1 == CmdType.INIT) {
			_connect();
		}
		if(msg.arg1 == CmdType.DISCONNECT) {
			_release();
		}
                return;
            default:
                Log.e(TAG, "Unknown message type " + msg.what);
                return;
            }
        }
    }

    private static native final void native_init();

    private native final void native_setup(Object vtmanager_this) throws IllegalStateException;

    private native final void native_finalize();

}
