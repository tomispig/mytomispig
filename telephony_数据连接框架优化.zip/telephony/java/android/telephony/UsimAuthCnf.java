/******************************************************************************
 * *(C) Copyright 2008 ZTE Ltd.
 * * All Rights Reserved
 * ******************************************************************************/

/* code update
===============================================================================
When              Who            Why
-----------  ----------   ---------------------------------
2010-10-29   Ganhuiliang     Create this file for USIM auth
===============================================================================
*/

package android.telephony;

import android.os.Bundle;

public class UsimAuthCnf {
    public int status;
    public String resAuts;
    public String ck;
    public String ik;
    public String kc;

    public UsimAuthCnf() {
        this.status = -1;
        this.resAuts = null;
        this.ck = null;
        this.ik = null;
        this.kc = null;
    }

    public UsimAuthCnf(Bundle bundle) {
        this.status = bundle.getInt("status");
        this.resAuts = bundle.getString("resAuts");
        this.ck = bundle.getString("ck");
        this.ik = bundle.getString("ik");
        this.kc = bundle.getString("kc");
    }

    public void fillInNotifierBundle(Bundle m) {
        m.putInt("status", status);
        m.putString("resAuts", resAuts);
        m.putString("ck", ck);
        m.putString("ik", ik);
        m.putString("kc", kc);
    }
    
    public String toString() {
        return super.toString() +
            " status: " + status +
            " resAuts: " + resAuts +
            " ck: " + ck +
            " ik: " + ik +
            " kc: " + kc;
    }
}
