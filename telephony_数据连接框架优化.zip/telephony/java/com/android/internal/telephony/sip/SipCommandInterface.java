/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony.sip;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;

import com.android.internal.telephony.BaseCommands;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.UUSInfo;
import com.android.internal.telephony.gsm.SmsBroadcastConfigInfo;

import java.util.ArrayList;

/**
 * SIP doesn't need CommandsInterface. The class does nothing but made to work
 * with PhoneBase's constructor.
 */
class SipCommandInterface extends BaseCommands implements CommandsInterface {
    //ZTE_SYJ_20110623, begin
    int pausedResponseCount;
    ArrayList<Message> pausedResponses = new ArrayList<Message>();
    //ZTE_SYJ_20110623, end

    SipCommandInterface(Context context) {
        super(context);
    }

    @Override public void setOnNITZTime(Handler h, int what, Object obj) {
    }

    public void getIccCardStatus(Message result) {
    }

    public void requestFastDormancy(Message response) {
    }

    public void selectBand(int band, Message response) {
    }

    public void getBand(Message response) {
    }

    public void supplyIccPin(String pin, Message result) {
    }

    public void supplyIccPuk(String puk, String newPin, Message result) {
    }

    public void supplyIccPin2(String pin, Message result) {
    }

    public void supplyIccPuk2(String puk, String newPin2, Message result) {
    }

    public void changeIccPin(String oldPin, String newPin, Message result) {
    }

    public void changeIccPin2(String oldPin2, String newPin2, Message result) {
    }

    public void changeBarringPassword(String facility, String oldPwd,
            String newPwd, Message result) {
    }

    public void supplyNetworkDepersonalization(String netpin, Message result) {
    }

    public void getCurrentCalls(Message result) {
    }

    @Deprecated public void getPDPContextList(Message result) {
    }

    public void getDataCallList(Message result) {
    }

    public void dial(String address, int clirMode, Message result) {
    }

    public void dial(String address, int clirMode, UUSInfo uusInfo,
            Message result) {
    }

    public void
    dialVT (String address, int clirMode, Message result) {
    }

    public void getIMSI(Message result) {
    }

    public void getIMEI(Message result) {
    }

    public void getIMEISV(Message result) {
    }


    public void hangupConnection (int gsmIndex, Message result) {
    }

    public void
    hangupVTConnection (int reason, Message result) {
    }

    public void hangupWaitingOrBackground (Message result) {
    }

    public void hangupForegroundResumeBackground (Message result) {
    }

    public void switchWaitingOrHoldingAndActive (Message result) {
    }

    public void conference (Message result) {
    }


    public void setPreferredVoicePrivacy(boolean enable, Message result) {
    }

    public void getPreferredVoicePrivacy(Message result) {
    }

    public void separateConnection (int gsmIndex, Message result) {
    }

    public void acceptCall (Message result) {
    }

    public void rejectCall (Message result) {
    }

    public void explicitCallTransfer (Message result) {
    }

    public void getLastCallFailCause (Message result) {
    }

    /** @deprecated */
    public void getLastPdpFailCause (Message result) {
    }

    public void getLastDataCallFailCause (Message result) {
    }

    public void setMute (boolean enableMute, Message response) {
    }

    public void getMute (Message response) {
    }

    public void getSignalStrength (Message result) {
    }

    public void getRegistrationState (Message result) {
    }

    public void getGPRSRegistrationState (Message result) {
    }

    public void getOperator(Message result) {
    }

    public void sendDtmf(char c, Message result) {
    }

    public void startDtmf(char c, Message result) {
    }

    public void stopDtmf(Message result) {
    }

    public void sendBurstDtmf(String dtmfString, int on, int off,
            Message result) {
    }

    public void sendSMS (String smscPDU, String pdu, Message result) {
    }

    public void sendSMSMore (String smscPDU, String pdu, Message result) {
    }

    public void sendCdmaSms(byte[] pdu, Message result) {
    }

    public void deleteSmsOnSim(int index, Message response) {
    }

    public void deleteSmsOnRuim(int index, Message response) {
    }

    public void writeSmsToSim(int status, String smsc, String pdu, Message response) {
    }

    public void writeSmsToRuim(int status, String pdu, Message response) {
    }

    public void setupDefaultPDP(String apn, String user, String password,
            Message result) {
    }

    public void deactivateDefaultPDP(int cid, Message result) {
    }

    public void setupDataCall(String radioTechnology, String profile,
            String apn, String user, String password, String authType,
            String protcol, Message result) {
    }
    public void setupDataCall(String radioTechnology, String profile,
            String apn, String user, String password, String authType,
            Message result) {
    }
    public void deactivateDataCall(int cid, Message result) {
    }

    public void setRadioPower(boolean on, Message result) {
    }

    public void setSuppServiceNotifications(boolean enable, Message result) {
    }

    public void acknowledgeLastIncomingGsmSms(boolean success, int cause,
            Message result) {
    }

    public void acknowledgeLastIncomingCdmaSms(boolean success, int cause,
            Message result) {
    }


    public void iccIO (int command, int fileid, String path, int p1, int p2,
            int p3, String data, String pin2, Message result) {
    }

    public void getCLIR(Message result) {
    }

    public void setCLIR(int clirMode, Message result) {
    }

    public void queryCallWaiting(int serviceClass, Message response) {
    }

    public void setCallWaiting(boolean enable, int serviceClass,
            Message response) {
    }

    public void setNetworkSelectionModeAutomatic(Message response) {
    }

    public void setNetworkSelectionModeManual(
            String operatorNumeric, Message response) {
    }
    
    public void setNetworkSelectionModeManualExt(
            String operatorNumeric, int rat, Message response) {
    }
	
    public void getNetworkSelectionMode(Message response) {
    }

    public void getAvailableNetworks(Message response) {
    }

    public void setCallForward(int action, int cfReason, int serviceClass,
                String number, int timeSeconds, Message response) {
    }

    public void queryCallForwardStatus(int cfReason, int serviceClass,
            String number, Message response) {
    }

    public void queryCLIP(Message response) {
    }

    public void  activateCLIP(boolean activate ,Message response){
    }

    public void queryCOLP(Message response){
    }

    public void  activateCOLP(boolean activate ,Message response){
    }

    public void queryCOLR(Message response){
    }

    public void  activateCOLR(boolean activate ,Message response){
    }

    public void queryCNAP(Message response){
    }

    public void  activateCNAP(boolean activate ,Message response){
    }

    public void getBasebandVersion (Message response) {
    }

    public void queryFacilityLock (String facility, String password,
            int serviceClass, Message response) {
    }

    public void setFacilityLock (String facility, boolean lockState,
            String password, int serviceClass, Message response) {
    }

    public void sendUSSD (String ussdString, Message response) {
    }

    public void cancelPendingUssd (Message response) {
    }

    public void resetRadio(Message result) {
    }

    public void invokeOemRilRequestRaw(byte[] data, Message response) {
    }

    public void invokeOemRilRequestStrings(String[] strings, Message response) {
    }

    public void setBandMode (int bandMode, Message response) {
    }

    public void queryAvailableBandMode (Message response) {
    }

    public void sendTerminalResponse(String contents, Message response) {
    }

    public void sendEnvelope(String contents, Message response) {
    }

    public void handleCallSetupRequestFromSim(
            boolean accept, Message response) {
    }

    public void setPreferredNetworkType(int networkType , Message response) {
    }

    public void getPreferredNetworkType(Message response) {
    }

    public void getNeighboringCids(Message response) {
    }

    public void setLocationUpdates(boolean enable, Message response) {
    }

    public void getSmscAddress(Message result) {
    }

    public void setSmscAddress(String address, Message result) {
    }

    public void reportSmsMemoryStatus(boolean available, Message result) {
    }

    public void reportStkServiceIsRunning(Message result) {
    }

    public void getGsmBroadcastConfig(Message response) {
    }

    public void setGsmBroadcastConfig(SmsBroadcastConfigInfo[] config, Message response) {
    }

    public void setGsmBroadcastActivation(boolean activate, Message response) {
    }

    // ***** Methods for CDMA support
    public void getDeviceIdentity(Message response) {
    }

    public void getCDMASubscription(Message response) {
    }

    public void setPhoneType(int phoneType) { //Set by CDMAPhone and GSMPhone constructor
    }

    public void queryCdmaRoamingPreference(Message response) {
    }

    public void setCdmaRoamingPreference(int cdmaRoamingType, Message response) {
    }

    public void setCdmaSubscription(int cdmaSubscription , Message response) {
    }

    public void queryTTYMode(Message response) {
    }

    public void setTTYMode(int ttyMode, Message response) {
    }

    public void sendCDMAFeatureCode(String FeatureCode, Message response) {
    }

    public void getCdmaBroadcastConfig(Message response) {
    }

    public void setCdmaBroadcastConfig(int[] configValuesArray, Message response) {
    }

    public void setCdmaBroadcastActivation(boolean activate, Message response) {
    }

    public void exitEmergencyCallbackMode(Message response) {
    }

//ZTE_SYJ_20110623, begin
    //***** Private Methods

    private void unimplemented(Message result) {
        if (result != null) {
            AsyncResult.forMessage(result).exception
                = new RuntimeException("Unimplemented");

            if (pausedResponseCount > 0) {
                pausedResponses.add(result);
            } else {
                result.sendToTarget();
            }
        }
    }

/* U810 added by GanHuiliang 2010-11-05 *** BEGIN */
	/**
     * Request for WLAN and CMMB
     *
     * @param response
     *
     */
    public void getSimType (Message result){
        unimplemented(result);
    }
    public void doSimAuth (String rand, Message result){
        unimplemented(result);
    }
	public void doUsimAuth (String rand, String autn, Message result){
        unimplemented(result);
    }
/* U810 added by GanHuiliang 2010-11-05 END */
/* U810 added by GanHuiliang 2010-11-08 *** BEGIN */
    public void getLacCid (int BDSType, Message result){
        unimplemented(result);
    }
/* U810 added by GanHuiliang 2010-11-08 END */
/* U810-WUYUN-add for emode 2010-12-14 *** BEGIN */
       public void switchtopsSms(Message response) {
    }
       public void switchtocsSms(Message response) {
    }
   public void deativePdp(Message response) {
   	}
       public void attachGprs(Message response) {
    }
       public void detachGprs(Message response) {
   }
/* U810-WUYUN-0000 2010-12-14 END */
       //wuyun add for gsm|td info periodic mode
      public void setinfoperiodicmode(Message response)
	{	
	}
 	 //wuyun add for turn off  gsm|td info periodic mode
      public void turnoffinfoperiodicmode(Message response)
	{	
	}

	//wuyun add for Double Date Rate speed set
	public void request3Gqos(int i,String transmission,String uplink,String descend,Message response)
	{

	}
	
/* U810-WUYUN-0000 2010-11-19 *** BEGIN */
	  public void query3Gqos(Message response)
  	{
  	}
/* U810-WUYUN-0000 2010-11-19 END */
/* U810 added by GanHuiliang on_20101127 *** BEGIN */
    public void getSimPbInfo (Message result){
        unimplemented(result);
    }
/* U810 added by GanHuiliang on_20101127 END */
//linan_1109 ,start
    public void getIccPinPukRetries (Message result){
        unimplemented(result);
    }
//linan_1109 ,end
//linan_1203 ,start
    public void setNewSmsIndication(int mt, Message result){
        unimplemented(result);
    }

//linan_1203 ,end
//linan_0113,start
    public void getSimSmsCapability (Message result){
        unimplemented(result);
    }
//linan_0113,end

/* U810-WUYUN-add for imei number set 2010-12-14 *** BEGIN */
	public void setImei(String imeinumber,Message response)
	{
		unimplemented(response);
	}
/* U810-WUYUN-0000 2010-12-14 END */

/* U810-WUYUN-add for imei number clear 2010-12-14 *** BEGIN */
	public void clearImei(Message response)
	{
	
		unimplemented(response);
	}
/* U810-WUYUN-0000 2010-12-14 END */

/* U810-WUYUN-add for cp reset 2010-12-15 *** BEGIN */
public void setCpReset(int swtich,Message response)
{
	unimplemented(response);

}
/* U810-WUYUN-0000 2010-12-15 END */

/* U810-WUYUN-add for snmunber set  2010-12-15 *** BEGIN */
public void setSnNumber(String number,Message response)
{
	unimplemented(response);

}
/* U810-WUYUN-0000 2010-12-15 END */

/* U810-WUYUN-add for snmunber query  2010-12-15 *** BEGIN */
public void querySnNumber(Message response)
{
	unimplemented(response);

}
/* U810-WUYUN-0000 2010-12-15 END */

/* U810-WUYUN-deleteSnNumber 2010-12-23 *** BEGIN */
public void deleteSnNumber(Message response)
{
	unimplemented(response);

}
/* U810-WUYUN-0000 2010-12-23 END */

/* U810-WUYUN-delete calibration 2010-12-23 *** BEGIN */
public void deleteCalibration(int sw,Message response)
{
}
/* U810-WUYUN-0000 2010-12-23 END */

/* U810-WUYUN-write calibration 2010-12-23 *** BEGIN */
public void writeCalibration(int sw,Message response)
{
}
/* U810-WUYUN-0000 2010-12-23 END */

/* U810-TIANQIXING-write sensor cal data 2011-01-12 *** BEGIN */
public void writeSensorCalibration(int sw,Message response)
{
}
/* U810-TIANQIXING-0000 2011-01-12 END */

/* U810-WUYUN-query calibration 2010-12-23 *** BEGIN */
public void queryCalibration(int sw,Message response)
{
}
/* U810-WUYUN-0000 2010-12-23 END */

/* U810-WUYUN-getadjust 2011-2-23 *** BEGIN */
    public void getadjust(Message response)
{
}
/* U810-WUYUN-0000 2011-2-23 END */
/* U810-WUYUN-setcfun 2011-2-23 *** BEGIN */
    public void setcfun(int sw,Message response)
	{
	}
/* U810-WUYUN-0000 2011-2-23 END */

/* U810 added by GanHuiliang on_2011324 *** BEGIN */
    public void queryPreferredPlmn (int format, Message result){
        unimplemented(result);
    }

    public void deletePreferredPlmn (int index, Message result) {
        unimplemented(result);
    }

    public void
    modifyPreferredPlmn (int index, int format, String oper, int GSM_AcT, int GSM_Compact_AcT, int UTRAN_AcT, Message result) {
        unimplemented(result);
    }

    public void setNetworkSelectionModeManual(
            String operatorNumeric, int acT, Message result) {unimplemented(result);}
/* U810 added by GanHuiliang on_2011324 END */
//ZTE_SYJ_20110623, end
/* Android added by GanHuiliang on_2011610 *** BEGIN */
    public void
    simBindUserConfirm (int enable, Message result){
        unimplemented(result);
    }
/* Android added by GanHuiliang on_2011610 END */

    public void getSIMLockInfo (Message result) {
    }
}
