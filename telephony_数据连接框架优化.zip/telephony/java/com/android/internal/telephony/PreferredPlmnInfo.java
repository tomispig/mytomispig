/******************************************************************************
 * *(C) Copyright 2011 ZTE Ltd.
 * * All Rights Reserved
 * ******************************************************************************/

/* code update
===============================================================================
When              Who            Why
-----------  ----------   ---------------------------------
2011-03-04   Ganhuiliang     Create this file for Preferred PLMN
===============================================================================
*/


package com.android.internal.telephony;


/**
 * See also RIL_CallForwardInfo in include/telephony/ril.h
 *
 * {@hide}
 */
public class PreferredPlmnInfo {
    public int             index;
    public int             format;
    public String          oper;
    public int             GSM_AcT;
    public int             GSM_Compact_AcT;
    public int             UTRAN_AcT;

    public String toString() {
        return super.toString() + "plmn:" 
            + index + format + oper + GSM_AcT + GSM_Compact_AcT + UTRAN_AcT;

    }
}
