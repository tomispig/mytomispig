/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony;

import android.content.pm.PackageManager;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.ServiceManager;
import android.telephony.PhoneNumberUtils;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


/**
 * SimPhoneBookInterfaceManager to provide an inter-process communication to
 * access ADN-like SIM records.
 */
public class IccPhoneBookInterfaceManagerProxy extends IIccPhoneBook.Stub {
    private IccPhoneBookInterfaceManager mIccPhoneBookInterfaceManager;

    public IccPhoneBookInterfaceManagerProxy(IccPhoneBookInterfaceManager
            iccPhoneBookInterfaceManager) {
        mIccPhoneBookInterfaceManager = iccPhoneBookInterfaceManager;
        if(ServiceManager.getService("simphonebook") == null) {
            ServiceManager.addService("simphonebook", this);
        }
    }

    public void setmIccPhoneBookInterfaceManager(
            IccPhoneBookInterfaceManager iccPhoneBookInterfaceManager) {
        this.mIccPhoneBookInterfaceManager = iccPhoneBookInterfaceManager;
    }

    public boolean
    updateAdnRecordsInEfBySearch (int efid,
            String oldTag, String oldPhoneNumber,
            String newTag, String newPhoneNumber,
            String pin2) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.updateAdnRecordsInEfBySearch(
                efid, oldTag, oldPhoneNumber, newTag, newPhoneNumber, pin2);
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
    public boolean
    updateEmailRecordsInEfBySearch (int efid,
            String newTag, String newPhoneNumber,
            String newEmail, String pin2) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.updateEmailRecordsInEfBySearch(
                efid, newTag, newPhoneNumber, newEmail, pin2);
    }

    public boolean
    updateAdnEmailRecordsInEfBySearch (int efid,
            String oldTag, String oldPhoneNumber,String oldEmail, String oldAnr, String oldAnr2, String oldAnr3, String oldSne, 
            String newTag, String newPhoneNumber,
            String newEmail, String newAnr, String newAnr2, String newAnr3, String newSne, String pin2) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.updateAdnEmailRecordsInEfBySearch(
                efid, oldTag, oldPhoneNumber, oldEmail, oldAnr, oldAnr2, oldAnr3, oldSne, newTag, newPhoneNumber, newEmail, newAnr, newAnr2, newAnr3, newSne, pin2);
    }
/*ZTE_MAOYING_USIM_002 2010-11-24 begin*/
    public boolean
    isSupportUsim() throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getIsSupUsim();
    }
    public boolean
    isSupportANR() throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getIsSupANR();
    }
    public boolean
    isSupportEmail() throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getIsSupEmail();
    }

    public int
    getGetAdnFileld(int index) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getGetAdnFileld(index);
    }

//add by liandongzhou for td some cards not support sne(c3), 20110101
      public boolean isSupportSne() {
        return mIccPhoneBookInterfaceManager.getIsSupSNE();
    }
//end add by liandongzhou for td some cards not support sne(c3), 20110101	  
    public boolean getSimCardType() {
        return mIccPhoneBookInterfaceManager.getSimCardType();//maoying 20100506
    }
/*ZTE_CONTACTS_MAOYING_001 20100506 end*/
    public boolean
    updateAdnRecordsInEfByIndex(int efid, String newTag,
            String newPhoneNumber, int index, String pin2) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.updateAdnRecordsInEfByIndex(efid,
                newTag, newPhoneNumber, index, pin2);
    }

    public int[] getAdnRecordsSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getAdnRecordsSize(efid);
    }
    public int getExtensionSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getExt1Size(efid);
    }

    public int getSimTotalSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getSimTotalSize(efid);
    }

//add by liandongzhou for td need the second the third number 20101223
    public int getAdditionalNumberCount(){
    return mIccPhoneBookInterfaceManager.getAdditionalNumberCount();
    }
//end add by liandongzhou for td need the second the third number 20101223
/*ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 end*/
    public int getSimSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getAdnSize(efid);
    }
    public int getUsimSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getUsimAdnSize();
    }
    public int getUsimAdnRecordsSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getUsimAdnRecordsSize(efid);
    }
    public int getTagRecordsSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getTagRecordsSize(efid);
    }
    public int getEmailRecordsSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getEmailRecordsSize(efid);
    }
    public int getAnrRecordsSize(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getAnrRecordsSize(efid);
    }
/*ZTE_CONTACTS_MAOYING_007 2010-05-27 end*/
    public List<AdnRecord> getAdnRecordsInEf(int efid) throws android.os.RemoteException {
        return mIccPhoneBookInterfaceManager.getAdnRecordsInEf(efid);
    }
}
