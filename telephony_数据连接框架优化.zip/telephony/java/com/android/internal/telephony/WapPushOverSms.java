/*
===============================================================================================================
when          who            what, where, why                                          comment tag
--------      ----           -------------------------------------       ----------------------------------
2010-05-10    zhangminghua   support wap push message                    ZTE_ZMH_CRDB00493582
2010-05-24    zhangminghua   forward dm push message                     ZTE_ZMH_2010-05-24
2010-06-03    zhangminghua   support iso-8859-1 charset                  ZTE_ZMH_CRDB00504571
2010-06-17    zhangminghua   support email push message                  ZTE_ZMH_2010-06-17
2011-05-31    zj                     support dm wap push                             ZTE_SMS_PUSH_ZJ
2011-06-02    zj                     support  text/x-hdml format                   ZTE_SMS_PUSH_ZJ
===============================================================================================================
*/

/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.provider.Telephony.Sms.Intents;
import android.util.Config;
import android.util.Log;
/* ZTE_ZMH_CRDB00493582 2010-5-3 */
import com.android.internal.util.HexDump;
/* end ZTE_ZMH_CRDB00493582 2010-5-3 */
import android.net.Uri;
/**
 * WAP push handler class.
 *
 * @hide
 */
public class WapPushOverSms {
    private static final String LOG_TAG = "WAP PUSH";

    private final Context mContext;
    private WspTypeDecoder pduDecoder;
    /* ZTE_ZMH_CRDB00493582 2010-5-3 */
    private WspTypeDecoder siPduDecoder;
    private WspTypeDecoder slPduDecoder;
    private SMSDispatcher mSmsDispatcher;
    private String mOriginatingAddress;
    private String mimeType;
    /* end ZTE_ZMH_CRDB00493582 2010-5-3 */

    /**
     * Hold the wake lock for 5 seconds, which should be enough time for
     * any receiver(s) to grab its own wake lock.
     */
    private final int WAKE_LOCK_TIMEOUT = 5000;

    public WapPushOverSms(Phone phone, SMSDispatcher smsDispatcher) {
        mSmsDispatcher = smsDispatcher;
        mContext = phone.getContext();
    }

    /* ZTE_ZMH_CRDB00493582 2010-5-3 */
    public int dispatchWapPdu(byte[] pdu,String address,int port,byte[][]pdus) {
           mOriginatingAddress = address;
           return dispatchWapPdu(pdu,port,pdus);
    }    
    /* end ZTE_ZMH_CRDB00493582 2010-5-3 */

    /**
     * Dispatches inbound messages that are in the WAP PDU format. See
     * wap-230-wsp-20010705-a section 8 for details on the WAP PDU format.
     *
     * @param pdu The WAP PDU, made up of one or more SMS PDUs
     * @return a result code from {@link Telephony.Sms.Intents}, or
     *         {@link Activity#RESULT_OK} if the message has been broadcast
     *         to applications
     */
    public int dispatchWapPdu(byte[] pdu,int port,byte[][]pdus) {

        if (true/*Config.LOGD*/) {
			Log.d(LOG_TAG, "Rx: " + IccUtils.bytesToHexString(pdu));
		}

        int index = 0;
        int transactionId = pdu[index++] & 0xFF;
        int pduType = pdu[index++] & 0xFF;
        int headerLength = 0;

        if ((pduType != WspTypeDecoder.PDU_TYPE_PUSH) &&
                (pduType != WspTypeDecoder.PDU_TYPE_CONFIRMED_PUSH) &&
			(pduType != WspTypeDecoder.PDU_TYPE_DM_PUSH)) {  //add by zhooujing, ZTE_SMS_PUSH, 20110531
            if (true/*Config.LOGD*/) {
                Log.w(LOG_TAG, "Received non-PUSH WAP PDU. Type = " + pduType);
            }
            return Intents.RESULT_SMS_HANDLED;
        }

        pduDecoder = new WspTypeDecoder(pdu);

        /**
         * Parse HeaderLen(unsigned integer).
         * From wap-230-wsp-20010705-a section 8.1.2
         * The maximum size of a uintvar is 32 bits.
         * So it will be encoded in no more than 5 octets.
         */
        if (pduDecoder.decodeUintvarInteger(index) == false) {
            if (true/*Config.LOGD*/) {
                Log.w(LOG_TAG, "Received PDU. Header Length error index at:" + index);
            }
            return Intents.RESULT_SMS_GENERIC_ERROR;
        }
        headerLength = (int)pduDecoder.getValue32();
        index += pduDecoder.getDecodedDataLength();

        int headerStartIndex = index;

        /**
         * Parse Content-Type.
         * From wap-230-wsp-20010705-a section 8.4.2.24
         *
         * Content-type-value = Constrained-media | Content-general-form
         * Content-general-form = Value-length Media-type
         * Media-type = (Well-known-media | Extension-Media) *(Parameter)
         * Value-length = Short-length | (Length-quote Length)
         * Short-length = <Any octet 0-30>   (octet <= WAP_PDU_SHORT_LENGTH_MAX)
         * Length-quote = <Octet 31>         (WAP_PDU_LENGTH_QUOTE)
         * Length = Uintvar-integer
         */
        if (pduDecoder.decodeContentType(index) == false) {
            if (true/*Config.LOGD*/) {
                Log.w(LOG_TAG, "Received PDU. Header Content-Type error index at:" + index);
            }
            return Intents.RESULT_SMS_GENERIC_ERROR;
        }
        int binaryContentType;
        /* ZTE_ZMH_CRDB00493582 2010-5-3 */
        mimeType = pduDecoder.getValueString();
        Log.w(LOG_TAG, "Received PDU. mimeType=" + mimeType);
        /* end ZTE_ZMH_CRDB00493582 2010-5-3 */
        if (mimeType == null) {
            binaryContentType = (int)pduDecoder.getValue32();
            Log.w(LOG_TAG, "Received PDU.  binaryContentType= " + binaryContentType);
            // TODO we should have more generic way to map binaryContentType code to mimeType.
            switch (binaryContentType) {
                case WspTypeDecoder.CONTENT_TYPE_B_DRM_RIGHTS_XML:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_DRM_RIGHTS_XML;
                    break;
                case WspTypeDecoder.CONTENT_TYPE_B_DRM_RIGHTS_WBXML:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_DRM_RIGHTS_WBXML;
                    break;
                case WspTypeDecoder.CONTENT_TYPE_B_PUSH_SI:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SI;
                    break;
                case WspTypeDecoder.CONTENT_TYPE_B_PUSH_SL:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SL;
                    break;
                case WspTypeDecoder.CONTENT_TYPE_B_PUSH_CO:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_CO;
                    break;
                case WspTypeDecoder.CONTENT_TYPE_B_MMS:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_MMS;
                    break;
                case WspTypeDecoder.CONTENT_TYPE_B_VND_DOCOMO_PF:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_VND_DOCOMO_PF;
                    break;
                case WspTypeDecoder.CONTENT_TYPE_B_SUPL_INIT:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_SUPL_INIT;
                    break;
                /* ZTE_ZMH_CRDB00493582 2010-5-6 */
				case WspTypeDecoder.CONTENT_TYPE_B_PUSH_SYNML_NOTIFICATION:
					mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SYNML_NOTIFICATION;
                /* end ZTE_ZMH_CRDB00493582 2010-5-6 */
                    break;
                /* ZTE_ZMH_2010-05-24 dm used */
                case WspTypeDecoder.CONTENT_TYPE_B_PUSH_CONNECTIVITY_WBXML:
					mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_CONNECTIVITY_WBXML;
                    break;
                /* ZTE_ZMH_2010-05-24 dm used */
                /* ZTE_ZMH_2010-06-17 email used */
                case WspTypeDecoder.CONTENT_TYPE_B_EMN_WBXML:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_EMN_WBXML;
                    break;
                /* end ZTE_ZMH_2010-06-17 email used */
                /* START ZTE_SMS_PUSH_ZJ, 20110602 */
                case WspTypeDecoder.CONTENT_TYPE_B_X_HDML:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_X_HDML;
                    break;
		/* END ZTE_SMS_PUSH_ZJ, 20110602 */
				
   		  /* ZTE_HUANGWEI_2011-07-19  139 email configuration used */
		  case WspTypeDecoder.CONTENT_TYPE_B_CMCC_WBXML:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_CMCC_WBXM;
   		  /* ZTE_HUANGWEI_2011-07-19  139 email configuration used */
   		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
		  case WspTypeDecoder.CONTENT_TYPE_B_CMCC_BOMBING_WBXML:
                    mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_CMCC_BOMBING_WBXM;
   		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
                default:
                    if (true/*Config.LOGD*/) {
                        Log.w(LOG_TAG,
                                "Received PDU. Unsupported Content-Type = " + binaryContentType);
                    }
                return Intents.RESULT_SMS_HANDLED;
            }
        } else {
            if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_DRM_RIGHTS_XML)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_DRM_RIGHTS_XML;
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_DRM_RIGHTS_WBXML)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_DRM_RIGHTS_WBXML;
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SI)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_PUSH_SI;
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SL)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_PUSH_SL;
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_CO)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_PUSH_CO;
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_MMS)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_MMS;
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_VND_DOCOMO_PF)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_VND_DOCOMO_PF;
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_SUPL_INIT)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_SUPL_INIT;
            /* ZTE_ZMH_CRDB00493582 2010-5-6 */
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SYNML_NOTIFICATION)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_PUSH_SYNML_NOTIFICATION;            
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SL_DCD)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_PUSH_SL;
            /* ZTE_ZMH_2010-05-24 dm used */
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_CONNECTIVITY_WBXML)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_PUSH_CONNECTIVITY_WBXML;
            /* end ZTE_ZMH_2010-05-24 dm used */
            /* ZTE_ZMH_2010-06-17 email used */
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_EMN_WBXML)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_EMN_WBXML;
            /* end ZTE_ZMH_2010-06-17 email used */
	    /* START ZTE_SMS_PUSH_ZJ,20110602 */
            } else if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_X_HDML)) {
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_X_HDML;
                /* END ZTE_SMS_PUSH_ZJ,20110602 */
            } else if(mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_CMCC_WBXM)){        
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_CMCC_WBXML;
                Log.w(LOG_TAG, "-----CMCC--binaryContentType = " + binaryContentType);
   		  /* ZTE_HUANGWEI_2011-07-19  139 email configuration used */
   		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
            } else if(mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_CMCC_BOMBING_WBXM)){        
                binaryContentType = WspTypeDecoder.CONTENT_TYPE_B_CMCC_BOMBING_WBXML;
                Log.w(LOG_TAG, "-----CMCC--binaryContentType = " + binaryContentType);
   		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
            } else {
                if (true/*Config.LOGD*/){
                    Log.w(LOG_TAG, "Received PDU. Unknown Content-Type = " + mimeType);
                }
                return Intents.RESULT_SMS_HANDLED;
            }
            /* end ZTE_ZMH_CRDB00493582 2010-5-6 */
        }
        index += pduDecoder.getDecodedDataLength();

        int dataIndex = headerStartIndex + headerLength;
            Log.w(LOG_TAG, "Received PDU.  index= " + index);
            Log.w(LOG_TAG, "Received PDU.  headerStartIndex= " + headerStartIndex);
            Log.w(LOG_TAG, "Received PDU.  headerLength= " + headerLength);
		
        boolean dispatchedByApplication = false;
        switch (binaryContentType) {
            case WspTypeDecoder.CONTENT_TYPE_B_PUSH_CO:
                dispatchWapPdu_PushCO(pdu, transactionId, pduType, headerStartIndex, headerLength);
                dispatchedByApplication = true;
                break;
            case WspTypeDecoder.CONTENT_TYPE_B_MMS:
                dispatchWapPdu_MMS(pdu, transactionId, pduType, headerStartIndex, headerLength);
                dispatchedByApplication = true;
                break;
            /* ZTE_ZMH_CRDB00493582 2010-5-3 */
            case WspTypeDecoder.CONTENT_TYPE_B_PUSH_SI:   
                /* ZTE_ZMH_CRDB00504571 2010-06-03 */
                dispatchedByApplication = dispatchWapPdu_SI(pdu, transactionId, pduType, dataIndex); 
                if (false == dispatchedByApplication){   //should set invalid mimeType
                    mimeType += ".invalid";
                }
                /* end ZTE_ZMH_CRDB00504571 2010-06-03 */
                break;
            case WspTypeDecoder.CONTENT_TYPE_B_PUSH_SL:
                /* ZTE_ZMH_CRDB00493582 2010-5-7 */
                String dcd_id_string = new String(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SL_DCD);
                byte[] dcd_id_byte = dcd_id_string.getBytes();
                if (headerLength>=dcd_id_byte.length){
                    int headerStartIndexOffset = 0;
                    while ((headerStartIndexOffset + dcd_id_byte.length) <= headerLength) {
                        int i;
                        for (i = 0; i < dcd_id_byte.length; i++ ){
                            if (pdu[headerStartIndex+headerStartIndexOffset+i] != dcd_id_byte[i]){
                                break;
                            }
                        }
                        if (i == dcd_id_byte.length){
                           mimeType = WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SL_DCD;   //dcd id
                           break;
                        }
                        headerStartIndexOffset++;
                    }
                }
                /* end ZTE_ZMH_CRDB00493582 2010-5-7 */                 
                /* ZTE_ZMH_CRDB00504571 2010-06-03 */
                dispatchedByApplication = dispatchWapPdu_SL(pdu, transactionId, pduType, dataIndex);
                if (false == dispatchedByApplication){  //should set invalid mimeType
                    mimeType += ".invalid";
                }
                /* end ZTE_ZMH_CRDB00504571 2010-06-03 */
                break;
            /* ZTE_ZMH_CRDB00493582 2010-5-6 */
			case WspTypeDecoder.CONTENT_TYPE_B_PUSH_SYNML_NOTIFICATION:
                dispatchWapPdu_SYNML_NOTIFICATION(pdu, transactionId, pduType, dataIndex);
                dispatchedByApplication = true;	
                break;
            /* end ZTE_ZMH_CRDB00493582 2010-5-6 */
            /* ZTE_ZMH_2010-05-24 dm used */
			case WspTypeDecoder.CONTENT_TYPE_B_PUSH_CONNECTIVITY_WBXML:
                dispatchWapPdu_CONNECTIVITY_WBXML(pdu, transactionId, pduType, dataIndex);
                dispatchedByApplication = true;	
                break;
            /* end ZTE_ZMH_2010-05-24 dm used */
            /* ZTE_ZMH_2010-06-17 email used */
			case WspTypeDecoder.CONTENT_TYPE_B_EMN_WBXML:
                dispatchWapPdu_EMN_WBXML(pdu, transactionId, pduType, dataIndex);
		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
                dispatchWapPdu_CMCC_WBXML(pdu, port,pdus);
		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
                dispatchedByApplication = true;	
                break;
            /* end ZTE_ZMH_2010-06-17 email used */
		/* START ZTE_SMS_PUSH_ZJ,20110602 */
		case WspTypeDecoder.CONTENT_TYPE_B_X_HDML:
                dispatchWapPdu_B_X_HDML(pdu, transactionId, pduType, dataIndex);
                dispatchedByApplication = true;	
                break;
                /* END ZTE_SMS_PUSH_ZJ,20110602 */
            /* end ZTE_ZMH_CRDB00493582 2010-5-3 */
   		  /* ZTE_HUANGWEI_2011-07-19  139 email configuration used */
			case WspTypeDecoder.CONTENT_TYPE_B_CMCC_WBXML:
                dispatchWapPdu_CMCC_WBXML(pdu, port,pdus);
                dispatchedByApplication = true;	
                break;
   		  /* ZTE_HUANGWEI_2011-07-19  139 email configuration used */
		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
		 case WspTypeDecoder.CONTENT_TYPE_B_CMCC_BOMBING_WBXML:
                dispatchWapPdu_CMCC_WBXML(pdu, port,pdus);
                dispatchedByApplication = true;	
                break;
   		  /* ZTE_HUANGWEI_2011-08-22  139 email configuration used */
            default:
                break;
        }
        if (dispatchedByApplication == false) {
            Log.w(LOG_TAG, "----Pdu_default---Received PDU.  transactionId= " + transactionId);
            Log.w(LOG_TAG, "----Pdu_default---Received PDU.  pduType= " + pduType);
            Log.w(LOG_TAG, "----Pdu_default---Received PDU.  mimeType= " + mimeType);
            Log.w(LOG_TAG, "----Pdu_default---Received PDU.  headerStartIndex= " + headerStartIndex);
            Log.w(LOG_TAG, "----Pdu_default---Received PDU.  headerLength= " + headerLength);
            dispatchWapPdu_default(pdu, transactionId, pduType, mimeType,
                                   headerStartIndex, headerLength);
        }
        return Activity.RESULT_OK;
    }

    private void dispatchWapPdu_default(byte[] pdu, int transactionId, int pduType,
                                        String mimeType, int headerStartIndex, int headerLength) {
        byte[] header = new byte[headerLength];
        System.arraycopy(pdu, headerStartIndex, header, 0, header.length);
        int dataIndex = headerStartIndex + headerLength;
        byte[] data;

        data = new byte[pdu.length - dataIndex];
        System.arraycopy(pdu, dataIndex, data, 0, data.length);

        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);
        intent.setType(mimeType);
        intent.putExtra("transactionId", transactionId);
        intent.putExtra("pduType", pduType);
        intent.putExtra("header", header);
        intent.putExtra("data", data);

        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");
    }

    private void dispatchWapPdu_PushCO(byte[] pdu, int transactionId, int pduType,
                                       int headerStartIndex, int headerLength) {
        byte[] header = new byte[headerLength];
        System.arraycopy(pdu, headerStartIndex, header, 0, header.length);

        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);
        intent.setType(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_CO);
        intent.putExtra("transactionId", transactionId);
        intent.putExtra("pduType", pduType);
        intent.putExtra("header", header);
        intent.putExtra("data", pdu);

        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");
    }

    private void dispatchWapPdu_MMS(byte[] pdu, int transactionId, int pduType,
                                    int headerStartIndex, int headerLength) {
        byte[] header = new byte[headerLength];
        System.arraycopy(pdu, headerStartIndex, header, 0, header.length);
        int dataIndex = headerStartIndex + headerLength;
        byte[] data = new byte[pdu.length - dataIndex];
        System.arraycopy(pdu, dataIndex, data, 0, data.length);

        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);
        intent.setType(WspTypeDecoder.CONTENT_MIME_TYPE_B_MMS);
        intent.putExtra("transactionId", transactionId);
        intent.putExtra("pduType", pduType);
        intent.putExtra("header", header);
        intent.putExtra("data", data);

        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_MMS");
    }

    /* ZTE_ZMH_CRDB00493582 2010-5-3 */
    /* ZTE_ZMH_CRDB00504571 2010-06-03 */
    private boolean dispatchWapPdu_SI(byte[] pdu, int transactionId, int pduType, int dataIndex) {
        byte[] data = new byte[pdu.length - dataIndex];
        System.arraycopy(pdu, dataIndex, data, 0, data.length);

        // wbxml_version
         int index = 0;
         int wbxml_version = data[index++] & 0xFF;
         if ((0x1 != wbxml_version) && (0x02 != wbxml_version)){
            Log.w(LOG_TAG,"Received SI push version is Not support index at:" + index);
            return false;
         }

         // create the decoder       
         siPduDecoder = new WspTypeDecoder(data);   

         // public id
         if (siPduDecoder.decodeUintvarInteger(index) == false) {
             Log.w(LOG_TAG, "Received SI push publicId error index at:" + index);
             return false;
         }
        long publicId = siPduDecoder.getValue32();
        index += siPduDecoder.getDecodedDataLength();
        if (5 != publicId ){
            Log.w(LOG_TAG,"Received SI push Not SI index at:" + index);
            return false;        
        }

        // charset
        if (siPduDecoder.decodeUintvarInteger(index) == false) {
             Log.w(LOG_TAG, "Received SI push charset error index at:" + index);
             return false;
        }        
        long charSet = siPduDecoder.getValue32();
        index += siPduDecoder.getDecodedDataLength();
        /* ZTE_ZMH_CRDB00504571 2010-05-31 */
        if ((0x6A != charSet) && (0x04 != charSet)){    //0x6A:utf-8       0x04:iso-8859-1
            Log.w(LOG_TAG,"Received SI push charset Not support index at:" + index);
            return false;
        }
        /* end ZTE_ZMH_CRDB00504571 2010-05-31 */

        // get the string table
        if (siPduDecoder.decodeUintvarInteger(index) == false) {
             Log.w(LOG_TAG, "Received SI push table_strlen error index at:" + index);
             return false;
        }            
        long table_strlen = siPduDecoder.getValue32();
        index += siPduDecoder.getDecodedDataLength();
        if (0 != table_strlen){
            Log.w(LOG_TAG,"Received SI push string table Not support index at:" + index);
            return false;
        }

        index += table_strlen;

        if(index >= data.length -1){
            Log.w(LOG_TAG,"Received SI push No valid content index at:" + index);
            return false;
        }
        
        // initialize the si element
        siPduDecoder.action = WspTypeDecoder.SIGNAL_MEDIUM;
        siPduDecoder.href = null;
        siPduDecoder.NotifyText = null;
        siPduDecoder.si_id = null;
        siPduDecoder.CharSet = charSet;

        int attrTag = (data[index] & 0x80 )>> 7;
        int conTag = (data[index] & 0x40 )>> 6;
        int SI_tag = data[index] & 0x3F;
        if ( 5 != SI_tag){
            Log.w(LOG_TAG,"Received SI push Not SI 2 index at:" + index);
            return false;
        }
        int siEndTagCount = attrTag + conTag;
        index++;

        while((index < data.length )&& (siEndTagCount > 0)) {

			SI_tag = data[index] & 0x3F;
			switch (SI_tag){
				case 0x01:  // end tag 
					if (0 != (data[index] & 0xC0)){
						Log.w(LOG_TAG,"Received SI push end tag not support index at:" + index);
						return false;
					}
					index++;
					siEndTagCount--;
					break;
				case 0x06:  // indication
					attrTag = (data[index] & 0x80) >> 7;
					conTag = (data[index] & 0x40) >> 6;
					long indicationEndTagcount = attrTag + conTag;
					index ++;
					while((index <= data.length -1) && (indicationEndTagcount >0 )){
						int attrId = data[index] & 0xFF;
						switch( attrId ) {
							case 0x01:    // end tag
								indicationEndTagcount--;
								index ++;
								break;
							case 0x03:   // string
								if (0 != (data[index] & 0xC0)){
									Log.w(LOG_TAG,"Received SI push string table not support index at:" + index);
									return false;
								}
								index++;
						
								// get text
                                /* ZTE_ZMH_CRDB00504571 2010-06-02 */
								if ( 0x04 == charSet){    //latin1
									if(siPduDecoder.decodeTextStringLatin1(index) == false){
										Log.w(LOG_TAG, "Received SI push latin1 text error index at:" + index);
										return false;
									}																																		
								} else {                  //default:utf8
									if(siPduDecoder.decodeTextString(index) == false){
										Log.w(LOG_TAG, "Received SI push utf8 text error index at:" + index);
										return false;
									}								
								}
                                /* end ZTE_ZMH_CRDB00504571 2010-06-02 */
								siPduDecoder.NotifyText = siPduDecoder.getValueString();
								index += siPduDecoder.getDecodedDataLength();
								break;

							case 0x05:
								siPduDecoder.action = siPduDecoder.SIGNAL_NONE;
								index ++;
								break;
							case 0x06:
								siPduDecoder.action = siPduDecoder.SIGNAL_LOW;
								index ++;
								break;
							case 0x07:
								siPduDecoder.action = siPduDecoder.SIGNAL_MEDIUM;
								index ++;
								break;                                      
							case 0x08:
								siPduDecoder.action = siPduDecoder.SIGNAL_HIGH;
								index ++;
								break;                 
							case 0x09:
								siPduDecoder.action = siPduDecoder.SIGNAL_DELETE;
								index ++;
								break;
							case 0x0A:  // create time parse may error
								index ++;
                                /* ZTE_ZMH_CRDB00504571 2010-06-02 */
								if((data[index] & 0xFF )!= 0xC3){  // OPAque data 
									Log.w(LOG_TAG, "Received SI push data type Not support index at:" + index);
									return false;
								}
                                /* end ZTE_ZMH_CRDB00504571 2010-06-02 */
								index++;
								index += data[index];
								index ++;
								break;   
							case 0x0B:  // href field is null
								index ++;
								if(data[index] != 0x03){
									Log.w(LOG_TAG, "Received SI push href 0x0B string type not support index at:"+ index);
									return false;
								}
								index ++;
								if(siPduDecoder.decodeUrlString(index) ==  false)  {
									Log.w(LOG_TAG, "Received SI push href 0x0B url parse error index at:" + index);
									return false;
								}
								siPduDecoder.href = siPduDecoder.getValueString();
								index += siPduDecoder.getDecodedDataLength();
								break;
							case 0x0C:  // href field:http:// 
								index ++;
								if(data[index] != 0x03){
									Log.w(LOG_TAG, "Received SI push href 0x0C string type not support index at:" + index);
									return false;
								}
								index ++;
								if(siPduDecoder.decodeUrlString(index) ==  false) {
									Log.w(LOG_TAG, "Received SI push href 0x0C url parse error index at:" + index);
									return false;
								}
								siPduDecoder.href = siPduDecoder.getValueString();
								index += siPduDecoder.getDecodedDataLength();     
								siPduDecoder.href = new String("http://") + siPduDecoder.href;
								break;
							case 0x0D:  // href field : http://www. 
								index ++;
								if(data[index] != 0x03){
									Log.w(LOG_TAG, "Received SI push href 0x0D string type not support index at:" + index);
									return false;
								}
								index ++;
								if(siPduDecoder.decodeUrlString(index) ==  false) {
									Log.w(LOG_TAG, "Received SI push href 0x0D url parse error index at:" + index);
									return false;
								}
								siPduDecoder.href = siPduDecoder.getValueString();
								index += siPduDecoder.getDecodedDataLength();  
								siPduDecoder.href = new String("http://www.") + siPduDecoder.href;
								break;
							case 0x0E:  // href field -- https://
								index ++;
								if(data[index] != 0x03){
									Log.w(LOG_TAG, "Received SI push href 0x0E string type not support index at:" + index);
									return false;
								}
								index ++;
								if(siPduDecoder.decodeUrlString(index) ==  false) {
									Log.w(LOG_TAG, "Received SI push href 0x0E url parse error index at:" + index);
									return false;
								}
								siPduDecoder.href = siPduDecoder.getValueString();
								index += siPduDecoder.getDecodedDataLength();    
								siPduDecoder.href = new String("https://") + siPduDecoder.href;                        
								break;         
							case 0x0F: // href field -- https://www. 
								index ++;
								if(data[index] != 0x03){
									Log.w(LOG_TAG, "Received SI push href 0x0F string type not support index at:" + index);
									return false;
								}
								index ++;
								if(siPduDecoder.decodeUrlString(index) ==  false) {
									Log.w(LOG_TAG, "Received SI push href 0x0F url parse error index at:" + index);
									return false;
								}
								siPduDecoder.href = siPduDecoder.getValueString();
								index += siPduDecoder.getDecodedDataLength();       
								siPduDecoder.href = new String("https://www.") + siPduDecoder.href;
								break;  
							case 0x10:  // si-expires 
								index ++;
                                /* ZTE_ZMH_CRDB00504571 2010-06-02 */
								if((data[index] & 0xFF) != 0xC3){  // OPAque data 
									Log.w(LOG_TAG, "Received SI push data type Not support index at:" + index);
									return false;
								}
                                /* end ZTE_ZMH_CRDB00504571 2010-06-02 */
								index++;
								index += data[index];
								index ++;
								break;       
							case 0x11:  // si id field
								index ++;
								Log.w(LOG_TAG, "dispatchWapPdu_default. data[index] 41= " + data[index] + "index :" + index);
								if(data[index] != 0x03) {
									Log.w(LOG_TAG, "Received SI push SI ID type Not support index at:" + index);
									return false;
								}
								// move the pointer to the string field
								index++;
								if(siPduDecoder.decodeUrlString(index) ==  false)  {
									Log.w(LOG_TAG, "Received SI push SI ID parse error index at:" + index);
									return false;
								}   
								siPduDecoder.si_id = siPduDecoder.getValueString();
								index += siPduDecoder.getDecodedDataLength();
								break;    
							default:
								//indicationEndTagcount = 0;
								Log.w(LOG_TAG, "Received SI push attribute content type not support index at:" + index);
								return false;
								//break;                            
						}
					}
					break;
				case 0x07: // info ingnore and skip
					attrTag = (data[index] & 0x80) >> 7;
					conTag = (data[index] & 0x40) >> 6;
					int infoEndTagCount = attrTag + conTag;
					index++;
					while((index <= data.length -1) && (infoEndTagCount > 0))
					{
						if (0x01 == (data[index] & 0xff)){
							infoEndTagCount--;
						}
						index++;
					}
					break;
				default:
					//siEndTagCount = 0;
					Log.w(LOG_TAG, "Received SI push not handled tag:0x%x"+SI_tag);
                    return false;
					//break;
}

        }

        if(siPduDecoder.action == siPduDecoder.SIGNAL_DELETE )  {
            Log.w(LOG_TAG, "dispatchWapPdu_default. si_id = " + siPduDecoder.si_id);
            Log.w(LOG_TAG, "delete all the push message with the same si_id");
        }
        else if(siPduDecoder.action == siPduDecoder.SIGNAL_DELETE || siPduDecoder.action == siPduDecoder.SIGNAL_NONE)  {
            Log.w(LOG_TAG, "dispatchWapPdu_default. si_id = " + siPduDecoder.si_id);
            Log.w(LOG_TAG, "don't save the push message");
        }        

        /* ZTE_ZMH_CRDB00493582 2010-5-7 */
        Log.e(LOG_TAG, "dispatchWapPdu SI mimeType:" + mimeType);
        Log.e(LOG_TAG, "dispatchWapPdu SI transactionId:"+transactionId);
        Log.e(LOG_TAG, "dispatchWapPdu SI pduType:"+pduType);
        Log.e(LOG_TAG, "dispatchWapPdu SI pdu :" + HexDump.toHexString(data));
        Log.e(LOG_TAG, "dispatchWapPdu SI action = " + siPduDecoder.action);
        Log.e(LOG_TAG, "dispatchWapPdu SI CharSet = " + siPduDecoder.CharSet);
        Log.e(LOG_TAG, "dispatchWapPdu SI href = " + siPduDecoder.href);
        Log.e(LOG_TAG, "dispatchWapPdu SI NotifyText length = " + siPduDecoder.NotifyText.length());
        Log.e(LOG_TAG, "dispatchWapPdu SI si_id = " + siPduDecoder.si_id);    
        Log.e(LOG_TAG, "dispatchWapPdu SI address = " + mOriginatingAddress);    

        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);//WAP_PUSH_RECEIVED_ACTION
        intent.setType(mimeType);
        intent.putExtra("transactionId", transactionId);
        intent.putExtra("pduType", pduType);
        intent.putExtra("data", data);
        intent.putExtra("href", siPduDecoder.href);
        intent.putExtra("action", siPduDecoder.action);
        intent.putExtra("NotifyText", siPduDecoder.NotifyText);
        intent.putExtra("si_id", siPduDecoder.si_id);// huangqinbo realize wap push delete & replace requirement 20101122
        intent.putExtra("address", mOriginatingAddress);
        /* end ZTE_ZMH_CRDB00493582 2010-5-7 */    
        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");

        return true;
    }
    /* end ZTE_ZMH_CRDB00493582 2010-5-3 */
    /* end ZTE_ZMH_CRDB00504571 2010-06-03 */

    /* ZTE_ZMH_CRDB00504571 2010-06-03 */
	/* ZTE_ZMH_CRDB00493582 2010-5-6 */
    private boolean dispatchWapPdu_SL(byte[] pdu, int transactionId, int pduType, int dataIndex) {
        byte[] data = new byte[pdu.length - dataIndex];
        System.arraycopy(pdu, dataIndex, data, 0, data.length);

        // wbxml_version
         int index = 0;
         int wbxml_version = data[index++] & 0xFF;
         if ((0x1 != wbxml_version) && (0x02 != wbxml_version)){
            Log.w(LOG_TAG,"Received SL push version is Not support index at:" + index);
            return false;
         }

         // create the decoder       
         slPduDecoder = new WspTypeDecoder(data);   

         // public id
         if (slPduDecoder.decodeUintvarInteger(index) == false) {
             Log.w(LOG_TAG, "Received SL push publicId error index at:" + index);
             return false;
         }
        long publicId = slPduDecoder.getValue32();
        index += slPduDecoder.getDecodedDataLength();
        if (6 != publicId ){
            Log.w(LOG_TAG,"Received SL push Not SL index at:" + index);
            return false;        
        }

        // charset
        if (slPduDecoder.decodeUintvarInteger(index) == false) {
             Log.w(LOG_TAG, "Received SL push charset error index at:" + index);
             return false;
        }        
        long charSet = slPduDecoder.getValue32();
        index += slPduDecoder.getDecodedDataLength();
        /* ZTE_ZMH_CRDB00504571 2010-05-31 */
        if ((0x6A != charSet) && (0x04 != charSet)){    //0x6A:utf-8       0x04:iso-8859-1
            Log.w(LOG_TAG,"Received SL push charset Not support index at:" + index);
            return false;
        }
        /* end ZTE_ZMH_CRDB00504571 2010-05-31 */

        // get the string table
        if (slPduDecoder.decodeUintvarInteger(index) == false) {
             Log.w(LOG_TAG, "Received SI push table_strlen error index at:" + index);
             return false;
        }            
        long table_strlen = slPduDecoder.getValue32();
        index += slPduDecoder.getDecodedDataLength();
        if (0 != table_strlen){
            Log.w(LOG_TAG,"Received SL push string table Not support index at:" + index);
            return false;
        }

        index += table_strlen;

        if(index >= data.length -1){
            Log.w(LOG_TAG,"Received SL push No valid content index at:" + index);
            return false;
        }
        
        // initialize the sl element
        slPduDecoder.action = WspTypeDecoder.EXECUTE_LOW;
        slPduDecoder.href = null;
        slPduDecoder.NotifyText = null;
        slPduDecoder.CharSet = charSet;

        int attrTag = (data[index] & 0x80 )>> 7;
        int conTag = (data[index] & 0x40 )>> 6;
        int SL_tag = data[index] & 0x3F;
        if ( 5 != SL_tag){
            Log.w(LOG_TAG,"Received SL push Not SI 2 index at:" + index);
            return false;
        }
        int slEndTagCount = attrTag + conTag;
        index++;

        while((index < data.length )&& (slEndTagCount > 0)) {

			SL_tag = data[index] & 0x3F;
			switch (SL_tag){
				case 0x01:  // end tag 
					if (0 != (data[index] & 0xC0)){
						Log.w(LOG_TAG,"Received SL push end tag not support index at:" + index);
						return false;
					}
					index++;
					slEndTagCount--;
					break;
				case 0x05:  // action EXECUTE_LOW 
					slPduDecoder.action = slPduDecoder.EXECUTE_LOW;
					index++;
					break;
				case 0x06:  // action EXECUTE_HIGH 
					slPduDecoder.action = slPduDecoder.EXECUTE_HIGH;
					index++;
					break;
				case 0x07:  // action EXECUTE_CACHE
					slPduDecoder.action = slPduDecoder.EXECUTE_CACHE;
					index++;
					break;										
				case 0x08:  // href  field	null 
					index++;
					if(data[index] != 0x03){
						Log.w(LOG_TAG, "Received SL push href 0x08 string type not support index at:"+ index);
						return false;
					}
					index++;
					if(slPduDecoder.decodeUrlString(index) ==  false)  {
						Log.w(LOG_TAG, "Received SL push href 0x08 url parse error index at:" + index);
						return false;
					}
					slPduDecoder.href = slPduDecoder.getValueString();
					index += slPduDecoder.getDecodedDataLength();
                    break;
				case 0x09:  // href  field:http://
					index++;
					if(data[index] != 0x03){
						Log.w(LOG_TAG, "Received SL push href 0x09 string type not support index at:" + index);
						return false;
					}
					index++;
					if(slPduDecoder.decodeUrlString(index) ==  false) {
						Log.w(LOG_TAG, "Received SL push href 0x09 url parse error index at:" + index);
						return false;
					}
					slPduDecoder.href = new String("http://") + slPduDecoder.getValueString();
					index += slPduDecoder.getDecodedDataLength();	  				
					break;
				case 0x0A:  // href  field:http://www. 
					index++;
					if(data[index] != 0x03){
						Log.w(LOG_TAG, "Received SL push href 0x0A string type not support index at:" + index);
						return false;
					}
					index++;
					if(slPduDecoder.decodeUrlString(index) ==  false) {
						Log.w(LOG_TAG, "Received SL push href 0x0A url parse error index at:" + index);
						return false;
					}
					slPduDecoder.href = new String("http://www.") + slPduDecoder.getValueString();
					index += slPduDecoder.getDecodedDataLength();  
					break;
				case 0x0B:  // href  field:https:// 
					index++;
					if(data[index] != 0x03){
						Log.w(LOG_TAG, "Received SL push href 0x0B string type not support index at:" + index);
						return false;
					}
					index++;
					if(siPduDecoder.decodeUrlString(index) ==  false) {
						Log.w(LOG_TAG, "Received SL push href 0x0B url parse error index at:" + index);
						return false;
					}
					slPduDecoder.href = new String("https://") + slPduDecoder.getValueString();
					index += slPduDecoder.getDecodedDataLength();  					
					break;
				case 0x0C:  // href  field:https://www. 
					index++;
					if(data[index] != 0x03){
						Log.w(LOG_TAG, "Received SL push href 0x0C string type not support index at:" + index);
						return false;
					}
					index++;
					if(slPduDecoder.decodeUrlString(index) ==  false) {
						Log.w(LOG_TAG, "Received SL push href 0x0C url parse error index at:" + index);
						return false;
					}
					slPduDecoder.href = new String("https://www.") + slPduDecoder.getValueString();
					index += slPduDecoder.getDecodedDataLength();  										
					break;					
				default:
					Log.w(LOG_TAG, "Received SL push not handled tag:0x%x" + SL_tag);
                    return false;
					//break;
			}

        }

		if (mimeType.equals(WspTypeDecoder.CONTENT_MIME_TYPE_B_PUSH_SL_DCD)){
			if (true/*Config.LOGD*/) {
				Log.d(LOG_TAG, "SL_DCD: " + slPduDecoder.href);
			}
			
			Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);//WAP_PUSH_RECEIVED_ACTION
			intent.setType(mimeType);
			intent.putExtra("href", slPduDecoder.href);
			mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");
            return true;			
		}

        if (slPduDecoder.action == slPduDecoder.EXECUTE_CACHE) {
			Log.w(LOG_TAG, "Received SL push not handled when action is cache ");
			return false;
		}

        Log.d(LOG_TAG, "dispatchWapPdu SL mimeType:" + mimeType);
        Log.d(LOG_TAG, "dispatchWapPdu SL pduType:"+pduType);
        Log.d(LOG_TAG, "dispatchWapPdu SL pdu :" + HexDump.toHexString(data));
        Log.d(LOG_TAG, "dispatchWapPdu SL action = " + slPduDecoder.action);
        Log.d(LOG_TAG, "dispatchWapPdu SL CharSet = " + slPduDecoder.CharSet);
        Log.d(LOG_TAG, "dispatchWapPdu SL href = " + slPduDecoder.href);
        Log.d(LOG_TAG, "dispatchWapPdu SL address = " + mOriginatingAddress);    

        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);//WAP_PUSH_RECEIVED_ACTION
        intent.setType(mimeType);
        intent.putExtra("transactionId", transactionId);
        intent.putExtra("pduType", pduType);
        intent.putExtra("data", data);
        intent.putExtra("href", slPduDecoder.href);
        intent.putExtra("action", slPduDecoder.action);
        intent.putExtra("address", mOriginatingAddress);
    
        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");
        return true;
    }
	/* end ZTE_ZMH_CRDB00493582 2010-5-6 */
    /* end ZTE_ZMH_CRDB00504571 2010-06-03 */

	/* ZTE_ZMH_CRDB00493582 2010-5-6 */
    private void dispatchWapPdu_SYNML_NOTIFICATION(byte[] pdu, int transactionId, int pduType, int dataIndex) {
    	if (true/*Config.LOGD*/) {
			Log.d(LOG_TAG, "SYNML_NOTIFICATION: " + IccUtils.bytesToHexString(pdu));
		}
		
        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);//WAP_PUSH_RECEIVED_ACTION
        intent.setType(mimeType);
        intent.putExtra("data", pdu);
        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");

    }
	/* end ZTE_ZMH_CRDB00493582 2010-5-6 */

    /* ZTE_ZMH_2010-05-24 dm used */
    private void dispatchWapPdu_CONNECTIVITY_WBXML(byte[] pdu, int transactionId, int pduType, int dataIndex) {
    	if (true/*Config.LOGD*/) {
			Log.d(LOG_TAG, "CONNECTIVITY_WBXML: " + IccUtils.bytesToHexString(pdu));
		}
		
        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);//WAP_PUSH_RECEIVED_ACTION
        intent.setType(mimeType);
        intent.putExtra("data", pdu);
        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");

    }
	/* end ZTE_ZMH_2010-05-24 dm used */
	
    /* ZTE_ZMH_2010-06-17 email used */
    private void dispatchWapPdu_EMN_WBXML(byte[] pdu, int transactionId, int pduType, int dataIndex) {
    	if (true/*Config.LOGD*/) {
			Log.d(LOG_TAG, "EMN_WBXML: " + IccUtils.bytesToHexString(pdu));
		}
		
        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);//WAP_PUSH_RECEIVED_ACTION
        intent.setType(mimeType);
        intent.putExtra("data", pdu);
        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");

    }
	/* end ZTE_ZMH_2010-06-17 email used */

    /* START ZTE_SMS_PUSH_ZJ, 20110602*/
    private void dispatchWapPdu_B_X_HDML(byte[] pdu, int transactionId, int pduType, int dataIndex) {
    	if (true/*Config.LOGD*/) {
			Log.d(LOG_TAG, "B_X_HDML: " + IccUtils.bytesToHexString(pdu));
	}
		
        Intent intent = new Intent(Intents.WAP_PUSH_RECEIVED_ACTION);//WAP_PUSH_RECEIVED_ACTION
        intent.setType(mimeType);
        intent.putExtra("data", pdu);
        mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_WAP_PUSH");

    }
    /* END ZTE_SMS_PUSH_ZJ, 20110602*/
   	 /* ZTE_HUANGWEI_2011-07-19  139 email configuration used */
    private void dispatchWapPdu_CMCC_WBXML(byte[] pdu, int port,byte[][] pdus) 	{

		if (true/*Config.LOGD*/) {
			Log.d(LOG_TAG, "CMCC_WBXML: " + IccUtils.bytesToHexString(pdu));
		}

		Log.d(LOG_TAG, "-----port: " + port);
		Uri uri = Uri.parse("sms://localhost:"+port);
		Log.d(LOG_TAG, "uri: " + uri);
		
		Intent intent = new Intent(Intents.DATA_SMS_RECEIVED_ACTION);
		
		// intent.setType(mimeType);
		intent.setData(uri);
		intent.putExtra("pdus", pdus);
		
		mSmsDispatcher.dispatch(intent, "android.permission.RECEIVE_SMS");

	}
   		  /* ZTE_HUANGWEI_2011-07-19  139 email configuration used */

}
