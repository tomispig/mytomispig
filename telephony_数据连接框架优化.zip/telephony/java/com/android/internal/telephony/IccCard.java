/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/* ======================================================
when         who        what, where, why                                          comment tag
--------   ----    -------------------------------------    ----------------------------------
2010-12-03   sunyanjun    add PUK unlock supports.             ZTE_PINPUK_SYJ
2010-12-10   wangpingzhi   add PIN2,PUK2  supports.             ZTE_PIN2PUK2_WPZ
2010-01-05   linan              patch pin&pin2 retrynum error      linan_0103
2011-06-23    sunyanjun      Upgrade to Gingerbread                 ZTE_SYJ_20110623
=======================================================*/
package com.android.internal.telephony;

import static android.Manifest.permission.READ_PHONE_STATE;
import android.app.ActivityManagerNative;
import android.content.Intent;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.util.Log;

import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.CommandsInterface.RadioState;
import com.android.internal.telephony.SimLockInfoResult;

/**
 * {@hide}
 */
public abstract class IccCard {
    protected String mLogTag;
    protected boolean mDbg;

    private IccCardStatus mIccCardStatus = null;
    protected State mState = null;
    protected PhoneBase mPhone;
    private RegistrantList mAbsentRegistrants = new RegistrantList();
    private RegistrantList mPinLockedRegistrants = new RegistrantList();
    private RegistrantList mNetworkLockedRegistrants = new RegistrantList();
    private RegistrantList mGetIccCardStatusDoneRegistrants = new RegistrantList();

    private boolean mDesiredPinLocked;
    private boolean mDesiredFdnEnabled;
    private boolean mIccPinLocked = true; // Default to locked
    private boolean mIccFdnEnabled = false; // Default to disabled.
                                            // Will be updated when SIM_READY.

    //ZTE_SYJ_20110623, begin
    //yuanhao add begin,20101104
    public static final int ICC_CARD_TYPE_UNKNOWN = -1;
    public static final int ICC_CARD_TYPE_SIM = 0;
    public static final int ICC_CARD_TYPE_USIM = 1;
    public static final int ICC_CARD_TYPE_RUIM = 2;
    public static final int ICC_CARD_TYPE_CSIM = 3;
    
    private int mIccCardType = ICC_CARD_TYPE_UNKNOWN;
    //yuanhao add end,20101104

    /*ZTE_PINPUK_SYJ, 2010-12-03*/
    /*add*/
    private int mPin1RetryCount = -1;
    private int mPin2RetryCount = -1;
    private int mPuk1RetryCount = -1;
    private int mPuk2RetryCount = -1;
    /*end ZTE_PINPUK_SYJ, 2010-12-03*/
    //ZTE_SYJ_20110623, end

    /* The extra data for broacasting intent INTENT_ICC_STATE_CHANGE */
    static public final String INTENT_KEY_ICC_STATE = "ss";
    /* NOT_READY means the ICC interface is not ready (eg, radio is off or powering on) */
    static public final String INTENT_VALUE_ICC_NOT_READY = "NOT_READY";
    /* ABSENT means ICC is missing */
    static public final String INTENT_VALUE_ICC_ABSENT = "ABSENT";
    /* LOCKED means ICC is locked by pin or by network */
    static public final String INTENT_VALUE_ICC_LOCKED = "LOCKED";
    /* READY means ICC is ready to access */
    static public final String INTENT_VALUE_ICC_READY = "READY";
    /* IMSI means ICC IMSI is ready in property */
    static public final String INTENT_VALUE_ICC_IMSI = "IMSI";
    /* LOADED means all ICC records, including IMSI, are loaded */
    static public final String INTENT_VALUE_ICC_LOADED = "LOADED";
    /* The extra data for broacasting intent INTENT_ICC_STATE_CHANGE */
    static public final String INTENT_KEY_LOCKED_REASON = "reason";
    /* PIN means ICC is locked on PIN1 */
    static public final String INTENT_VALUE_LOCKED_ON_PIN = "PIN";
    /* PUK means ICC is locked on PUK1 */
    static public final String INTENT_VALUE_LOCKED_ON_PUK = "PUK";
    /* NETWORK means ICC is locked on NETWORK PERSONALIZATION */
    static public final String INTENT_VALUE_LOCKED_NETWORK = "NETWORK";
    
    SimLockInfoResult mResultSIMLOCKINFO;

    protected static final int EVENT_ICC_LOCKED_OR_ABSENT = 1;
    private static final int EVENT_GET_ICC_STATUS_DONE = 2;
    protected static final int EVENT_RADIO_OFF_OR_NOT_AVAILABLE = 3;
    private static final int EVENT_PINPUK_DONE = 4;
    private static final int EVENT_REPOLL_STATUS_DONE = 5;
    protected static final int EVENT_ICC_READY = 6;
    private static final int EVENT_QUERY_FACILITY_LOCK_DONE = 7;
    private static final int EVENT_CHANGE_FACILITY_LOCK_DONE = 8;
    private static final int EVENT_CHANGE_ICC_PASSWORD_DONE = 9;
    private static final int EVENT_QUERY_FACILITY_FDN_DONE = 10;
    private static final int EVENT_CHANGE_FACILITY_FDN_DONE = 11;
    //ZTE_SYJ_20110623, begin
    private static final int EVENT_ICC_READY_GET_ICC_STATUS_DONE = 12;
    private static final int EVENT_PIN2PUK2_DONE = 13;

    //yuanhao add begin,20101104
    private static final int EVENT_GET_ICC_CARD_TYPE_DONE = 14;
    //yuanhao add end,20101104

    /*ZTE_PINPUK_SYJ, 2010-12-03*/
    /*add*/
    private static final int EVENT_GET_PINPUK_RETRIES_DONE = 15;
    private boolean mIccPuk1Blocked = false;
 /*ZTE_PIN2PUK2_WPZ, 2010-12-10*/
      private static final int EVENT_SIM_LOCK_INFO_DONE = 16;
 
    private boolean mIccFdnAvailable = true; // Default is enabled.

    private boolean mIccPin2Blocked = false; // Default to disabled.
                                             // Will be updated when sim status changes.
    private boolean mIccPuk2Blocked = false; // Default to disabled.
                                             // Will be updated when sim status changes.
   /*end ZTE_PIN2PUK2_WPZ, 2010-12-10*/
    //ZTE_SYJ_20110623, end

    /*
      UNKNOWN is a transient state, for example, after uesr inputs ICC pin under
      PIN_REQUIRED state, the query for ICC status returns UNKNOWN before it
      turns to READY
     */
    public enum State {
        UNKNOWN,
        ABSENT,
        PIN_REQUIRED,
        PUK_REQUIRED,
        NETWORK_LOCKED,
        READY,
        NOT_READY;

        public boolean isPinLocked() {
            return ((this == PIN_REQUIRED) || (this == PUK_REQUIRED));
        }
    }

    public State getState() {
        if (mState == null) {
            switch(mPhone.mCM.getRadioState()) {
                /* This switch block must not return anything in
                 * State.isLocked() or State.ABSENT.
                 * If it does, handleSimStatus() may break
                 */
                case RADIO_OFF:
                case RADIO_UNAVAILABLE:
                case SIM_NOT_READY:
                case RUIM_NOT_READY:
                    return State.UNKNOWN;
                case SIM_LOCKED_OR_ABSENT:
                case RUIM_LOCKED_OR_ABSENT:
                    //this should be transient-only
                    return State.UNKNOWN;
                case SIM_READY:
                case RUIM_READY:
                case NV_READY:
                    return State.READY;
                case NV_NOT_READY:
                    return State.ABSENT;
            }
        } else {
            return mState;
        }

        Log.e(mLogTag, "IccCard.getState(): case should never be reached");
        return State.UNKNOWN;
    }

    public IccCard(PhoneBase phone, String logTag, Boolean dbg) {
        mPhone = phone;
        mLogTag = logTag;
        mDbg = dbg;
    }

    abstract public void dispose();

    protected void finalize() {
        if(mDbg) Log.d(mLogTag, "IccCard finalized");
    }

    /**
     * Notifies handler of any transition into State.ABSENT
     */
    public void registerForAbsent(Handler h, int what, Object obj) {
        Registrant r = new Registrant (h, what, obj);

        mAbsentRegistrants.add(r);

        if (getState() == State.ABSENT) {
            r.notifyRegistrant();
        }
    }

    public void unregisterForAbsent(Handler h) {
        mAbsentRegistrants.remove(h);
    }

    /**
     * Notifies handler of any transition into State.NETWORK_LOCKED
     */
    public void registerForNetworkLocked(Handler h, int what, Object obj) {
        Registrant r = new Registrant (h, what, obj);

        mNetworkLockedRegistrants.add(r);

        if (getState() == State.NETWORK_LOCKED) {
            r.notifyRegistrant();
        }
    }

    public void unregisterForNetworkLocked(Handler h) {
        mNetworkLockedRegistrants.remove(h);
    }

    /**
     * Notifies handler of any transition into State.isPinLocked()
     */
    public void registerForLocked(Handler h, int what, Object obj) {
        Registrant r = new Registrant (h, what, obj);

        mPinLockedRegistrants.add(r);

        if (getState().isPinLocked()) {
            r.notifyRegistrant();
        }
    }

    public void unregisterForLocked(Handler h) {
        mPinLockedRegistrants.remove(h);
    }

    /**
     * Notifies handler of Get IccCard status done in EVENT_ICC_READY
     */
    public void registerForGetIccCardStatusDone(Handler h, int what, Object obj) {
        Registrant r = new Registrant (h, what, obj);

        mGetIccCardStatusDoneRegistrants.add(r);
    }

    public void unregisterForGetIccCardStatusDone(Handler h) {
        mGetIccCardStatusDoneRegistrants.remove(h);
    }


    /**
     * Supply the ICC PIN to the ICC
     *
     * When the operation is complete, onComplete will be sent to its
     * Handler.
     *
     * onComplete.obj will be an AsyncResult
     *
     * ((AsyncResult)onComplete.obj).exception == null on success
     * ((AsyncResult)onComplete.obj).exception != null on fail
     *
     * If the supplied PIN is incorrect:
     * ((AsyncResult)onComplete.obj).exception != null
     * && ((AsyncResult)onComplete.obj).exception
     *       instanceof com.android.internal.telephony.gsm.CommandException)
     * && ((CommandException)(((AsyncResult)onComplete.obj).exception))
     *          .getCommandError() == CommandException.Error.PASSWORD_INCORRECT
     *
     *
     */

    public void supplyPin (String pin, Message onComplete) {
        mPhone.mCM.supplyIccPin(pin, mHandler.obtainMessage(EVENT_PINPUK_DONE, onComplete));
    }

    public void supplyPuk (String puk, String newPin, Message onComplete) {
        mPhone.mCM.supplyIccPuk(puk, newPin,
                mHandler.obtainMessage(EVENT_PINPUK_DONE, onComplete));
    }

    public void supplyPin2 (String pin2, Message onComplete) {
        //ZTE_SYJ_20110623, begin
        mPhone.mCM.supplyIccPin2(pin2,mHandler.obtainMessage(EVENT_PIN2PUK2_DONE, onComplete));
                /////mHandler.obtainMessage(EVENT_PINPUK_DONE, onComplete));//modify wpz 101210
        //ZTE_SYJ_20110623, end


    }

    public void supplyPuk2 (String puk2, String newPin2, Message onComplete) {
        //ZTE_SYJ_20110623, begin
        mPhone.mCM.supplyIccPuk2(puk2, newPin2,mHandler.obtainMessage(EVENT_PIN2PUK2_DONE, onComplete));
              /////  mHandler.obtainMessage(EVENT_PINPUK_DONE, onComplete)); //modify wpz101210
        //ZTE_SYJ_20110623, end

    }

    public void supplyNetworkDepersonalization (String pin, Message onComplete) {
        if(mDbg) log("Network Despersonalization: " + pin);
        mPhone.mCM.supplyNetworkDepersonalization(pin,
                mHandler.obtainMessage(EVENT_PINPUK_DONE, onComplete));
    }

//ZTE_SYJ_20110623, begin
//add wpz 101210
    /**
     * Check whether fdn (fixed dialing number) service is available.
     * @return true if ICC fdn service available
     *         false if ICC fdn service not available
     */
     public boolean getIccFdnAvailable() {
         return mIccFdnAvailable;
     }
//add end
//ZTE_SYJ_20110623, end

    /**
     * Check whether ICC pin lock is enabled
     * This is a sync call which returns the cached pin enabled state
     *
     * @return true for ICC locked enabled
     *         false for ICC locked disabled
     */
    public boolean getIccLockEnabled() {
        return mIccPinLocked;
     }

    /**
     * Check whether ICC fdn (fixed dialing number) is enabled
     * This is a sync call which returns the cached pin enabled state
     *
     * @return true for ICC fdn enabled
     *         false for ICC fdn disabled
     */
     public boolean getIccFdnEnabled() {
        //ZTE_SYJ_20110623, begin
        Log.d("IccCard","getIccFdnEnabled = "+mIccFdnEnabled);
        //ZTE_SYJ_20110623, end
        return mIccFdnEnabled;
     }

     /**
      * Set the ICC pin lock enabled or disabled
      * When the operation is complete, onComplete will be sent to its handler
      *
      * @param enabled "true" for locked "false" for unlocked.
      * @param password needed to change the ICC pin state, aka. Pin1
      * @param onComplete
      *        onComplete.obj will be an AsyncResult
      *        ((AsyncResult)onComplete.obj).exception == null on success
      *        ((AsyncResult)onComplete.obj).exception != null on fail
      */
     public void setIccLockEnabled (boolean enabled,
             String password, Message onComplete) {
         int serviceClassX;
         serviceClassX = CommandsInterface.SERVICE_CLASS_VOICE +
                 CommandsInterface.SERVICE_CLASS_DATA +
                 CommandsInterface.SERVICE_CLASS_FAX;

         mDesiredPinLocked = enabled;

         mPhone.mCM.setFacilityLock(CommandsInterface.CB_FACILITY_BA_SIM,
                 enabled, password, serviceClassX,
                 mHandler.obtainMessage(EVENT_CHANGE_FACILITY_LOCK_DONE, onComplete));
     }

     /**
      * Set the ICC fdn enabled or disabled
      * When the operation is complete, onComplete will be sent to its handler
      *
      * @param enabled "true" for locked "false" for unlocked.
      * @param password needed to change the ICC fdn enable, aka Pin2
      * @param onComplete
      *        onComplete.obj will be an AsyncResult
      *        ((AsyncResult)onComplete.obj).exception == null on success
      *        ((AsyncResult)onComplete.obj).exception != null on fail
      */
     public void setIccFdnEnabled (boolean enabled,
             String password, Message onComplete) {
         int serviceClassX;
         serviceClassX = CommandsInterface.SERVICE_CLASS_VOICE +
                 CommandsInterface.SERVICE_CLASS_DATA +
                 CommandsInterface.SERVICE_CLASS_FAX +
                 CommandsInterface.SERVICE_CLASS_SMS;

         mDesiredFdnEnabled = enabled;

         mPhone.mCM.setFacilityLock(CommandsInterface.CB_FACILITY_BA_FD,
                 enabled, password, serviceClassX,
                 mHandler.obtainMessage(EVENT_CHANGE_FACILITY_FDN_DONE, onComplete));
     }

     /**
      * Change the ICC password used in ICC pin lock
      * When the operation is complete, onComplete will be sent to its handler
      *
      * @param oldPassword is the old password
      * @param newPassword is the new password
      * @param onComplete
      *        onComplete.obj will be an AsyncResult
      *        ((AsyncResult)onComplete.obj).exception == null on success
      *        ((AsyncResult)onComplete.obj).exception != null on fail
      */
     public void changeIccLockPassword(String oldPassword, String newPassword,
             Message onComplete) {
         if(mDbg) log("Change Pin1 old: " + oldPassword + " new: " + newPassword);
         mPhone.mCM.changeIccPin(oldPassword, newPassword,
                 mHandler.obtainMessage(EVENT_CHANGE_ICC_PASSWORD_DONE, onComplete));

     }

     /**
      * Change the ICC password used in ICC fdn enable
      * When the operation is complete, onComplete will be sent to its handler
      *
      * @param oldPassword is the old password
      * @param newPassword is the new password
      * @param onComplete
      *        onComplete.obj will be an AsyncResult
      *        ((AsyncResult)onComplete.obj).exception == null on success
      *        ((AsyncResult)onComplete.obj).exception != null on fail
      */
     public void changeIccFdnPassword(String oldPassword, String newPassword,
             Message onComplete) {
         if(mDbg) log("Change Pin2 old: " + oldPassword + " new: " + newPassword);
         mPhone.mCM.changeIccPin2(oldPassword, newPassword,
                 mHandler.obtainMessage(EVENT_CHANGE_ICC_PASSWORD_DONE, onComplete));

     }


    /**
     * Returns service provider name stored in ICC card.
     * If there is no service provider name associated or the record is not
     * yet available, null will be returned <p>
     *
     * Please use this value when display Service Provider Name in idle mode <p>
     *
     * Usage of this provider name in the UI is a common carrier requirement.
     *
     * Also available via Android property "gsm.sim.operator.alpha"
     *
     * @return Service Provider Name stored in ICC card
     *         null if no service provider name associated or the record is not
     *         yet available
     *
     */
    public abstract String getServiceProviderName();

    protected void updateStateProperty() {
        mPhone.setSystemProperty(TelephonyProperties.PROPERTY_SIM_STATE, getState().toString());
    }

    private void getIccCardStatusDone(AsyncResult ar) {
        if (ar.exception != null) {
            Log.e(mLogTag,"Error getting ICC status. "
                    + "RIL_REQUEST_GET_ICC_STATUS should "
                    + "never return an error", ar.exception);
            return;
        }
        handleIccCardStatus((IccCardStatus) ar.result);
    }

    private void handleIccCardStatus(IccCardStatus newCardStatus) {
        boolean transitionedIntoPinLocked;
        boolean transitionedIntoAbsent;
        boolean transitionedIntoNetworkLocked;

        State oldState, newState;

        oldState = mState;
        mIccCardStatus = newCardStatus;
        newState = getIccCardState();
        mState = newState;

        updateStateProperty();

        transitionedIntoPinLocked = (
                 (oldState != State.PIN_REQUIRED && newState == State.PIN_REQUIRED)
              || (oldState != State.PUK_REQUIRED && newState == State.PUK_REQUIRED));
        transitionedIntoAbsent = (oldState != State.ABSENT && newState == State.ABSENT);
        transitionedIntoNetworkLocked = (oldState != State.NETWORK_LOCKED
                && newState == State.NETWORK_LOCKED);

        if (transitionedIntoPinLocked) {
            if(mDbg) log("Notify SIM pin or puk locked.");
            mPinLockedRegistrants.notifyRegistrants();
            broadcastIccStateChangedIntent(INTENT_VALUE_ICC_LOCKED,
                    (newState == State.PIN_REQUIRED) ?
                       INTENT_VALUE_LOCKED_ON_PIN : INTENT_VALUE_LOCKED_ON_PUK);
        } else if (transitionedIntoAbsent) {
            if(mDbg) log("Notify SIM missing.");
            mAbsentRegistrants.notifyRegistrants();
            broadcastIccStateChangedIntent(INTENT_VALUE_ICC_ABSENT, null);
        } else if (transitionedIntoNetworkLocked) {
            if(mDbg) log("Notify SIM network locked.");
            mNetworkLockedRegistrants.notifyRegistrants();
            broadcastIccStateChangedIntent(INTENT_VALUE_ICC_LOCKED,
                  INTENT_VALUE_LOCKED_NETWORK);
        }
    }

     //ZTE_SYJ_20110623, begin
    //yuanhao add begin,20101104
    private void getIccCardTypeDone(AsyncResult ar) {
        Log.d(mLogTag, "enter getIccCardTypeDone");
        if (ar.exception != null) {
            Log.e(mLogTag,"Error getting ICC type. "
                    + "ZTE_RIL_REQUEST_GET_SIM_TYPE should "
                    + "never return an error", ar.exception);
            return;
        }
        
        int[] ints = (int[])ar.result;

        Log.d(mLogTag, "ints.length = "+ints.length);
        if (ints.length != 0) {
            mIccCardType = ints[0];
            Log.d(mLogTag, "mIccCardType = "+mIccCardType);
        } else {
            Log.e(mLogTag, "bad result of getIccCardType");
        }
    }

    //these interface for app
    public int getIccCardType() {
        Log.d(mLogTag, "enter getIccCardType");
        Log.d(mLogTag, "mIccCardType = "+mIccCardType);
        return mIccCardType;
    }

    public void doSimAuth (String rand, Message result) {
        Log.d(mLogTag, "enter doSimAuth");
        mPhone.mCM.doSimAuth(rand, result);
    }

    public void doUsimAuth (String rand, String autn, Message result) {
        Log.d(mLogTag, "enter doUsimAuth");
        mPhone.mCM.doUsimAuth(rand, autn, result);
    }

    public void getLacCid( int BDSType, Message result) {
        log("enter getLacCid");
        mPhone.mCM.getLacCid(BDSType, result);
        return;
    }
    //yuanhao add end,20101104
    //ZTE_SYJ_20110623, end

    /**
     * Interperate EVENT_QUERY_FACILITY_LOCK_DONE
     * @param ar is asyncResult of Query_Facility_Locked
     */
    private void onQueryFdnEnabled(AsyncResult ar) {
        if(ar.exception != null) {
            if(mDbg) log("Error in querying facility lock:" + ar.exception);
            return;
        }

        int[] ints = (int[])ar.result;
        if(ints.length != 0) {
            //ZTE_SYJ_20110623, begin
            if (ints[0] != 2) {
            mIccFdnEnabled = (0!=ints[0]);
                mIccFdnAvailable = true;
            } else {
                if(mDbg) log("Query facility lock: FDN Service Unavailable!");
                mIccFdnAvailable = false;
                mIccFdnEnabled = false;
            }
            if(mDbg) log("Query facility lock for FDN : "  + mIccFdnEnabled);
            //ZTE_SYJ_20110623, end
        } else {
            Log.e(mLogTag, "[IccCard] Bogus facility lock response");
        }
    }

    /**
     * Interperate EVENT_QUERY_FACILITY_LOCK_DONE
     * @param ar is asyncResult of Query_Facility_Locked
     */
    private void onQueryFacilityLock(AsyncResult ar) {
        if(ar.exception != null) {
            if (mDbg) log("Error in querying facility lock:" + ar.exception);
            return;
        }

        int[] ints = (int[])ar.result;
        if(ints.length != 0) {
            mIccPinLocked = (0!=ints[0]);
            if(mDbg) log("Query facility lock : "  + mIccPinLocked);
        } else {
            Log.e(mLogTag, "[IccCard] Bogus facility lock response");
        }
    }

    public void broadcastIccStateChangedIntent(String value, String reason) {
        Intent intent = new Intent(TelephonyIntents.ACTION_SIM_STATE_CHANGED);
        intent.addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);
        intent.putExtra(Phone.PHONE_NAME_KEY, mPhone.getPhoneName());
        intent.putExtra(INTENT_KEY_ICC_STATE, value);
        intent.putExtra(INTENT_KEY_LOCKED_REASON, reason);
        if(mDbg) log("Broadcasting intent ACTION_SIM_STATE_CHANGED " +  value
                + " reason " + reason);
        ActivityManagerNative.broadcastStickyIntent(intent, READ_PHONE_STATE);
    }

    //ZTE_SYJ_20110623, begin
    /**
     * Parse the error response to obtain No of attempts remaining to unlock PIN adn PUK
     */
    private void parsePinPukErrorResult(AsyncResult ar) {
        int[] intArray = (int[]) ar.result;
        mPin1RetryCount = intArray[0];
        mPin2RetryCount = intArray[1];
        mPuk1RetryCount = intArray[2];
        mPuk2RetryCount = intArray[3];
        log("In parsePinPukErrorResult mPin1RetryCount = " + mPin1RetryCount +
            "mPin2RetryCount = " + mPin2RetryCount +
            "mPuk1RetryCount = " + mPuk1RetryCount +
            "mPuk2RetryCount = " + mPuk2RetryCount);
    }
    //ZTE_SYJ_20110623, end

    protected Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg){
            AsyncResult ar;
            int serviceClassX;

            serviceClassX = CommandsInterface.SERVICE_CLASS_VOICE +
                            CommandsInterface.SERVICE_CLASS_DATA +
                            CommandsInterface.SERVICE_CLASS_FAX;
            //ZTE_SYJ_20110623, begin
            log("++++++++++++wpz+++++msg.what++++"+msg.what);
            //ZTE_SYJ_20110623, end
            switch (msg.what) {
                case EVENT_RADIO_OFF_OR_NOT_AVAILABLE:
                    mState = null;
                    updateStateProperty();
                    broadcastIccStateChangedIntent(INTENT_VALUE_ICC_NOT_READY, null);
                    break;
                case EVENT_ICC_READY:
                    //TODO: put facility read in SIM_READY now, maybe in REG_NW
                    //ZTE_SYJ_20110623, begin
			        /*ZTE_PINPUK_SYJ, 2010-12-03*/
			        /*add*/
			        getPinPukRetries();
			        log("EVENT_ICC_READY ");
			        /*end ZTE_PINPUK_SYJ, 2010-12-03*/
                    //ZTE_SYJ_20110623, end
                    mPhone.mCM.getIccCardStatus(obtainMessage(EVENT_ICC_READY_GET_ICC_STATUS_DONE));
                    //ZTE_SYJ_20110623, begin
                    //yuanhao add begin,20101104
                    mPhone.mCM.getSimType(obtainMessage(EVENT_GET_ICC_CARD_TYPE_DONE));
                    //yuanhao add end,20101104
                    //ZTE_SYJ_20110623, end

                    mPhone.mCM.queryFacilityLock (
                            CommandsInterface.CB_FACILITY_BA_SIM, "", serviceClassX,
                            obtainMessage(EVENT_QUERY_FACILITY_LOCK_DONE));
                    mPhone.mCM.queryFacilityLock (
                            CommandsInterface.CB_FACILITY_BA_FD, "", serviceClassX,
                            obtainMessage(EVENT_QUERY_FACILITY_FDN_DONE));
                    break;
                case EVENT_ICC_LOCKED_OR_ABSENT:
                    //ZTE_SYJ_20110623, begin
			        /*ZTE_PINPUK_SYJ, 2010-12-03*/
			        /*add*/
			        getPinPukRetries();
                    log("EVENT_ICC_LOCKED_OR_ABSENT getPinPukRetries() called");
			        /*end ZTE_PINPUK_SYJ, 2010-12-03*/
                    //ZTE_SYJ_20110623, end
                    mPhone.mCM.getIccCardStatus(obtainMessage(EVENT_GET_ICC_STATUS_DONE));
                    mPhone.mCM.queryFacilityLock (
                            CommandsInterface.CB_FACILITY_BA_SIM, "", serviceClassX,
                            obtainMessage(EVENT_QUERY_FACILITY_LOCK_DONE));
                    break;
                case EVENT_ICC_READY_GET_ICC_STATUS_DONE:
                case EVENT_GET_ICC_STATUS_DONE:
                    ar = (AsyncResult)msg.obj;

                    getIccCardStatusDone(ar);

                    if(msg.what == EVENT_ICC_READY_GET_ICC_STATUS_DONE) {
                        mGetIccCardStatusDoneRegistrants.notifyRegistrants();
                    }
                    break;
                //ZTE_SYJ_20110623, begin
			    /*ZTE_PINPUK_SYJ, 2010-12-03*/
                /*add*/
                case EVENT_GET_PINPUK_RETRIES_DONE:
                    ar = (AsyncResult)msg.obj;
                    //synchronized (mLock) {
    					if(ar != null && ar.result !=null && (ar.exception == null)) {
                            int[] intArray = (int[]) ar.result;
                            mPin1RetryCount = intArray[0];
                            mPin2RetryCount = intArray[1];
                            mPuk1RetryCount = intArray[2];
                            mPuk2RetryCount = intArray[3];
                            log("In parsePinPukErrorResult mPin1RetryCount = " + mPin1RetryCount +
                                "mPin2RetryCount = " + mPin2RetryCount +
                                "mPuk1RetryCount = " + mPuk1RetryCount +
                                "mPuk2RetryCount = " + mPuk2RetryCount);
                            //mLock.notifyAll();
                        }
                    //}
                    break;
			    /*end ZTE_PINPUK_SYJ, 2010-12-03*/
                //ZTE_SYJ_20110623, end
                case EVENT_PINPUK_DONE:
                //ZTE_SYJ_20110623, begin
                case EVENT_PIN2PUK2_DONE://add wpz 101210
                //ZTE_SYJ_20110623, end
                    // a PIN/PUK/PIN2/PUK2/Network Personalization
                    // request has completed. ar.userObj is the response Message
                    // Repoll before returning
                    ar = (AsyncResult)msg.obj;
                    // TODO should abstract these exceptions
                    AsyncResult.forMessage(((Message)ar.userObj)).exception
                                                        = ar.exception;
                //ZTE_SYJ_20110623, begin
                    log("ar.exception="+ar.exception+"ar.result"+ar.result);
					
		    if ((ar.exception != null) && (ar.result != null)) {
			   log(" +++++++++parsePinPukErrorResult(ar)");
                        parsePinPukErrorResult(ar);
                    }
			else
			{
				   
			    log(" ++++++++++getPinPukRetries(ar)");
                         getPinPukRetries();
			}
                ((AsyncResult)((Message)ar.userObj).obj).result = ar.result;//ZTE_PINPUK_XUYANG_001 ZTE_ZB_MERGE_5310_002
                //ZTE_SYJ_20110623, end
                    mPhone.mCM.getIccCardStatus(
                        obtainMessage(EVENT_REPOLL_STATUS_DONE, ar.userObj));
                    break;
                case EVENT_REPOLL_STATUS_DONE:
                    // Finished repolling status after PIN operation
                    // ar.userObj is the response messaeg
                    // ar.userObj.obj is already an AsyncResult with an
                    // appropriate exception filled in if applicable

                    ar = (AsyncResult)msg.obj;
                    getIccCardStatusDone(ar);
                    ((Message)ar.userObj).sendToTarget();
                    break;
                case EVENT_QUERY_FACILITY_LOCK_DONE:
                    ar = (AsyncResult)msg.obj;
                    onQueryFacilityLock(ar);
                    break;
                case EVENT_QUERY_FACILITY_FDN_DONE:
                    ar = (AsyncResult)msg.obj;
                    onQueryFdnEnabled(ar);
                    break;
                case EVENT_CHANGE_FACILITY_LOCK_DONE:
                    ar = (AsyncResult)msg.obj;
                    if (ar.exception == null) {
                        mIccPinLocked = mDesiredPinLocked;
                        if (mDbg) log( "EVENT_CHANGE_FACILITY_LOCK_DONE: " +
                                "mIccPinLocked= " + mIccPinLocked);
//ZTE_SYJ_20110623, begin
//linan_0103,start
                    mPin1RetryCount=3;
//linan_0103,end
//ZTE_SYJ_20110623, end
                    } else {
//ZTE_SYJ_20110623, begin
                        if (ar.result != null) {
                            parsePinPukErrorResult(ar);
                        }
//ZTE_SYJ_20110623, end
                        Log.e(mLogTag, "Error change facility lock with exception "
                            + ar.exception);
                    }
                    AsyncResult.forMessage(((Message)ar.userObj)).exception
                                                        = ar.exception;
                    ((Message)ar.userObj).sendToTarget();
                    break;
                case EVENT_CHANGE_FACILITY_FDN_DONE:
                    ar = (AsyncResult)msg.obj;

                    if (ar.exception == null) {
                        mIccFdnEnabled = mDesiredFdnEnabled;
                        //ZTE_SYJ_20110623, begin
                        Log.d("IccCard","EVENT_CHANGE_FACILITY_FDN_DONE = mIccFdnEnabled"+mIccFdnEnabled);
                        Log.d("IccCard","EVENT_CHANGE_FACILITY_FDN_DONE = mDesiredFdnEnabled"+mDesiredFdnEnabled);
                        //ZTE_SYJ_20110623, end
                        if (mDbg) log("EVENT_CHANGE_FACILITY_FDN_DONE: " +
                                "mIccFdnEnabled=" + mIccFdnEnabled);
//ZTE_SYJ_20110623, begin
//linan_0103,start
                       mPin2RetryCount = 3;
//linan_0103,end
//ZTE_SYJ_20110623, end
                    } else {
                        //ZTE_SYJ_20110623, begin
                        if (ar.result != null) {
                            parsePinPukErrorResult(ar);
                        }
                        //ZTE_SYJ_20110623, end
                        Log.e(mLogTag, "Error change facility fdn with exception "
                                + ar.exception);
                    }
                    AsyncResult.forMessage(((Message)ar.userObj)).exception
                                                        = ar.exception;
                    ((Message)ar.userObj).sendToTarget();
                    break;
                case EVENT_CHANGE_ICC_PASSWORD_DONE:
                    ar = (AsyncResult)msg.obj;
//ZTE_SYJ_20110623, begin
//linan_0103,start
                    if (ar.exception == null) {
                        if (mDbg) log( "EVENT_CHANGE_ICC_PASSWORD_DONE" );
                    getPinPukRetries();
                    } else {
//linan_0103,end
//ZTE_SYJ_20110623, end
                    if(ar.exception != null) {
                        Log.e(mLogTag, "Error in change sim password with exception"
                            + ar.exception);
                        //ZTE_SYJ_20110623, begin
                        if (ar.result != null) {
                            parsePinPukErrorResult(ar);
                    }
                        //ZTE_SYJ_20110623, end
                    }
//ZTE_SYJ_20110623, begin
//linan_0103,start
                }
//linan_0103,end
//ZTE_SYJ_20110623, end
                    AsyncResult.forMessage(((Message)ar.userObj)).exception
                                                        = ar.exception;
                    ((Message)ar.userObj).sendToTarget();
                    break;
                //ZTE_SYJ_20110623, begin
                //yuanhao add begin,20101104
                case EVENT_GET_ICC_CARD_TYPE_DONE:
                    ar = (AsyncResult)msg.obj;

                    getIccCardTypeDone(ar);
                    break;
                //yuanhao add end,20101104
                //ZTE_SYJ_20110623, end
                case EVENT_SIM_LOCK_INFO_DONE:
                    Log.i(mLogTag,"EVENT_SIM_LOCK_INFO_DONE");
                    Log.d("IccCard","---> EVENT_SIM_LOCK_INFO_DONE ");
                    ar = (AsyncResult)msg.obj;
                    if (ar.exception != null) {
                        Log.e(mLogTag,"Error in get SIM LOCK INFO" + ar.exception);
                        return;
                    }
                    else {
                        mResultSIMLOCKINFO = (SimLockInfoResult) ar.result;
                    }
                    break;
                default:
                    Log.d("IccCard","[IccCard] Unknown Event " + msg.what);
                    Log.e(mLogTag, "[IccCard] Unknown Event " + msg.what);
            }
        }
    };

    public State getIccCardState() {
        if (mIccCardStatus == null) {
            Log.e(mLogTag, "[IccCard] IccCardStatus is null");
            return IccCard.State.ABSENT;
        }

        // this is common for all radio technologies
        if (!mIccCardStatus.getCardState().isCardPresent()) {
            return IccCard.State.ABSENT;
        }

        RadioState currentRadioState = mPhone.mCM.getRadioState();
        // check radio technology
        if( currentRadioState == RadioState.RADIO_OFF         ||
            currentRadioState == RadioState.RADIO_UNAVAILABLE ||
            currentRadioState == RadioState.SIM_NOT_READY     ||
            currentRadioState == RadioState.RUIM_NOT_READY    ||
            currentRadioState == RadioState.NV_NOT_READY      ||
            currentRadioState == RadioState.NV_READY) {
            return IccCard.State.NOT_READY;
        }

        if( currentRadioState == RadioState.SIM_LOCKED_OR_ABSENT  ||
            currentRadioState == RadioState.SIM_READY             ||
            currentRadioState == RadioState.RUIM_LOCKED_OR_ABSENT ||
            currentRadioState == RadioState.RUIM_READY) {

            int index;

            // check for CDMA radio technology
            if (currentRadioState == RadioState.RUIM_LOCKED_OR_ABSENT ||
                currentRadioState == RadioState.RUIM_READY) {
                index = mIccCardStatus.getCdmaSubscriptionAppIndex();
            }
            else {
                index = mIccCardStatus.getGsmUmtsSubscriptionAppIndex();
            }

            IccCardApplication app = mIccCardStatus.getApplication(index);

            if (app == null) {
                Log.e(mLogTag, "[IccCard] Subscription Application in not present");
                return IccCard.State.ABSENT;
            }

           //ZTE_SYJ_20110623, begin
//add ZTE_PIN2PUK2_WPZ, 2010-12-10
            Log.i(mLogTag, "PIN1 Status " + app.pin1 + "PIN2 Status " + app.pin2);
            if (getIccPin2RetryCount()==0) {
                Log.i(mLogTag, "PIN2 is blocked, PUK2 required.");
                mIccPin2Blocked = true;
                mIccPuk2Blocked = false;
            }  else {
                Log.i(mLogTag, "Neither PIN2 nor PUK2 is blocked.");
                mIccPin2Blocked = false;
                mIccPuk2Blocked = false;
            }
	     if (getIccPuk2RetryCount()==0) {
                Log.i(mLogTag, "PUK2 is permanently blocked.");
                mIccPuk2Blocked = true;
                mIccPin2Blocked = false;
            }
///add end ZTE_PIN2PUK2_WPZ, 2010-12-10

            /*ZTE_PINPUK_SYJ, 2010-12-03*/
            /*add*/
            if (app.pin1 == 5) {//5 presents PINSTATE_ENABLED_PERM_BLOCKED
                Log.i(mLogTag, "liuji ****** PUK1 is blocked");
                mIccPuk1Blocked = true;
            } else {
                mIccPuk1Blocked = false;
                Log.i(mLogTag, "liuji ****** PUK1 is not blocked");
            }
            /*end ZTE_PINPUK_SYJ, 2010-12-03*/
            //ZTE_SYJ_20110623, end

            // check if PIN required
            if (app.app_state.isPinRequired()) {
                return IccCard.State.PIN_REQUIRED;
            }
            if (app.app_state.isPukRequired()) {
                return IccCard.State.PUK_REQUIRED;
            }
            if (app.app_state.isSubscriptionPersoEnabled()) {
                return IccCard.State.NETWORK_LOCKED;
            }
            if (app.app_state.isAppReady()) {
                return IccCard.State.READY;
            }
            if (app.app_state.isAppNotReady()) {
                return IccCard.State.NOT_READY;
            }
            return IccCard.State.NOT_READY;
        }

        return IccCard.State.ABSENT;
    }


    public boolean isApplicationOnIcc(IccCardApplication.AppType type) {
        if (mIccCardStatus == null) return false;

        for (int i = 0 ; i < mIccCardStatus.getNumApplications(); i++) {
            IccCardApplication app = mIccCardStatus.getApplication(i);
            if (app != null && app.app_type == type) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return true if a ICC card is present
     */
    public boolean hasIccCard() {
        boolean isIccPresent;
        if (mPhone.getPhoneName().equals("GSM")) {
            return mIccCardStatus.getCardState().isCardPresent();
        } else {
            // TODO: Make work with a CDMA device with a RUIM card.
            return false;
        }
    }

    //ZTE_SYJ_20110623, begin
    /*ZTE_PINPUK_SYJ, 2010-12-03*/
    /*add*/
    public boolean getIccPuk1Blocked() {
        return mIccPuk1Blocked;
    }
    /*end ZTE_PINPUK_SYJ, 2010-12-03*/
	    /*ZTE_PIN2PUK2_WPZ, 2010-12-10*/
    /*add*/
    /**
     * @return true if ICC card is PIN2 blocked
     */
    public boolean getIccPin2Blocked() {
        return mIccPin2Blocked;
    }


    public boolean getIccPuk2Blocked() {
        return mIccPuk2Blocked;
    }
    /*end ZTE_PIN2PUK2_WPZ, 2010-12-1*/

    /*ZTE_PINPUK_SYJ, 2010-12-03*/
    /*add*/
    public void getPinPukRetries () {
        mPhone.mCM.getIccPinPukRetries(mHandler.obtainMessage(EVENT_GET_PINPUK_RETRIES_DONE));
    }

   /**
     * @return No. of Attempts remaining to unlock PIN1
     */
    public int getIccPin1RetryCount() {
        /*synchronized(mLock) {
            try {
                //log("into getPinPukRetries()");
                getPinPukRetries();
                mLock.wait();
                //log("out getPinPukRetries()");
            } catch (InterruptedException e) {
                log("interrupted while trying to getPinPukRetries");
            }
        }*/
        //log("syj getIccPin1RetryCount() is done, will return mPin1RetryCount");
        log("mPin1RetryCount = " + mPin1RetryCount);
	    return mPin1RetryCount;
    }

   /**
     * @return No. of Attempts remaining to unlock PUK1
     */
    public int getIccPuk1RetryCount() {
       /* synchronized(mLock) {
            try {
                //log("into getPinPukRetries()");
                getPinPukRetries();
                mLock.wait();
                //log("out getPinPukRetries()");
            } catch (InterruptedException e) {
                log("interrupted while trying to getPinPukRetries");
            }
        }*/
        //log("syj getIccPuk1RetryCount() is done, will return mPin1RetryCount");
        log("mPuk1RetryCount = " + mPuk1RetryCount);
	    return mPuk1RetryCount;
    }

   /**
     * @return No. of Attempts remaining to unlock PIN2
     */
    public int getIccPin2RetryCount() {
        /*synchronized(mLock) {
            try {
                //log("into getPinPukRetries()");
                getPinPukRetries();
                mLock.wait();
                //log("out getPinPukRetries()");
            } catch (InterruptedException e) {
                log("interrupted while trying to getPinPukRetries");
            }
        }*/
        //log("syj getIccPin2RetryCount() is done, will return mPin1RetryCount");
         log("mPin2RetryCount"+mPin2RetryCount);
	    return mPin2RetryCount;
    }

   /**
     * @return No. of Attempts remaining to unlock PUK2
     */
    public int getIccPuk2RetryCount() {
        /*synchronized(mLock) {
            try {
                //log("into getPinPukRetries()");
                getPinPukRetries();
                mLock.wait();
                //log("out getPinPukRetries()");
            } catch (InterruptedException e) {
                log("interrupted while trying to getPinPukRetries");
            }
        }*/
        //log("syj getIccPuk2RetryCount() is done, will return mPin1RetryCount");
          log("mPuk2RetryCount"+mPuk2RetryCount);
	    return mPuk2RetryCount;
    }
    /*end ZTE_PINPUK_SYJ, 2010-12-03*/
    //ZTE_SYJ_20110623, end

    private void log(String msg) {
        Log.d(mLogTag, "[IccCard] " + msg);
    }

    //ZTE_SYJ_20110623, begin
    //yuanhao add begin,20101116
    public void setFacilityLock (String facility, 
                                 boolean lockState, 
                                 String password,
                                 int serviceClass,
                                 Message response) {
        mPhone.mCM.setFacilityLock(facility, lockState, password, 
                                            serviceClass, response);
    }
    
    public void queryFacilityLock (String facility, 
                                    String password, 
                                    int serviceClass,
                                    Message onComplete) {
        mPhone.mCM.queryFacilityLock(facility, password, serviceClass, onComplete);
    }
    
    public void changeBarringPassword(String facility, 
                                        String oldPwd, 
                                        String newPwd, 
                                        Message result) {
        mPhone.mCM.changeBarringPassword(facility, oldPwd, newPwd, result);
    }
    //yuanhao add end,20101116
    //ZTE_SYJ_20110623, end

    public SimLockInfoResult
    getSimLockInfoResult() {
        try{
            mPhone.mCM.getSIMLockInfo(mHandler.obtainMessage(EVENT_SIM_LOCK_INFO_DONE));
            Thread.sleep(400);// FIX ME. It should be sent after information is updated. 
        }
        catch (InterruptedException e){
            ;
        }
        return mResultSIMLOCKINFO;
    }
}
