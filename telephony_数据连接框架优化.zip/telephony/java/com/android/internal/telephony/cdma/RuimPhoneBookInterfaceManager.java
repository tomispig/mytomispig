/*
** Copyright 2007, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

package com.android.internal.telephony.cdma;

import android.os.Message;
import android.util.Log;

import com.android.internal.telephony.IccPhoneBookInterfaceManager;

//add by liandongzhou for 3g file id 20101207
import com.android.internal.telephony.IccConstants;
//end add by liandongzhou for 3g file id 20101207
/**
 * RuimPhoneBookInterfaceManager to provide an inter-process communication to
 * access ADN-like SIM records.
 */


public class RuimPhoneBookInterfaceManager extends IccPhoneBookInterfaceManager {
    static final String LOG_TAG = "CDMA";

    public RuimPhoneBookInterfaceManager(CDMAPhone phone) {
        super(phone);
        adnCache = phone.mRuimRecords.getAdnCache();
        //NOTE service "simphonebook" added by IccSmsInterfaceManagerProxy
    }

    public void dispose() {
        super.dispose();
    }

    protected void finalize() {
        try {
            super.finalize();
        } catch (Throwable throwable) {
            Log.e(LOG_TAG, "Error while finalizing:", throwable);
        }
        if(DBG) Log.d(LOG_TAG, "RuimPhoneBookInterfaceManager finalized");
    }

    public int[] getAdnRecordsSize(int efid) {
        if (DBG) logd("getAdnRecordsSize: efid=" + efid);
        synchronized(mLock) {
            checkThread();
            recordSize = new int[3];

            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);

            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the RUIM");
            }
        }

        return recordSize;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_018 20101205 begin*/
    public int getSimTotalSize(int efid) {
        Log.d("GSM","MY getAdnTotalSize.......="+getAdnTotalSize(efid));
	    return getAdnTotalSize(efid);
    }
    public int getExtensionSize(int efid) {
	return getExt1Size(efid);
    }
/*ZTE_CONTACTS_LIANDONGZHOU_018 20101205 end*/
/*ZTE_CONTACTS_MAOYING_013 2010-06-25 end*/
    public int getSimSize(int efid) {
	return getAdnSize(efid);
            }
    public int getUsimSize(int efid) {
	return getUsimAdnSize();
        }
    public int getUsimAdnRecordsSize(int efid) {;
        return getPbrFileld();
    }
    public int getTagRecordsSize(int efid) {
	    int recordAdnSize;
        if (DBG) logd("getTagRecordsSize: efid=" + efid);
	    //add by liandongzhou for 3g file id 20101207
	    if (efid == IccConstants.EF_ADN) {
                efid =  IccConstants.EF_PBR;
            }
	    //end add by liandongzhou for 3g file id 20101207
        synchronized(mLock) {
            checkThread();
            recordSize = new int[3];
			
            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);

            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the RUIM");
            }
        }
	// modify by liandongzhou for sometimes recordSize[0]  = 0 20101211
	if(recordSize != null && recordSize[0] > 14){
            recordAdnSize = recordSize[0]-14;
	}
	else{recordAdnSize = 14;} 
	// modify by liandongzhou for sometimes recordSize[0]  = 0 20101211		
        return recordAdnSize;
    }
      public int getEmailRecordsSize(int efid) {
	int recordEmailSize;
        if (DBG) logd("getEmailRecordsSize: efid=" + efid);
        synchronized(mLock) {
            checkThread();
            recordSize = new int[3];
            // modify by liandongzhou for cannot read email fileId. 20110311
			//
            // 4 is the empirical data, the general range of TD documents up to 4, w, only two,
            //and email in the second partition, so only one here before. If the partition is not more than 2, 
            //and have not found the two in efid, to partition 3 does not exist, the method in a direct return, not an error.     
           for (int i = 0; i < 4; i++){
               efid = getGetEmailFileld(i);
               if (DBG) logd("for getGetEmailFileld: efid=" + efid);                
               if(efid != 0)break;   
           }       

//           efid = getGetEmailFileld(1);
            // end modify by liandongzhou for cannot read email fileId. 20110311
            
            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);
            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the SIM");
            }
        }
	// modify by liandongzhou for sometimes recordSize[0]  = 0 20101214		
	if(recordSize != null && recordSize[0] > 2)		
		recordEmailSize = recordSize[0]-2;
	else{recordEmailSize = 40;}  	//after exception , we need normal length for email, general,it is 40.	20110311
	// modify by liandongzhou for sometimes recordSize[0]  = 0 20101214	
        return recordEmailSize;
    }
    public int getAnrRecordsSize(int efid) {
	int recordAnrSize;
        if (DBG) logd("getAnrRecordsSize: efid=" + efid);
        synchronized(mLock) {
            checkThread();
            recordSize = new int[3];
            //modify by liandongzhou for cannot read email fileId. 20110311
            //
            // 4 is the empirical data, the general range of TD documents up to 4, w, only two,
            //and email in the second partition, so only one here before. If the partition is not more than 2, 
            //and have not found the two in efid, to partition 3 does not exist, the method in a direct return, not an error.

            for (int i = 0; i < 4; i++){
                efid = getGetAnrFileld(i);
                if (DBG) logd("for getGetEmailFileld: efid=" + efid);                
                if(efid != 0)break;   
            }				
//            efid = getGetAnrFileld(1);
            // end modify by liandongzhou for cannot read email fileId. 20110311

            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);

            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the SIM");
            }
        }
	recordAnrSize = 10;
        return recordAnrSize;
    }
/*ZTE_LIANDONGZHOU_USIM 20101205 begin*/
      public boolean isSupportUsim() {
            return getIsSupUsim();
    }
      public boolean isSupportANR() {
            return getIsSupANR();
    }
      public boolean isSupportEmail() {
            return getIsSupEmail();
    }

/*ZTE_LIANDONGZHOU_USIM 20101205 end*/

//add by liandongzhou for td some cards not support sne(c3), 20110101
      public boolean isSupportSne() {
            return getIsSupSNE();
    }
//end add by liandongzhou for td some cards not support sne(c3), 20110101	  

//add by liandongzhou for td need the second the third number 20101223
    public int getAdditionalNumberCount(){
        Log.d("ZLian", "TDS_CDMA: getAdditionalNumberCount is run.");    
        if(getIsSupANR3())return 3;
        if(getIsSupANR2())return 2;
        if(getIsSupANR())return 1;	
	return 0;
    }
//end add by liandongzhou for td need the second the third number 20101223

/*ZTE_CONTACTS_MAOYING_007 2010-05-27 end*/
    protected void logd(String msg) {
        Log.d(LOG_TAG, "[RuimPbInterfaceManager] " + msg);
    }

    protected void loge(String msg) {
        Log.e(LOG_TAG, "[RuimPbInterfaceManager] " + msg);
    }
}

