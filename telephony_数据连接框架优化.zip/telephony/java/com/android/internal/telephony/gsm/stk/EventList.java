/******************************************************************************
 * *(C) Copyright 2010 Marvell International Ltd.
 * * All Rights Reserved
 * * Author Linda follow 3GPP TS 11.14 V8.18.0 (2007-06)
 * ******************************************************************************/

package com.android.internal.telephony.gsm.stk;

import android.os.Parcel;
import android.os.Parcelable;
/**
 * Enumeration for the proactive SIM commands SET UP EVENTLIST
 * To get each enum value
 *
 * {@hide}
 */
public enum EventList {
    /** MT Call */
    MT_CALL(0x00),
    
    /** Call connected */
    CALL_CONNECTED(0x01),

    /** Call disconnected */
    CALL_DISCONNECTED(0x02),

    /** Location status */
    LOCATION_SATATUS(0x03),

    /** User activity */
    USER_ACTIVITY(0x04),

    /** Idle screen availabe */
    IDLE_SCREEN_AVAILABLE(0x05),

    /** Card reader status (if class "a" is supported) */
    CARD_READER_STATUS(0x06),

    /** Language selection */
    LANGUAGE_SELECTION(0x07),

    /** Brower Termination (if class "c" is supported) */
    BROWER_TERMINATION(0x08),

    /** Data available (if class "e" is supported) */
    DATA_ABAILABLE(0x09),

    /** Channel status (if class "e" is supported) */
    CHANNEL_STATUS(0x0A),

    //TS 102.223 section 8.25
    SINGLE_ACCESS_TECHNOLOGY_CHANGE(0x0B),
    DISPLAY_PARAMETERS_CHANGED(0x0C),
    LOCAL_CONNECTION(0x0D),
    NETWORK_SEARCH_MODE_CHANGE(0x0E),
    BROWSING_STATUS(0x0F),
    FRAMES_INFORMATION_CHANGE(0x10),
    //RESERVED_FOR_I_WLAN_ACCESS_STATUS(0x11);
    //RESERVED_FOR_NETWORK_REJECTION(0x12);
    HCI_CONNECTIVITY_EVENT(0x13),
    MULTIPLE_ACCESS_TECHNOLOGY_CHANGE(0x14),
    REMOVE_EVENT(0x15);
    private int mValue;

    EventList(int value) {
    mValue = value;
    }

    public int value() {
        return mValue;
    }

    public static EventList fromInt(int value) {
        for (EventList r: EventList.values()) {
            if(r.mValue == value) {
                return r;
            }
        }
        return null;
    }
}
