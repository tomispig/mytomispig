/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony.gsm.stk;

/**
 * Interface for communication between STK App and STK Telephony
 *
 * {@hide}
 */
public interface AppInterface {

    /*
     * Intent's actions which are broadcasted by the Telephony once a new STK
     * proactive command, session end arrive.
     */
    public static final String STK_CMD_ACTION =
                                    "android.intent.action.stk.command";
    public static final String STK_SESSION_END_ACTION =
                                    "android.intent.action.stk.session_end";
    public static final String STK_SCREEN_BUSY =
                                    "android.intent.action.stk.screen_busy";
    public static final String STK_LANGUAGE_SETTING =
                                    "android.intent.action.stk.languages_setting";
    public static final String STK_EVENT_LIST_LANGUAGE_SELECT =
                                    "android.intent.action.stk.even_list_languages_select";
    public static final String STK_CALL_CONNECTED_EVENT =
                                    "android.intent.action.stk.call_connected_event";
    public static final String STK_EVENT_LIST_CALL_CONNECTED =
                                    "android.intent.action.stk.event_list_call_connected";
    public static final String STK_EVENT_REMOVE_EVENT =
                                    "android.intent.action.stk.event_remove_event";
    public static final String STK_EVENT_SEND_SM_STATUS = 
                                    "android.intent.action.stk.event_send_sm_status";

    /*
     * Callback function from app to telephony to pass a result code and user's
     * input back to the SIM.
     */
    void onCmdResponse(StkResponseMessage resMsg);

    /*
     * Callback function from app to telephony to pass a event download to the SIM.
     */
    void onEventResponse(StkResponseMessage resMsg);

    /*
     * Enumeration for representing "Type of Command" of proactive commands.
     * Those are the only commands which are supported by the Telephony. Any app
     * implementation should support those.
     */
    public static enum CommandType {
        DISPLAY_TEXT(0x21),
        GET_INKEY(0x22),
        GET_INPUT(0x23),
        LAUNCH_BROWSER(0x15),
        PLAY_TONE(0x20),
        REFRESH(0x01),
        SELECT_ITEM(0x24),
        SEND_SS(0x11),
        SEND_USSD(0x12),
        SEND_SMS(0x13),
        SEND_DTMF(0x14),
        SET_UP_EVENT_LIST(0x05),
        SET_UP_IDLE_MODE_TEXT(0x28),
        SET_UP_MENU(0x25),
        SET_UP_CALL(0x10),
        PROVIDE_LOCAL_INFORMATION(0x26),
        LANGUAGE_NOTIFICATION(0x35);

        private int mValue;

        CommandType(int value) {
            mValue = value;
        }

        public int value() {
            return mValue;
        }

        /**
         * Create a CommandType object.
         *
         * @param value Integer value to be converted to a CommandType object.
         * @return CommandType object whose "Type of Command" value is {@code
         *         value}. If no CommandType object has that value, null is
         *         returned.
         */
        public static CommandType fromInt(int value) {
            for (CommandType e : CommandType.values()) {
                if (e.mValue == value) {
                    return e;
                }
            }
            return null;
        }
    }
}
