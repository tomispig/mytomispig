/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony.gsm.stk;

import android.os.Parcel;
import android.os.Parcelable;
/**
 * Class for representing text attributes for SIM Toolkit.
 *
 * {@hide}
 */
public class TextAttribute implements Parcelable {  
    public int start;
    public int length;
    public TextAlignment align;
    public FontSize size;
    public boolean bold;
    public boolean italic;
    public boolean underlined;
    public boolean strikeThrough;
    public TextColor color;
    public TextColor colorBG;

    public TextAttribute(int start, int length, TextAlignment align, FontSize size, boolean bold,
            boolean italic, boolean underlined, boolean strikeThrough, TextColor color,
            TextColor colorBG) {
        this.start = start;
        this.length = length;
        this.align = align;
        this.size = size;
        this.bold = bold;
        this.italic = italic;
        this.underlined = underlined;
        this.strikeThrough = strikeThrough;
        this.color = color;
        this.colorBG = colorBG;
    }

    private TextAttribute(Parcel in) {
        start = in.readInt();
        length = in.readInt();
        align = TextAlignment.values()[in.readInt()];
        size = FontSize.values()[in.readInt()];
        int format = in.readInt();
        bold = (format & 0x10) != 0 ? true : false;
        italic = (format & 0x20) != 0 ? true : false;
        underlined = (format & 0x40) != 0 ? true : false;
        strikeThrough = (format & 0x80) != 0 ? true : false;
        color = TextColor.values()[in.readInt()];
        colorBG = TextColor.values()[in.readInt()];
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(start);
        dest.writeInt(length);
        dest.writeInt(align.ordinal());
        dest.writeInt(size.ordinal());
        int format = ((bold ? 0x10 : 0x00) | (italic ? 0x20 : 0x00) | (underlined ? 0x40 : 0x00) | (strikeThrough ? 0x80
                : 0x00));
        dest.writeInt(format);
        dest.writeInt(color.ordinal());
        dest.writeInt(colorBG.ordinal());
    }

    public static final Parcelable.Creator<TextAttribute> CREATOR = new Parcelable.Creator<TextAttribute>() {
        public TextAttribute createFromParcel(Parcel in) {
            return new TextAttribute(in);
        }

        public TextAttribute[] newArray(int size) {
            return new TextAttribute[size];
        }
    };
}
