/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* code update
===============================================================================
When          Who           Why
-----------  ----------   ---------------------------------
2011-02-16   Zhouhao       implemented enhanced plmn list for OT only
2011-06-23    sunyanjun      Upgrade to Gingerbread                 ZTE_SYJ_20110623
===============================================================================
*/

package com.android.internal.telephony.gsm;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * {@hide}
 */
public class NetworkInfo implements Parcelable {
    public enum State {
        UNKNOWN,
        AVAILABLE,
        CURRENT,
        FORBIDDEN;
    }

    public enum RadioAccessTechnology {
        GSM,
        GSM_COMPACT,
        UTRAN,
//ZTE_SYJ_20110623, begin
/* U810-project added by zhouhao. 2011-02-16 *** BEGIN */
        DEFAULT;
/* U810-project added by zhouhao. 2011-02-16 *** END */
//ZTE_SYJ_20110623, end
    }

    String operatorAlphaLong;
    String operatorAlphaShort;
    String operatorNumeric;

    State state = State.UNKNOWN;
    RadioAccessTechnology rat = RadioAccessTechnology.GSM;


    public String
    getOperatorAlphaLong() {
        return operatorAlphaLong;
    }

    public String
    getOperatorAlphaShort() {
        return operatorAlphaShort;
    }

    public String
    getOperatorNumeric() {
        return operatorNumeric;
    }

    public State
    getState() {
        return state;
    }

//ZTE_SYJ_20110623, begin
/* U810-project added by zhouhao. 2011-02-16 *** BEGIN */
    NetworkInfo(String operatorAlphaLong,
                String operatorAlphaShort,
                String operatorNumeric,
                State state) {

        this.operatorAlphaLong = operatorAlphaLong;
        this.operatorAlphaShort = operatorAlphaShort;
        this.operatorNumeric = operatorNumeric;

        this.state = state;
        this.rat = RadioAccessTechnology.DEFAULT;
    }
/* U810-project added by zhouhao. 2011-02-16 *** END */
//ZTE_SYJ_20110623, end

    public RadioAccessTechnology
    getRat() {
        return rat;
    }

    NetworkInfo(String operatorAlphaLong,
                String operatorAlphaShort,
                String operatorNumeric,
                State state,
                RadioAccessTechnology rat) {

        this.operatorAlphaLong = operatorAlphaLong;
        this.operatorAlphaShort = operatorAlphaShort;
        this.operatorNumeric = operatorNumeric;

        this.state = state;
        this.rat = rat;
    }

//ZTE_SYJ_20110623, begin
/* U810-project added by zhouhao. 2011-02-16 *** BEGIN */
    public NetworkInfo(String operatorAlphaLong,
                String operatorAlphaShort,
                String operatorNumeric,
                String stateString) {
        this (operatorAlphaLong, operatorAlphaShort,
                operatorNumeric, rilStateToState(stateString), rilRatToRat("default"));
    }
/* U810-project added by zhouhao. 2011-02-16 *** END */
//ZTE_SYJ_20110623, end

    public NetworkInfo(String operatorAlphaLong,
                String operatorAlphaShort,
                String operatorNumeric,
                String stateString,
                String ratString) {
        this (operatorAlphaLong, operatorAlphaShort,
                operatorNumeric, rilStateToState(stateString), rilRatToRat(ratString));
    }

    /**
     * See state strings defined in ril.h RIL_REQUEST_QUERY_AVAILABLE_NETWORKS
     */
    private static State rilStateToState(String s) {
        if (s.equals("unknown")) {
            return State.UNKNOWN;
        } else if (s.equals("available")) {
            return State.AVAILABLE;
        } else if (s.equals("current")) {
            return State.CURRENT;
        } else if (s.equals("forbidden")) {
            return State.FORBIDDEN;
        } else {
            throw new RuntimeException(
                "RIL impl error: Invalid network state '" + s + "'");
        }
    }

    /**
     * See rat strings defined in ril.h RIL_REQUEST_QUERY_AVAILABLE_NETWORKS
     */
    private static RadioAccessTechnology rilRatToRat(String s) {
        if (s.equals("GSM")) {
            return RadioAccessTechnology.GSM;
        } else if (s.equals("GSM_COMPACT")) {
            return RadioAccessTechnology.GSM_COMPACT;
        } else if (s.equals("UTRAN")) {
            return RadioAccessTechnology.UTRAN;
        } 
//ZTE_SYJ_20110623, begin
/* U810-project added by zhouhao. 2011-02-16 *** BEGIN */
        else if(s.equals("default"))
        {
            return RadioAccessTechnology.DEFAULT;
        }
/* U810-project added by zhouhao. 2011-02-16 *** END */
//ZTE_SYJ_20110623, end
        else {
            throw new RuntimeException(
                "RIL impl error: Invalid radio access technology '" + s + "'");
        }
    }

    public String toString() {
//ZTE_SYJ_20110623, begin
/* U810-project added by zhouhao. 2011-02-16 *** BEGIN */
        String retString = "NetworkInfo"; 
        retString += operatorAlphaLong
                + "/" + operatorAlphaShort
                + "/" + operatorNumeric
                + "/" + state;
        if(rat != RadioAccessTechnology.DEFAULT)
        {
            retString += "/" + rat;
        }

        //return "NetworkInfo " + operatorAlphaLong
        //        + "/" + operatorAlphaShort
        //        + "/" + operatorNumeric
        //        + "/" + state
        //        + "/" + rat;

        return retString;
/* U810-project added by zhouhao. 2011-02-16 *** END */
//ZTE_SYJ_20110623, end
    }

//ZTE_SYJ_20110623, begin
/* U810-project added by zhouhao. 2011-02-16 *** BEGIN */
    public String ratToString()
    {
        String retString = "";
        if(rat == RadioAccessTechnology.GSM) {
            retString = "GSM";
        } else if(rat == RadioAccessTechnology.GSM_COMPACT) {
            retString = "GSM_COMPACT";
        } else if(rat == RadioAccessTechnology.UTRAN) {
            retString = "UTRAN";
        } else if(rat == RadioAccessTechnology.DEFAULT) {
            retString = "DEFAULT";
        } else {
            throw new RuntimeException(
                "RIL impl error: Invalid radio access technology '" + rat + "'");
        }
        return retString;
    }
/* U810-project added by zhouhao. 2011-02-16 *** END */
//ZTE_SYJ_20110623, end

    /**
     * Parcelable interface implemented below.
     * This is a simple effort to make NetworkInfo parcelable rather than
     * trying to make the conventional containing object (AsyncResult),
     * implement parcelable.  This functionality is needed for the
     * NetworkQueryService to fix 1128695.
     */

    public int describeContents() {
        return 0;
    }

    /**
     * Implement the Parcelable interface.
     * Method to serialize a NetworkInfo object.
     */
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(operatorAlphaLong);
        dest.writeString(operatorAlphaShort);
        dest.writeString(operatorNumeric);
        dest.writeSerializable(state);
        dest.writeSerializable(rat);
    }

    /**
     * Implement the Parcelable interface
     * Method to deserialize a NetworkInfo object, or an array thereof.
     */
    public static final Creator<NetworkInfo> CREATOR =
        new Creator<NetworkInfo>() {
            public NetworkInfo createFromParcel(Parcel in) {
                NetworkInfo netInfo = new NetworkInfo(
                        in.readString(), /*operatorAlphaLong*/
                        in.readString(), /*operatorAlphaShort*/
                        in.readString(), /*operatorNumeric*/
                        (State) in.readSerializable(), /*state*/
                        (RadioAccessTechnology) in.readSerializable()); /*rat*/
                return netInfo;
            }

            public NetworkInfo[] newArray(int size) {
                return new NetworkInfo[size];
            }
        };
}
