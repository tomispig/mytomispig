/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony.gsm;

import android.os.Message;
import android.util.Log;

import com.android.internal.telephony.IccCard;
import com.android.internal.telephony.IccCardApplication;
import com.android.internal.telephony.IccConstants;
import com.android.internal.telephony.IccFileHandler;
import com.android.internal.telephony.Phone;

/**
 * {@hide}
 */
public final class SIMFileHandler extends IccFileHandler implements IccConstants {
    static final String LOG_TAG = "GSM";
    private Phone mPhone;

    //***** Instance Variables

    //***** Constructor

    SIMFileHandler(GSMPhone phone) {
        super(phone);
        mPhone = phone;
    }

    public void dispose() {
        super.dispose();
    }

    protected void finalize() {
        Log.d(LOG_TAG, "SIMFileHandler finalized");
    }

    //***** Overridden from IccFileHandler

    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
    }

    protected String getEFPath(int efid) {
        IccCard card = phone.getIccCard();

        //SIM/USIM same path
        switch(efid) {
            case EF_MAILBOX_CPHS:
            case EF_VOICE_MAIL_INDICATOR_CPHS:
            case EF_CFF_CPHS:
            case EF_SPN_CPHS:
            case EF_SPN_SHORT_CPHS:
            case EF_INFO_CPHS:
                return MF_SIM + DF_GSM;
                
            case EF_IMG:
                return MF_SIM + DF_TELECOM + DF_GRAPHICS;     

            case EF_ICCID:
                return MF_SIM;
				
            case EF_PBR:
                // we only support global phonebook.
                return MF_SIM + DF_TELECOM + DF_PHONEBOOK;

        }

        //for USIM, we use FID 7FFF(ADF_USIM) as root path
        if (card != null && card.isApplicationOnIcc(IccCardApplication.AppType.APPTYPE_USIM)) {

            switch(efid) {
                case EF_SMS:
                case EF_FDN:
                case EF_MSISDN:
                case EF_SDN:
                case EF_EXT2:
                case EF_EXT3:
                case EF_EXT6:
                case EF_MWIS:
                case EF_MBI:
                case EF_SPN:
                case EF_AD:
                case EF_MBDN:
                case EF_PNN:
                case EF_SPDI:
                case EF_UST: //EF_UST in USIM, EF_SST in SIM
                case EF_CFIS:
                case EF_ECC:
                case EF_ARR:
                case EF_SMSP:
                case EF_SMSS:
                case EF_LND:
                case EF_SMSR:
                case EF_BDN:
                case EF_EXT4:
                case EF_ECCP:
                case EF_RMA:
                case EF_SUME:
                case EF_ICEDN:
                case EF_ICEFF:
                case EF_PSISMSC:
                    return ADF_USIM;
        
                }
        }
        else {
        
            switch(efid) {
                case EF_SMS:
                case EF_FDN:
                case EF_MSISDN:
                case EF_SDN:
                case EF_EXT2:
                case EF_EXT3:
                case EF_SMSP:
                case EF_SMSS:
                case EF_LND:
                case EF_SMSR:
                case EF_EXT4:
                case EF_ECCP:
                    return MF_SIM + DF_TELECOM;

                case EF_EXT6:
                case EF_MWIS:
                case EF_MBI:
                case EF_SPN:
                case EF_AD:
                case EF_MBDN:
                case EF_PNN:
                case EF_SPDI:
                case EF_SST:
                case EF_CFIS:
                    return MF_SIM + DF_GSM;


                case EF_ECC:
                    return MF_SIM + DF_GSM;
                    
                case EF_ADN:
                case EF_EXT1:
                    return MF_SIM + DF_TELECOM;
                }
        }        
        
        // The EFids in USIM phone book entries are decided by the card manufacturer.
        // So if we don't match any of the cases above and if its a USIM return
        // the phone book path.
        if (card != null && card.isApplicationOnIcc(IccCardApplication.AppType.APPTYPE_USIM)) {
            return MF_SIM + DF_TELECOM + DF_PHONEBOOK;
        }
        Log.e(LOG_TAG, "Error: EF Path being returned in null");
        
        return null;
    }

    protected void logd(String msg) {
        Log.d(LOG_TAG, "[SIMFileHandler] " + msg);
    }

    protected void loge(String msg) {
        Log.e(LOG_TAG, "[SIMFileHandler] " + msg);
    }
}
