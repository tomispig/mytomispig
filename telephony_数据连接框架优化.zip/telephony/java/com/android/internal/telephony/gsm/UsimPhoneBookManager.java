/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony.gsm;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.android.internal.telephony.AdnRecord;
import com.android.internal.telephony.AdnRecordCache;
import com.android.internal.telephony.IccConstants;
import com.android.internal.telephony.IccUtils;
import com.android.internal.telephony.PhoneBase;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
import android.telephony.PhoneNumberUtils; 
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/

import org.apache.harmony.luni.lang.reflect.ListOfTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//add by liandongzhou for td need the second the third number 20101220
import android.text.TextUtils;
//end add by liandongzhou for td need the second the third number 20101220

/**
 * This class implements reading and parsing USIM records.
 * Refer to Spec 3GPP TS 31.102 for more details.
 *
 * {@hide}
 */
public class UsimPhoneBookManager extends Handler implements IccConstants {
    private static final String LOG_TAG = "GSM";
    private static final boolean DBG = true;
    private PbrFile mPbrFile;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    private PbrFileSfi mPbrFileSfi;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
    private Boolean mIsPbrPresent;
    private PhoneBase mPhone;
    private AdnRecordCache mAdnCache;
    private Object mLock = new Object();
    private ArrayList<AdnRecord> mPhoneBookRecords;
    private boolean mEmailPresentInIap = false;
    private int mEmailTagNumberInIap = 0;
    private ArrayList<byte[]> mIapFileRecord;
    private ArrayList<byte[]> mEmailFileRecord;
    private Map<Integer, ArrayList<String>> mEmailsForAdnRec;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    private Map<Integer, String> mAnrForAdnRec;
//add by liandongzhou for td need the second the third number 20101220
    private Map<Integer, String> mAnr2ForAdnRec;
    private Map<Integer, String> mAnr3ForAdnRec;
    private Map<Integer, String> mSneForAdnRec;	
//end add by liandongzhou for td need the second the third number 20101220	
    private boolean mAnrPresentInIap = false;
    private int mAnrTagNumberInIap = 0;
    private ArrayList<byte[]> mAnrFileRecord;
//add by liandongzhou for td need the second the third number 20101220
    private ArrayList<byte[]> mAnr2FileRecord;
    private ArrayList<byte[]> mAnr3FileRecord;
    private ArrayList<byte[]> mSneFileRecord;	
//end add by liandongzhou for td need the second the third number 20101220	
    private Map<Integer, ArrayList<String>> mAnrsForAdnRec;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
    private static final int EVENT_PBR_LOAD_DONE = 1;
    private static final int EVENT_USIM_ADN_LOAD_DONE = 2;
    private static final int EVENT_IAP_LOAD_DONE = 3;
    private static final int EVENT_EMAIL_LOAD_DONE = 4;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    private static final int EVENT_ANR_LOAD_DONE = 5; 
//add by liandongzhou for td need the second the third number 20101220
    private static final int EVENT_ANR2_LOAD_DONE = 6; 
    private static final int EVENT_ANR3_LOAD_DONE = 7; 	
    private static final int EVENT_SNE_LOAD_DONE = 8; 		
//end add by liandongzhou for td need the second the third number 20101220	
    private int ext1Efid = 0;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
    private static final int USIM_TYPE1_TAG   = 0xA8;
    private static final int USIM_TYPE2_TAG   = 0xA9;
    private static final int USIM_TYPE3_TAG   = 0xAA;
    private static final int USIM_EFADN_TAG   = 0xC0;
    private static final int USIM_EFIAP_TAG   = 0xC1;
    private static final int USIM_EFEXT1_TAG  = 0xC2;
    private static final int USIM_EFSNE_TAG   = 0xC3;
    private static final int USIM_EFANR_TAG   = 0xC4;
    private static final int USIM_EFPBC_TAG   = 0xC5;
    private static final int USIM_EFGRP_TAG   = 0xC6;
    private static final int USIM_EFAAS_TAG   = 0xC7;
    private static final int USIM_EFGSD_TAG   = 0xC8;
    private static final int USIM_EFUID_TAG   = 0xC9;
    private static final int USIM_EFEMAIL_TAG = 0xCA;
    private static final int USIM_EFCCP1_TAG  = 0xCB;
//add by liandongzhou for td need the second the third number 20101220
    private static final int USIM_EFANR2_TAG = 0xCE;
    private static final int USIM_EFANR3_TAG  = 0xCF;
//end add by liandongzhou for td need the second the third number 20101220
	
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    private int pbrNumbers = 0;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/

    public UsimPhoneBookManager(PhoneBase phone, AdnRecordCache cache) {
        mPhone = phone;
        mPhoneBookRecords = new ArrayList<AdnRecord>();
        mPbrFile = null;
        // We assume its present, after the first read this is updated.
        // So we don't have to read from UICC if its not present on subsequent reads.
        mIsPbrPresent = true;
        mAdnCache = cache;
    }

    public void reset() {
        mPhoneBookRecords.clear();
        mIapFileRecord = null;
        mEmailFileRecord = null;
        mPbrFile = null;
        mIsPbrPresent = true;
    }

/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    public boolean isSupportUsim() {
        Map <Integer,Integer> fileIds;
        if (mPbrFile == null)  return false;
        if (mPbrFile.mFileIds == null) return false;
        fileIds = mPbrFile.mFileIds.get(0);
        if (fileIds == null || fileIds.isEmpty()){
	    return false;
        }
        if (fileIds.containsKey(USIM_EFANR_TAG) && 
	     fileIds.containsKey(USIM_EFEMAIL_TAG) &&
	     fileIds.containsKey(USIM_EFIAP_TAG)) 
	    return true;
	 return false;
    }
    public boolean isSupportANR() {
        Map <Integer,Integer> fileIds;
        if (mPbrFile == null)  return false;
        if (mPbrFile.mFileIds == null) return false;
        fileIds = mPbrFile.mFileIds.get(0);
        if (fileIds == null || fileIds.isEmpty()){
	    return false;
        }
        if (fileIds.containsKey(USIM_EFANR_TAG)) 
	    return true;
	 return false;
    }
//add by liandongzhou for td need the second the third number 20101222
    public boolean isSupportANR2() {
        Map <Integer,Integer> fileIds;
        if (mPbrFile == null)  return false;
        if (mPbrFile.mFileIds == null) return false;
        fileIds = mPbrFile.mFileIds.get(0);
        if (fileIds == null || fileIds.isEmpty()){
	    return false;
        }
        if (fileIds.containsKey(USIM_EFANR2_TAG)) 
	    return true;
	 return false;
    }

    public boolean isSupportANR3() {
        Map <Integer,Integer> fileIds;
        if (mPbrFile == null)  return false;
        if (mPbrFile.mFileIds == null) return false;
        fileIds = mPbrFile.mFileIds.get(0);
        if (fileIds == null || fileIds.isEmpty()){
	    return false;
        }
        if (fileIds.containsKey(USIM_EFANR3_TAG)) 
	    return true;
	 return false;
    }
	
    public boolean isSupportSNE() {
        Map <Integer,Integer> fileIds;
        if (mPbrFile == null)  return false;
        if (mPbrFile.mFileIds == null) return false;
        fileIds = mPbrFile.mFileIds.get(0);
        if (fileIds == null || fileIds.isEmpty()){
	    return false;
        }
        if (fileIds.containsKey(USIM_EFSNE_TAG)) 
	    return true;
	 return false;
    }	
//end add by liandongzhou for td need the second the third number 20101222
	
    public boolean isSupportEmail() {
        Map <Integer,Integer> fileIds;
        if (mPbrFile == null)  return false;
        if (mPbrFile.mFileIds == null) return false;
        fileIds = mPbrFile.mFileIds.get(0);
        if (fileIds == null || fileIds.isEmpty()){
	    return false;
        }
        if (fileIds.containsKey(USIM_EFEMAIL_TAG)) 
	    return true;
	 return false;
    }
    public boolean isSupportIAP() {
        Map <Integer,Integer> fileIds;
        if (mPbrFile == null)  return false;
        if (mPbrFile.mFileIds == null) return false;
        fileIds = mPbrFile.mFileIds.get(0);
        if (fileIds == null || fileIds.isEmpty()){
	    return false;
        }
        if (fileIds.containsKey(USIM_EFIAP_TAG)) 
	    return true;
	 return false;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
    public ArrayList<AdnRecord> loadEfFilesFromUsim() {
        synchronized (mLock) {
            if (!mPhoneBookRecords.isEmpty()) return mPhoneBookRecords;
            if (!mIsPbrPresent) return null;

            // Check if the PBR file is present in the cache, if not read it
            // from the USIM.
            if (mPbrFile == null) {
                readPbrFileAndWait();
            }

            if (mPbrFile == null) return null;

            int numRecs = mPbrFile.mFileIds.size();
            Log.e("ZLian", "loadEfFilesFromUsim numRecs = "+numRecs);			
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
	    pbrNumbers = numRecs;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
            for (int i = 0; i < numRecs; i++) {
                readAdnFileAndWait(i);
                readEmailFileAndWait(i);
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
                readAnrFileAndWait(i);
                readAnr2FileAndWait(i);
                readAnr3FileAndWait(i);		
                readSneFileAndWait(i);						
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
            }
            // All EF files are loaded, post the response.
        }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
        int ANRefid1 = getAnrFileId(0);
        int ANRefid2 = getAnrFileId(1);
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
        return mPhoneBookRecords;
    }

    private void readPbrFileAndWait() {
        mPhone.getIccFileHandler().loadEFLinearFixedAll(EF_PBR, obtainMessage(EVENT_PBR_LOAD_DONE));
        try {
            mLock.wait();
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, "Interrupted Exception in readAdnFileAndWait");
        }
    }

    private void readEmailFileAndWait(int recNum) {
        Map <Integer,Integer> fileIds;
        fileIds = mPbrFile.mFileIds.get(recNum);
        if (fileIds == null) return;

        if (fileIds.containsKey(USIM_EFEMAIL_TAG)) {
            int efid = fileIds.get(USIM_EFEMAIL_TAG);
            // Check if the EFEmail is a Type 1 file or a type 2 file.
            // If mEmailPresentInIap is true, its a type 2 file.
            // So we read the IAP file and then read the email records.
            // instead of reading directly.
            if (mEmailPresentInIap) {
                readIapFileAndWait(fileIds.get(USIM_EFIAP_TAG));
                if (mIapFileRecord == null) {
                    Log.e(LOG_TAG, "Error: IAP file is empty");
                    return;
                }
            }
            // Read the EFEmail file.
            mPhone.getIccFileHandler().loadEFLinearFixedAll(fileIds.get(USIM_EFEMAIL_TAG),
                    obtainMessage(EVENT_EMAIL_LOAD_DONE));
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                Log.e(LOG_TAG, "Interrupted Exception in readEmailFileAndWait");
            }

            if (mEmailFileRecord == null) {
                Log.e(LOG_TAG, "Error: Email file is empty");
                return;
            }
            updatePhoneAdnRecord();
        }

    }

    private void readIapFileAndWait(int efid) {
        mPhone.getIccFileHandler().loadEFLinearFixedAll(efid, obtainMessage(EVENT_IAP_LOAD_DONE));
        try {
            mLock.wait();
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, "Interrupted Exception in readIapFileAndWait");
        }
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    private void readAnrFileAndWait(int recNum) {
        Map <Integer,Integer> fileIds;
        fileIds = mPbrFile.mFileIds.get(recNum);
        if (fileIds == null) return;
	/*ZTE_MAOYING_USIM_001 20100730 begin */
	if (fileIds.containsKey(USIM_EFANR_TAG)) {
	/*ZTE_MAOYING_USIM_001 20100730 end */
        mPhone.getIccFileHandler().loadEFLinearFixedAll(fileIds.get(USIM_EFANR_TAG), obtainMessage(EVENT_ANR_LOAD_DONE));
        try {
            mLock.wait();
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, "Interrupted Exception in readAnrFileAndWait");
        }
		
        if (mAnrFileRecord == null) {
            Log.e(LOG_TAG, "Error: Anr file is empty");
            return;
        }
        updatePhoneAnrAdnRecord();
	}
    }
//add by liandongzhou for td need the second the third number 20101220
    private void readAnr2FileAndWait(int recNum) {
        Map <Integer,Integer> fileIds;
        fileIds = mPbrFile.mFileIds.get(recNum);
        if (fileIds == null) return;
	/*ZTE_MAOYING_USIM_001 20100730 begin */
	if (fileIds.containsKey(USIM_EFANR2_TAG)) {
	/*ZTE_MAOYING_USIM_001 20100730 end */
        mPhone.getIccFileHandler().loadEFLinearFixedAll(fileIds.get(USIM_EFANR2_TAG), obtainMessage(EVENT_ANR2_LOAD_DONE));
        try {
            mLock.wait();
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, "Interrupted Exception in readAnr2FileAndWait");
        }
		
        if (mAnr2FileRecord == null) {
            Log.e(LOG_TAG, "Error: Anr2 file is empty");
            return;
        }
        updatePhoneAnr2AdnRecord();
	}
    }

    private void readAnr3FileAndWait(int recNum) {
        Map <Integer,Integer> fileIds;
        fileIds = mPbrFile.mFileIds.get(recNum);
        if (fileIds == null) return;
	/*ZTE_MAOYING_USIM_001 20100730 begin */
	if (fileIds.containsKey(USIM_EFANR3_TAG)) {
	/*ZTE_MAOYING_USIM_001 20100730 end */
        mPhone.getIccFileHandler().loadEFLinearFixedAll(fileIds.get(USIM_EFANR3_TAG), obtainMessage(EVENT_ANR3_LOAD_DONE));
        try {
            mLock.wait();
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, "Interrupted Exception in readAnr3FileAndWait");
        }
		
        if (mAnr3FileRecord == null) {
            Log.e(LOG_TAG, "Error: Anr3 file is empty");
            return;
        }
        updatePhoneAnr3AdnRecord();
	}
    }

    private void readSneFileAndWait(int recNum) {
        Map <Integer,Integer> fileIds;
        fileIds = mPbrFile.mFileIds.get(recNum);
        if (fileIds == null) return;
	/*ZTE_MAOYING_USIM_001 20100730 begin */
	if (fileIds.containsKey(USIM_EFSNE_TAG)) {
	/*ZTE_MAOYING_USIM_001 20100730 end */
        mPhone.getIccFileHandler().loadEFLinearFixedAll(fileIds.get(USIM_EFSNE_TAG), obtainMessage(EVENT_SNE_LOAD_DONE));
        try {
            mLock.wait();
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, "Interrupted Exception in readSneFileAndWait");
        }
		
        if (mSneFileRecord == null) {
            Log.e(LOG_TAG, "Error: sne file is empty");
            return;
        }
        updatePhoneSneAdnRecord();
	}
    }	

    public int getAnrFileId(int recNum) {
        Map <Integer,Integer> fileIds;
/*ZTE_MAOYING_USIM_001 20100730 begin */
	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }
/*ZTE_MAOYING_USIM_001 20100730 end */
        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFANR_TAG)) {
            efid = fileIds.get(USIM_EFANR_TAG);
        }
	return efid;
    }
	
//end add by liandongzhou for td need the second the third number 20101220

    public int getEmailFileId(int recNum) {
        Map <Integer,Integer> fileIds;
        Log.e(LOG_TAG, "getEmailFileId-- begin recNum = " +recNum);//modify by liandongzhou for can not get email fileId.20110312
        if (mPbrFile == null){ 
            return 0;
        }else{
            if (mPbrFile.mFileIds == null) return 0;
        }

        fileIds = mPbrFile.mFileIds.get(recNum);
        Log.e(LOG_TAG, "getEmailFileId-- fileIds = " + fileIds);   //modify by liandongzhou for can not get email fileId.20110312
        int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
            return efid;
        }
        Log.e(LOG_TAG, "getEmailFileId-- fileIds != null and  fileIds.isnotEmpty");//modify by liandongzhou for can not get email fileId.20110312

        if (fileIds.containsKey(USIM_EFEMAIL_TAG)) {
            efid = fileIds.get(USIM_EFEMAIL_TAG);
        }
        Log.e(LOG_TAG, "getEmailFileId-- efid = " + efid); //modify by liandongzhou for can not get email fileId.20110312       
        return efid;
    }


    public int getIapFileId(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFIAP_TAG)) {
            efid = fileIds.get(USIM_EFIAP_TAG);
        }
	return efid;
    }
	
    public int getAdnFileld(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFADN_TAG)) {
            efid = fileIds.get(USIM_EFADN_TAG);
        }
	return efid;
    }

    public int getExt1Fileld(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFEXT1_TAG)) {
            efid = fileIds.get(USIM_EFEXT1_TAG);
        }
	return efid;
    }

    public int getSfiFileld(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFileSfi.mSfiFileIds.get(recNum);
	int sfi = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return sfi;
        }

        if (fileIds.containsKey(USIM_EFADN_TAG)) {
            sfi = fileIds.get(USIM_EFADN_TAG);
        }
	return sfi;
    }

    public int getAnrFileld(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFANR_TAG)) {
            efid = fileIds.get(USIM_EFANR_TAG);
        }
	return efid;
    }
	
//add by liandongzhou for td need the second the third number 20101222
    public int getAnr2FileId(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFANR2_TAG)) {
            efid = fileIds.get(USIM_EFANR2_TAG);
        }
	return efid;
    }

    public int getAnr3FileId(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFANR3_TAG)) {
            efid = fileIds.get(USIM_EFANR3_TAG);
        }
	return efid;
    }

    public int getSneFileId(int recNum) {
        Map <Integer,Integer> fileIds;

	 if (mPbrFile == null){ 
           return 0;
         }else{
           if (mPbrFile.mFileIds == null) return 0;
         }

        fileIds = mPbrFile.mFileIds.get(recNum);
	int efid = 0;
        if (fileIds == null || fileIds.isEmpty()){
	    return efid;
        }

        if (fileIds.containsKey(USIM_EFSNE_TAG)) {
            efid = fileIds.get(USIM_EFSNE_TAG);
        }
	return efid;
    }
//end add by liandongzhou for td need the second the third number 20101222	
    private void createPbrFileSfi(ArrayList<byte[]> records) {
        if (records == null) {
            mPbrFileSfi = null;
            //mIsPbrPresent = false;
            return;
        }
        mPbrFileSfi = new PbrFileSfi(records);
    }

    public int[] getAllEmailFileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getEmailFileId(i);
	}
	return FileId;
    }

    public int[] getAllIapFileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getIapFileId(i);
	}
	return FileId;
    }

    public int[] getAllAdnFileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getAdnFileld(i);
	}
	return FileId;
    }

    public int[] getAllExt1Fileld(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getExt1Fileld(i);
	}
	return FileId;
    }

    public int[] getAllSfiFileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getSfiFileld(i);
	}
	return FileId;
    }

    public int[] getAllAnrFileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getAnrFileld(i);
	}
	return FileId;
    }
//add by liandongzhou for td need the second the third number 20101222
    public int[] getAllAnr2FileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getAnr2FileId(i);
	}
	return FileId;
    }

    public int[] getAllAnr3FileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getAnr3FileId(i);
	}
	return FileId;
    }

    public int[] getAllSneFileId(){
	int[] FileId = null;
	FileId = new int[pbrNumbers];
	for(int i =0; i<pbrNumbers; i++)
	{
	    FileId[i] = getSneFileId(i);
	}
	return FileId;
    }
//end add by liandongzhou for td need the second the third number 20101222	
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/

    private void updatePhoneAdnRecord() {
        if (mEmailFileRecord == null) return;
        int numAdnRecs = mPhoneBookRecords.size();
        if (mIapFileRecord != null) {
            // The number of records in the IAP file is same as the number of records in ADN file.
            // The order of the pointers in an EFIAP shall be the same as the order of file IDs
            // that appear in the TLV object indicated by Tag 'A9' in the reference file record.
            // i.e value of mEmailTagNumberInIap

            for (int i = 0; i < numAdnRecs; i++) {
                byte[] record = null;
                try {
                    record = mIapFileRecord.get(i);
                } catch (IndexOutOfBoundsException e) {
                    Log.e(LOG_TAG, "Error: Improper ICC card: No IAP record for ADN, continuing i= " + i);
                    break;
                }
                int recNum = record[mEmailTagNumberInIap];

                if (recNum != -1) {
                    String[] emails = new String[1];
                    // SIM record numbers are 1 based
                    emails[0] = readEmailRecord(recNum - 1);
                    AdnRecord rec = mPhoneBookRecords.get(i);
                    if (rec != null) {
                        rec.setEmails(emails);
                    } else {
                        // might be a record with only email
                        rec = new AdnRecord("", "", emails);
                    }
                    mPhoneBookRecords.set(i, rec);
                }
            }
        }

        // ICC cards can be made such that they have an IAP file but all
        // records are empty. So we read both type 1 and type 2 file
        // email records, just to be sure.

        int len = mPhoneBookRecords.size();
        // Type 1 file, the number of records is the same as the number of
        // records in the ADN file.
        if (mEmailsForAdnRec == null) {
            parseType1EmailFile(len);
        }
        for (int i = 0; i < numAdnRecs; i++) {
            ArrayList<String> emailList = null;
            try {
                emailList = mEmailsForAdnRec.get(i);
            } catch (IndexOutOfBoundsException e) {
                break;
            }
            if (emailList == null) continue;

            AdnRecord rec = mPhoneBookRecords.get(i);

            String[] emails = new String[emailList.size()];
            System.arraycopy(emailList.toArray(), 0, emails, 0, emailList.size());
            rec.setEmails(emails);
            mPhoneBookRecords.set(i, rec);
        }
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    private void updatePhoneAnrAdnRecord() {
        if (mAnrFileRecord == null) return;
        int numAdnRecs = mPhoneBookRecords.size();

        // ICC cards can be made such that they have an IAP file but all
        // records are empty. So we read both type 1 and type 2 file
        // email records, just to be sure.

        int len = mPhoneBookRecords.size();
        // Type 1 file, the number of records is the same as the number of
        // records in the ADN file.
        if (mAnrForAdnRec == null) {
            parseType1Anr(len);
        }

        for (int i = 0; i < numAdnRecs; i++) {
	    String anr =null;//xuyang test for anr
            try {
		anr = mAnrForAdnRec.get(i);//xuyang test for anr
            } catch (IndexOutOfBoundsException e) {
                break;
            }
			
            if (anr == null) continue;

            AdnRecord rec = mPhoneBookRecords.get(i);
	    rec.setAnr(anr);//xuyang test for anr
            mPhoneBookRecords.set(i, rec);
        }

    }
// add by liandongzhou for td need the second the third number 20101220
    private void updatePhoneAnr2AdnRecord() {
        if (mAnr2FileRecord == null) return;
        int numAdnRecs = mPhoneBookRecords.size();

        // ICC cards can be made such that they have an IAP file but all
        // records are empty. So we read both type 1 and type 2 file
        // email records, just to be sure.

        int len = mPhoneBookRecords.size();
        // Type 1 file, the number of records is the same as the number of
        // records in the ADN file.
        if (mAnr2ForAdnRec == null) {
            parseType1Anr2(len);
        }

        for (int i = 0; i < numAdnRecs; i++) {
	    String anr =null;//xuyang test for anr
            try {
		anr = mAnr2ForAdnRec.get(i);//xuyang test for anr
            } catch (IndexOutOfBoundsException e) {
                break;
            }

            if (anr == null) continue;

            AdnRecord rec = mPhoneBookRecords.get(i);
	     rec.setAnr2(anr);//xuyang test for anr
            mPhoneBookRecords.set(i, rec);
        }

    }
    private void updatePhoneAnr3AdnRecord() {
        if (mAnr3FileRecord == null) return;
        int numAdnRecs = mPhoneBookRecords.size();

        // ICC cards can be made such that they have an IAP file but all
        // records are empty. So we read both type 1 and type 2 file
        // email records, just to be sure.

        int len = mPhoneBookRecords.size();
        // Type 1 file, the number of records is the same as the number of
        // records in the ADN file.
        if (mAnr3ForAdnRec == null) {
            parseType1Anr3(len);
        }

        for (int i = 0; i < numAdnRecs; i++) {
	    String anr =null;//xuyang test for anr
            try {
		anr = mAnr3ForAdnRec.get(i);//xuyang test for anr
            } catch (IndexOutOfBoundsException e) {
                break;
            }
			
            if (anr == null) continue;

            AdnRecord rec = mPhoneBookRecords.get(i);
	    rec.setAnr3(anr);//xuyang test for anr
            mPhoneBookRecords.set(i, rec);
        }

    }

    private void updatePhoneSneAdnRecord() {
        if (mSneFileRecord == null) return;
        int numAdnRecs = mPhoneBookRecords.size();

        // records in the ADN file.
        if (mSneForAdnRec == null) {			
            parseType1Sne(numAdnRecs);
        }

        for (int i = 0; i < numAdnRecs; i++) {
	    String sne =null;
            try {
		sne = mSneForAdnRec.get(i);//xuyang test for anr
            } catch (IndexOutOfBoundsException e) {
                break;
            }
			
            if (sne == null) continue;

            AdnRecord rec = mPhoneBookRecords.get(i);
	    rec.setSne(sne);//xuyang test for anr
            mPhoneBookRecords.set(i, rec);
        }

    }	

//end add by liandongzhou for td need the second the third number 20101220
    void parseType1Anr(int numRecs) {
        mAnrForAdnRec = new HashMap<Integer, String>();

        for (int i = 0; i < numRecs; i++) {

            String anr = readAnrRecord(i);

            if (anr == null || anr.equals("")) {
                continue;
            }

            // SIM record numbers are 1 based.
            mAnrForAdnRec.put(i, anr);
        }
    }

//add by liandongzhou for td need the second the third number 20101220
    void parseType1Anr2(int numRecs) {
        mAnr2ForAdnRec = new HashMap<Integer, String>();

        for (int i = 0; i < numRecs; i++) {

            String anr = readAnr2Record(i);

            if (TextUtils.isEmpty(anr)) {
                continue;
            }

            mAnr2ForAdnRec.put(i, anr);
        }
    }
    void parseType1Anr3(int numRecs) {
        mAnr3ForAdnRec = new HashMap<Integer, String>();

        for (int i = 0; i < numRecs; i++) {

            String anr = readAnr3Record(i);

            if (TextUtils.isEmpty(anr)) {
                continue;
            }

            mAnr3ForAdnRec.put(i, anr);
        }
    }
    void parseType1Sne(int numRecs) {
        mSneForAdnRec = new HashMap<Integer, String>();

        for (int i = 0; i < numRecs; i++) {

            String sne = readSneRecord(i);

            if (TextUtils.isEmpty(sne)) {
                continue;
            }

            mSneForAdnRec.put(i, sne);
        }
    }	
//end add by liandongzhou for td need the second the third number 20101220
    private String readAnrRecord(int recNum) {
        byte[] anrRec = null;
	try {
            anrRec = mAnrFileRecord.get(recNum);
        } catch (IndexOutOfBoundsException e) {
        log("readAnrRecord mAnrFileRecord.get exception anrRec = " + anrRec);
            return null;
        }
        int anrLength = (int)0xff&anrRec[1];

        // The length of the record is X+2 byte, where X bytes is the email address
        /*ZTE_ANR_MAOYING_001 CRDB00558993 2010-10-16 begin */
        //String anr = PhoneNumberUtils.calledPartyBCDFragmentToString(anrRec, 3, anrLength);//bcd is the fourth byte, and length is 10
	 String anr = PhoneNumberUtils.calledPartyBCDToString(anrRec, 2, anrLength+1);//bcd is the fourth byte, and length is 10
        /*ZTE_ANR_MAOYING_001 CRDB00558993 2010-10-16 end */
        return anr;
    }
//add by liandongzhou for td need the second the third number 20101221
    private String readAnr2Record(int recNum) {
        byte[] anrRec = null;
	try {
            anrRec = mAnr2FileRecord.get(recNum);
        } catch (IndexOutOfBoundsException e) {
            log("readAnrRecord mAnr2FileRecord.get exception anrRec = " + anrRec);
            return null;
        }
        int anrLength = (int)0xff&anrRec[1];
	 String anr = PhoneNumberUtils.calledPartyBCDToString(anrRec, 2, anrLength+1);//bcd is the fourth byte, and length is 10
        return anr;
    }

    private String readAnr3Record(int recNum) {
        byte[] anrRec = null;
	try {
            anrRec = mAnr3FileRecord.get(recNum);
        } catch (IndexOutOfBoundsException e) {
            log("readAnrRecord mAnr3FileRecord.get exception anrRec = " + anrRec);
            return null;
        }
        int anrLength = (int)0xff&anrRec[1];
	 String anr = PhoneNumberUtils.calledPartyBCDToString(anrRec, 2, anrLength+1);//bcd is the fourth byte, and length is 10
        return anr;
    }	

    private String readSneRecord(int recNum) {
        byte[] sneRec = null;
	try {
            sneRec = mSneFileRecord.get(recNum);
        } catch (IndexOutOfBoundsException e) {
            log("readSneRecord mSneFileRecord.get exception sneRec = " + sneRec);
            return null;
        }
	 String sne =  IccUtils.adnStringFieldToString(sneRec, 0, sneRec.length);
        return sne;
    }		
//end add by liandongzhou for td need the second the third number 20101221
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
    void parseType1EmailFile(int numRecs) {
        mEmailsForAdnRec = new HashMap<Integer, ArrayList<String>>();
        byte[] emailRec = null;
        for (int i = 0; i < numRecs; i++) {
            try {
                emailRec = mEmailFileRecord.get(i);
            } catch (IndexOutOfBoundsException e) {
                Log.e(LOG_TAG, "Error: Improper ICC card: No email record for ADN, continuing");
                break;
            }
            int adnRecNum = emailRec[emailRec.length - 1];

            if (adnRecNum == -1) {
		/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
		/* Type1 is the method of link with ADN of EF_EMAIL of SBM USIM.
		The length of the record is X byte, where X bytes is the email address
		If an e-mail address is registered in another UE, it is not displayed
		on Venus because EF_EMAIL is registered by Type1.*/
		adnRecNum =i+1;//SIM record numbers are 1 based.
		Log.e(LOG_TAG, "yangxiangling: parseType1EmailFile: SIM record numbers adnRecNum="+adnRecNum);
		/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/	
            }

            String email = readEmailRecord(i);

            if (email == null || email.equals("")) {
                continue;
            }

            // SIM record numbers are 1 based.
            ArrayList<String> val = mEmailsForAdnRec.get(adnRecNum - 1);
            if (val == null) {
                val = new ArrayList<String>();
            }
            val.add(email);
            // SIM record numbers are 1 based.
            mEmailsForAdnRec.put(adnRecNum - 1, val);
        }
    }

    private String readEmailRecord(int recNum) {
        byte[] emailRec = null;
        try {
            emailRec = mEmailFileRecord.get(recNum);
        } catch (IndexOutOfBoundsException e) {
            return null;
        }

        // The length of the record is X+2 byte, where X bytes is the email address
        String email = IccUtils.adnStringFieldToString(emailRec, 0, emailRec.length - 2);
	/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
	/*Type1 is the method of link with ADN of EF_EMAIL of SBM USIM.
	The length of the record is X byte, where X bytes is the email address
	If an e-mail address is registered in another UE, it is not displayed
	on Venus because EF_EMAIL is registered by Type1.*/
        if (-1 ==  emailRec[emailRec.length - 1]){
            email = IccUtils.adnStringFieldToString(emailRec, 0, emailRec.length);
            Log.e(LOG_TAG, "yangxiangling: readEmailRecord: emailRec.length="+emailRec.length+" emailRec="+email);
	}
	/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
        return email;
    }

    private void readAdnFileAndWait(int recNum) {
        Map <Integer,Integer> fileIds;
        fileIds = mPbrFile.mFileIds.get(recNum);
        if (fileIds == null || fileIds.isEmpty()) return;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
        if (fileIds.containsKey(USIM_EFEXT1_TAG)) {
        mAdnCache.requestLoadAllAdnLike(fileIds.get(USIM_EFADN_TAG),
            fileIds.get(USIM_EFEXT1_TAG), obtainMessage(EVENT_USIM_ADN_LOAD_DONE));
        }else{
            mAdnCache.requestLoadAllAdnLike(fileIds.get(USIM_EFADN_TAG),
                    0, obtainMessage(EVENT_USIM_ADN_LOAD_DONE));
        }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
        try {
            mLock.wait();
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, "Interrupted Exception in readAdnFileAndWait");
        }
    }

    private void createPbrFile(ArrayList<byte[]> records) {
        if (records == null) {
            mPbrFile = null;
            mIsPbrPresent = false;
            return;
        }
        mPbrFile = new PbrFile(records);
    }

    @Override
    public void handleMessage(Message msg) {
        AsyncResult ar;

        switch(msg.what) {
        case EVENT_PBR_LOAD_DONE:
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                createPbrFile((ArrayList<byte[]>)ar.result);
                /*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
		createPbrFileSfi((ArrayList<byte[]>)ar.result);//xuyang test for write contacts
                /*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
            }
            synchronized (mLock) {
                mLock.notify();
            }
            break;
        case EVENT_USIM_ADN_LOAD_DONE:
            log("Loading USIM ADN records done");
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                mPhoneBookRecords.addAll((ArrayList<AdnRecord>)ar.result);
            }
            synchronized (mLock) {
                mLock.notify();
            }
            break;
        case EVENT_IAP_LOAD_DONE:
            log("Loading USIM IAP records done");
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                mIapFileRecord = ((ArrayList<byte[]>)ar.result);
            }
            synchronized (mLock) {
                mLock.notify();
            }
            break;
        case EVENT_EMAIL_LOAD_DONE:
            log("Loading USIM Email records done");
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                mEmailFileRecord = ((ArrayList<byte[]>)ar.result);
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
	        byte[] emailRec = null;
    		 emailRec = mEmailFileRecord.get(0);
		  if(emailRec != null )
		  {
		  	Log.e(LOG_TAG, "MY EVENT_EMAIL_LOAD_DONE email len:"+emailRec.length+" " +IccUtils.bytesToHexString(emailRec));
		  }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
            }

            synchronized (mLock) {
                mLock.notify();
            }
            break;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
	case EVENT_ANR_LOAD_DONE:
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                mAnrFileRecord = ((ArrayList<byte[]>)ar.result);
				
	        byte[] anrRec = null;
		for(int i =0;i<mAnrFileRecord.size();i++){
    		 anrRec = mAnrFileRecord.get(i);
		  if(anrRec != null )
		  {
		  	Log.e(LOG_TAG, "ZX EVENT_ANR_LOAD_DONE number2 len:"+anrRec.length+" " +IccUtils.bytesToHexString(anrRec));
		  }
            }
            }
            synchronized (mLock) {
                mLock.notify();
            }
            break;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
//add by liandongzhou for td need the second the third number 20101221
	case EVENT_ANR2_LOAD_DONE:
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                mAnr2FileRecord = ((ArrayList<byte[]>)ar.result);
				
	        byte[] anrRec = null;
		for(int i =0;i<mAnr2FileRecord.size();i++){
    		 anrRec = mAnr2FileRecord.get(i);
		  if(anrRec != null )
		  {
		  	Log.e(LOG_TAG, "ZX EVENT_ANR_LOAD_DONE number3 len:"+anrRec.length+" " +IccUtils.bytesToHexString(anrRec));
		  }
            }
            }
            synchronized (mLock) {
                mLock.notify();
            }
            break;

	case EVENT_ANR3_LOAD_DONE:
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                mAnr3FileRecord = ((ArrayList<byte[]>)ar.result);

	        byte[] anrRec = null;
		for(int i =0;i<mAnr3FileRecord.size();i++){
    		 anrRec = mAnr3FileRecord.get(i);
		  if(anrRec != null )
		  {
		  	Log.e(LOG_TAG, "ZX EVENT_ANR_LOAD_DONE number4 len:"+anrRec.length+" " +IccUtils.bytesToHexString(anrRec));
		  }
            }
            }
            synchronized (mLock) {
                mLock.notify();
            }
            break;		

	case EVENT_SNE_LOAD_DONE:
            ar = (AsyncResult) msg.obj;
            if (ar.exception == null) {
                mSneFileRecord = ((ArrayList<byte[]>)ar.result);
	/*					
	        byte[] sneRec = null;
	
		for(int i =0;i<mSneFileRecord.size();i++){
    		 sneRec = mSneFileRecord.get(i);
		  if(sneRec != null )
		  {
		  	Log.e(LOG_TAG, " EVENT_SNE_LOAD_DONE sneRec len:"+sneRec.length+" " +IccUtils.bytesToHexString(sneRec));
		  }
            }*/
            }
            synchronized (mLock) {
                mLock.notify();
            }
            break;
//end add by liandongzhou for td need the second the third number 20101221
        }
    }

    private class PbrFile {
        // RecNum <EF Tag, efid>
        HashMap<Integer,Map<Integer,Integer>> mFileIds;

        PbrFile(ArrayList<byte[]> records) {
            mFileIds = new HashMap<Integer, Map<Integer, Integer>>();
            SimTlv recTlv;
            int recNum = 0;
            for (byte[] record: records) {
                recTlv = new SimTlv(record, 0, record.length);
                parseTag(recTlv, recNum);
                recNum ++;
            }
        }

        void parseTag(SimTlv tlv, int recNum) {
            SimTlv tlvEf;
            int tag;
            byte[] data;
            Map<Integer, Integer> val = new HashMap<Integer, Integer>();
            do {
                tag = tlv.getTag();
                switch(tag) {
                case USIM_TYPE1_TAG: // A8
                case USIM_TYPE3_TAG: // AA
                case USIM_TYPE2_TAG: // A9
                    data = tlv.getData();
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
		    if (data != null){
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
                    tlvEf = new SimTlv(data, 0, data.length);
                    parseEf(tlvEf, val, tag);
		    }
                    break;
                }
            } while (tlv.nextObject());
            mFileIds.put(recNum, val);
        }

        void parseEf(SimTlv tlv, Map<Integer, Integer> val, int parentTag) {
            int tag;
            byte[] data;
            int tagNumberWithinParentTag = 0;
            do {
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
                tag = tlv.getTag();
                if (parentTag == USIM_TYPE2_TAG && tag == USIM_EFANR_TAG) {
                    mAnrPresentInIap = true;
                    mAnrTagNumberInIap = tagNumberWithinParentTag;
                }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
                if (parentTag == USIM_TYPE2_TAG && tag == USIM_EFEMAIL_TAG) {
                    mEmailPresentInIap = true;
                    mEmailTagNumberInIap = tagNumberWithinParentTag;
                }
                switch(tag) {
                    case USIM_EFEMAIL_TAG:
                    case USIM_EFADN_TAG:
                    case USIM_EFEXT1_TAG:
                    case USIM_EFANR_TAG:
                    case USIM_EFPBC_TAG:
                    case USIM_EFGRP_TAG:
                    case USIM_EFAAS_TAG:
                    case USIM_EFGSD_TAG:
                    case USIM_EFUID_TAG:
                    case USIM_EFCCP1_TAG:
                    case USIM_EFIAP_TAG:
                    case USIM_EFSNE_TAG:
                        data = tlv.getData();
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
                        if (data != null){

                            //int efid = data[0] << 8 | data[1];
                            int efid = data[0] << 8 | (data[1] & 0xFF);
//add by liandongzhou for cannot read u900 the second phone number	20101220						
                            if(USIM_EFANR_TAG == tag && val.get(tag)!= null ){//we has get efid,can not overwrite it
                                Log.e("ZLian", "parseEf: val.get(USIM_EFANR2_TAG) =" +val.get(USIM_EFANR2_TAG));
                                if(val.get(USIM_EFANR2_TAG) == null){
                                    Log.e("ZLian", "val has anr, put anr2,  tag:0x"+Integer.toHexString(tag)+" parentTag:0x"+Integer.toHexString(parentTag)+" efid:0x"+Integer.toHexString(efid)+" ");	                        									
				        val.put(USIM_EFANR2_TAG, efid);
				    }else{
                                    Log.e("ZLian", "val has anr2 put anr3,  tag:0x"+Integer.toHexString(tag)+" parentTag:0x"+Integer.toHexString(parentTag)+" efid:0x"+Integer.toHexString(efid)+" ");	                        				    
				        val.put(USIM_EFANR3_TAG, efid);
				    }
                                                 
				    break; 
				}
//end add by liandongzhou for cannot read u900 the second phone number	20101220	
                        val.put(tag, efid);
                            if (tag == USIM_EFEXT1_TAG){ext1Efid = efid;}/*ZTE_CONTACTS_MAOYING_008 20100604 */
                            Log.e("ZLian", "MY parseEf  tag:0x"+Integer.toHexString(tag)+" parentTag:0x"+Integer.toHexString(parentTag)+" efid:0x"+Integer.toHexString(efid)+" ");	
                       }
                        break;
                }
                tagNumberWithinParentTag ++;
            } while(tlv.nextObject());
        }
    }

    private class PbrFileSfi {
        // RecNum <EF Tag, efid>
        HashMap<Integer,Map<Integer,Integer>> mSfiFileIds;

        PbrFileSfi(ArrayList<byte[]> records) {
            mSfiFileIds = new HashMap<Integer, Map<Integer, Integer>>();
            SimTlv recTlv;
            int recNum = 0;
            for (byte[] record: records) {
                recTlv = new SimTlv(record, 0, record.length);
                parseTag(recTlv, recNum);
                recNum ++;
            }
        }

        void parseTag(SimTlv tlv, int recNum) {
            SimTlv tlvEf;
            int tag;
            byte[] data;
            Map<Integer, Integer> val = new HashMap<Integer, Integer>();
            do {
                tag = tlv.getTag();
                switch(tag) {
                case USIM_TYPE1_TAG: // A8
                case USIM_TYPE3_TAG: // AA
                case USIM_TYPE2_TAG: // A9
                    data = tlv.getData();

		    if (data != null){

                    tlvEf = new SimTlv(data, 0, data.length);
                    parseEf(tlvEf, val, tag);
		    }
                    break;
                }
            } while (tlv.nextObject());
            mSfiFileIds.put(recNum, val);
        }

        void parseEf(SimTlv tlv, Map<Integer, Integer> val, int parentTag) {
            int tag;
            byte[] data;
            int tagNumberWithinParentTag = 0;
            do {
                tag = tlv.getTag();
                if (parentTag == USIM_TYPE2_TAG && tag == USIM_EFEMAIL_TAG) {
                    mEmailPresentInIap = true;
                    mEmailTagNumberInIap = tagNumberWithinParentTag;
                }
                switch(tag) {
                    case USIM_EFEMAIL_TAG:
                    case USIM_EFADN_TAG:
                    case USIM_EFEXT1_TAG:
                    case USIM_EFANR_TAG:
                    case USIM_EFPBC_TAG:
                    case USIM_EFGRP_TAG:
                    case USIM_EFAAS_TAG:
                    case USIM_EFGSD_TAG:
                    case USIM_EFUID_TAG:
                    case USIM_EFCCP1_TAG:
                    case USIM_EFIAP_TAG:
                    case USIM_EFSNE_TAG:
                        data = tlv.getData();

                        if (data != null){
                          if (data.length > 2){
                        int sfi = data[2];
                        val.put(tag, sfi);
                             log("MY  sfi parseEf ="+sfi);
                          }else{
                             val.put(tag, 0);
                             log("MY  Don't have sfi");
                          }
                        }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
                        break;
                }
                tagNumberWithinParentTag ++;
            } while(tlv.nextObject());
        }
    }
/*ZTE_CONTACTS_LIANDONGZHOU 2010-11-02 begin*/
    public int getUsimRecordSize() {
	   Log.e("ZLian", "getUsimRecordSize");
       int usimNumbers = 0;

	   if (mPhoneBookRecords != null){

       for (int i = 0; i < mPhoneBookRecords.size(); i++){   	
	   AdnRecord rec = mPhoneBookRecords.get(i);
	   //begin number error houjiong 2011.10.12		
	   if(!TextUtils.isEmpty(rec.getNumber()) || !TextUtils.isEmpty(rec.getAlphaTag())||rec.getEmails()!=null){
	   	usimNumbers++;
	   }else{
	   Log.e("ZLian", "error getUsimRecordSize =");
	   }
	   //end number error houjiong 2011.10.12
	   }
	}
       Log.e("ZLian", "MY getUsimRecordSize ="+usimNumbers);
	return usimNumbers;
    }
/*ZTE_CONTACTS_LIANDONGZHOU 2010-11-02 end*/
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    public int getEXT1efid() {
        Log.e(LOG_TAG, "MY ext1Efid ="+ext1Efid);
	return ext1Efid;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
    private void log(String msg) {
        if(DBG) Log.d(LOG_TAG, msg);
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    public ArrayList<AdnRecord> loadUsimRecord() {
	    Log.d(LOG_TAG, "MY loadUsimRecord ="+mPhoneBookRecords);
	    return mPhoneBookRecords;
	   
   }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
}
