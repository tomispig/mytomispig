/*
** Copyright 2007, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

package com.android.internal.telephony.gsm;

import android.os.Message;
import android.util.Log;

import com.android.internal.telephony.IccPhoneBookInterfaceManager;

//begin houjiong sim 20110902
import com.android.internal.telephony.IccConstants;
//end houjiong sim 20110902

/**
 * SimPhoneBookInterfaceManager to provide an inter-process communication to
 * access ADN-like SIM records.
 */


public class SimPhoneBookInterfaceManager extends IccPhoneBookInterfaceManager {
    static final String LOG_TAG = "GSM";

    public SimPhoneBookInterfaceManager(GSMPhone phone) {
        super(phone);
        adnCache = phone.mSIMRecords.getAdnCache();
        //NOTE service "simphonebook" added by IccSmsInterfaceManagerProxy
    }

    public void dispose() {
        super.dispose();
    }

    protected void finalize() {
        try {
            super.finalize();
        } catch (Throwable throwable) {
            Log.e(LOG_TAG, "Error while finalizing:", throwable);
        }
        if(DBG) Log.d(LOG_TAG, "SimPhoneBookInterfaceManager finalized");
    }

    public int[] getAdnRecordsSize(int efid) {
        if (DBG) logd("getAdnRecordsSize: efid=" + efid);
        synchronized(mLock) {
            checkThread();
            recordSize = new int[3];

            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);

            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the SIM");
            }
        }

        return recordSize;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 begin*/
    public int getSimTotalSize(int efid) {
	    return getAdnTotalSize(efid);
    }

    public int getExtensionSize(int efid) {
	    return getExt1Size(efid);
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101206 end*/
/*ZTE_CONTACTS_MAOYING_013 2010-06-25 end*/
    public int getSimSize(int efid) {
	return getAdnSize(efid);
            }
    public int getUsimSize(int efid) {
	return getUsimAdnSize();
        }
    public int getUsimAdnRecordsSize(int efid) {;
        return getPbrFileld();
    }
    public int getTagRecordsSize(int efid) {
	    int recordAdnSize;
        if (DBG) logd("getTagRecordsSize: efid=" + efid);
        synchronized(mLock) {
            checkThread();
            recordSize = new int[3];
			
            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);

            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the RUIM");
            }
        }
	// modify by liandongzhou for sometimes recordSize[0]  = 0 20101211
	if(recordSize != null && recordSize[0] > 14){
            recordAdnSize = recordSize[0]-14;
	}
	else{recordAdnSize = 14;} 
	// modify by liandongzhou for sometimes recordSize[0]  = 0 20101211				
        return recordAdnSize;
    }
      public int getEmailRecordsSize(int efid) {
	int recordEmailSize;
        if (DBG) logd("getEmailRecordsSize: efid=" + efid);
        synchronized(mLock) {
            checkThread();
            recordSize = new int[3];
            // modify by liandongzhou for cannot read email fileId. 20110311
			//
            // 4 is the empirical data, the general range of TD documents up to 4, w, only two,
            //and email in the second partition, so only one here before. If the partition is not more than 2, 
            //and have not found the two in efid, to partition 3 does not exist, the method in a direct return, not an error.                    
            for (int i = 0; i < 4; i++){
                efid = getGetEmailFileld(i);
                if (DBG) logd("for getGetEmailFileld: efid=" + efid);                
                if(efid != 0)break;   
            }
           
     //      if(efid == 0)getGetEmailFileld(1);
          // end modify by liandongzhou for cannot read email fileId. 20110311        
            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);
            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the SIM");
            }
        }
	// modify by liandongzhou for sometimes recordSize[0]  = 0 20101211		
	if(recordSize != null && recordSize[0] > 2){
            recordEmailSize = recordSize[0]-2;
	}
	else{recordEmailSize = 40;} 	//after exception , we need normal length for email, general,it is 40.	20110311
	// end modify by liandongzhou for sometimes recordSize[0]  = 0 20101211
        return recordEmailSize;
    }
    public int getAnrRecordsSize(int efid) {
			//begin houjiong sim 20110902
        if (DBG) logd("getAnrRecordsSize: efid=" + efid);		
				return 10;
       /* int recordAnrSize=20;
		//ZTE_lvliufang_ext1_20110712 begain
        if(IccConstants.EF_ADN == efid){
            int ext1recordSize[]=null;
            ext1recordSize = getAdnRecordsSize(IccConstants.EF_EXT1);
		     if (ext1recordSize != null){
                if (getExtensionSize(IccConstants.EF_ADN) >=ext1recordSize[2]){
                    recordAnrSize = 10;
                }
            }else{
                recordAnrSize = 10;
            }
            Log.e(LOG_TAG, "lvliufang getAnrRecordsSize recordAnrSize=" + recordAnrSize);
        }else{
            synchronized(mLock) {
            checkThread();
            recordSize = new int[3];
            // modify by liandongzhou for cannot read email fileId. 20110311
			//
            // 4 is the empirical data, the general range of TD documents up to 4, w, only two,
            //and email in the second partition, so only one here before. If the partition is not more than 2, 
            //and have not found the two in efid, to partition 3 does not exist, the method in a direct return, not an error.                  
            for (int i = 0; i < 4; i++){
                efid = getGetAnrFileld(i);
                if (DBG) logd("for getGetAnrFileld: efid=" + efid);                
                if(efid != 0)break;   
            }		
 //           efid = getGetAnrFileld(0);
            // end modify by liandongzhou for cannot read email fileId. 20110311
            //Using mBaseHandler, no difference in EVENT_GET_SIZE_DONE handling
            Message response = mBaseHandler.obtainMessage(EVENT_GET_SIZE_DONE);

            phone.getIccFileHandler().getEFLinearRecordSize(efid, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the SIM");
            }
        }
		    recordAnrSize = 10;
            return recordAnrSize;			
        }
		//ZTE_lvliufang_ext1_20110712 end
        return recordAnrSize;*/
			//end houjiong sim 20110902	
    }
/*ZTE_LIANDONGZHOU_3G 20101206 begin*/
      public boolean isSupportUsim() {
            return getIsSupUsim();
    }
      public boolean isSupportANR() {
            return getIsSupANR();
    }
      public boolean isSupportEmail() {
            return getIsSupEmail();
    }
//add by liandongzhou for td some cards not support sne(c3), 20110101
      public boolean isSupportSne() {
            return getIsSupSNE();
    }
//end add by liandongzhou for td some cards not support sne(c3), 20110101	  
//add by liandongzhou for td need the second the third number 20101223
    public int getAdditionalNumberCount(){
        Log.e("ZLian", "getAdditionalNumberCount: simphone run. ");
        if(getIsSupANR3())return 3;
        if(getIsSupANR2())return 2;
        if(getIsSupANR())return 1;	
	return 0;
    }
//end add by liandongzhou for td need the second the third number 20101223

    protected void logd(String msg) {
        Log.d(LOG_TAG, "[SimPbInterfaceManager] " + msg);
    }

    protected void loge(String msg) {
        Log.e(LOG_TAG, "[SimPbInterfaceManager] " + msg);
    }
}

