/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony.gsm.stk;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.widget.Toast;

import com.android.internal.telephony.IccUtils;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.gsm.SimCard;
import com.android.internal.telephony.gsm.SIMFileHandler;
import com.android.internal.telephony.gsm.SIMRecords;

import android.util.Config;
import android.text.format.Time;
import android.os.SystemProperties;
import com.android.internal.telephony.GsmAlphabet; 
import com.android.internal.telephony.EncodeException;

import java.io.ByteArrayOutputStream;

//gjc 20110330 test for cp reset
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import android.util.Log;

/**
 * Enumeration for representing the tag value of COMPREHENSION-TLV objects. If
 * you want to get the actual value, call {@link #value() value} method.
 *
 * {@hide}
 */
enum ComprehensionTlvTag {
  COMMAND_DETAILS(0x01),
  DEVICE_IDENTITIES(0x02),
  RESULT(0x03),
  DURATION(0x04),
  ALPHA_ID(0x05),
  USSD_STRING(0x0a),
  TEXT_STRING(0x0d),
  TONE(0x0e),
  ITEM(0x0f),
  ITEM_ID(0x10),
  RESPONSE_LENGTH(0x11),
  FILE_LIST(0x12),
  HELP_REQUEST(0x15),
  DEFAULT_TEXT(0x17),
  EVENT_LIST(0x19),
  ICON_ID(0x1e),
  ITEM_ICON_ID_LIST(0x1f),
  IMMEDIATE_RESPONSE(0x2b),
  LANGUAGE(0x2d),
  URL(0x31),
  BROWSER_TERMINATION_CAUSE(0x34),
  TEXT_ATTRIBUTE(0x50),
  ITEM_TEXT_ATTRIBUTE_LIST(0x51),
  //3GPP 11.14
  LOCATION_INFORMATION(0x13),
  IMEI(0x14),
  NETWORK_MEASUREMENT_RESULT(0x16),
  DATA_TIME_TIME_ZONE(0x26),
  TIMING_ADVANCE(0x2E),
  TRANSACTION_ID(0x9C);

    private int mValue;

    ComprehensionTlvTag(int value) {
        mValue = value;
    }

    /**
     * Returns the actual value of this COMPREHENSION-TLV object.
     *
     * @return Actual tag value of this object
     */
        public int value() {
            return mValue;
        }

    public static ComprehensionTlvTag fromInt(int value) {
        for (ComprehensionTlvTag e : ComprehensionTlvTag.values()) {
            if (e.mValue == value) {
                return e;
            }
        }
        return null;
    }
}

class RilMessage {
    int mId;
    Object mData;
    ResultCode mResCode;

    RilMessage(int msgId, String rawData) {
        mId = msgId;
        mData = rawData;
    }

    RilMessage(RilMessage other) {
        this.mId = other.mId;
        this.mData = other.mData;
        this.mResCode = other.mResCode;
    }
}

/**
 * Class that implements SIM Toolkit Telephony Service. Interacts with the RIL
 * and application.
 *
 * {@hide}
 */
public class StkService extends Handler implements AppInterface {

    // Class members
    private static SIMRecords mSimRecords;

    // Service members.
    private static StkService sInstance;
    private CommandsInterface mCmdIf;
    private Context mContext;
    private StkCmdMessage mCurrntCmd = null;
    private StkCmdMessage mMenuCmd = null;
    private StkCmdMessage mEventCmd = null;

    private RilMessageDecoder mMsgDecoder = null;

    //gjc 20110330 test for cp reset
    private int mCPResetDisableSTKProactiveCmd = 0;

    // Service constants.
    static final int MSG_ID_SESSION_END              = 1;
    static final int MSG_ID_PROACTIVE_COMMAND        = 2;
    static final int MSG_ID_EVENT_NOTIFY             = 3;
    static final int MSG_ID_CALL_SETUP               = 4;
    static final int MSG_ID_REFRESH                  = 5;
    static final int MSG_ID_RESPONSE                 = 6;

    static final int MSG_ID_RIL_MSG_DECODED          = 10;
    //gjc 20110330 test for cp reset
    static final int MSG_ID_CP_RESET = 11;
    static final int MSG_ID_SIGNAL_STRENGTH_UPDATE          = 12;

    // Events to signal SIM presence or absent in the device.
    private static final int MSG_ID_SIM_LOADED       = 20;
    static final int MSG_ID_CALL_SETUP_STATUS        = 30;
    static final int MSG_ID_SEND_SM_STATUS           = 31;
    static final int MSG_ID_CALL_SETUP_RESULT        = 32;
    static final int MSG_ID_SEND_SS_USSD_RESULT      = 33;
    static final int MSG_ID_EVENT_RESPONSE           = 34;

    private static final int MSG_ID_DELAY_SEND_SM_STATUS = 35;
    private static final int DELAY_TIME = 1000;  //1s

    private static final int DEV_ID_KEYPAD      = 0x01;
    private static final int DEV_ID_DISPLAY     = 0x02;
    private static final int DEV_ID_EARPIECE    = 0x03;
    private static final int DEV_ID_UICC        = 0x81;
    private static final int DEV_ID_TERMINAL    = 0x82;
    private static final int DEV_ID_NETWORK     = 0x83;

    /* Intentionally private for singleton */
    private StkService(CommandsInterface ci, SIMRecords sr, Context context,
            SIMFileHandler fh, SimCard sc) {
        if (ci == null || sr == null || context == null || fh == null
                || sc == null) {
            throw new NullPointerException(
                    "Service: Input parameters must not be null");
        }
        mCmdIf = ci;
        mContext = context;

        // Get the RilMessagesDecoder for decoding the messages.
        mMsgDecoder = RilMessageDecoder.getInstance(this, fh);

        // Register ril events handling.
        mCmdIf.setOnStkSessionEnd(this, MSG_ID_SESSION_END, null);
        mCmdIf.setOnStkProactiveCmd(this, MSG_ID_PROACTIVE_COMMAND, null);
        mCmdIf.setOnStkEvent(this, MSG_ID_EVENT_NOTIFY, null);
        mCmdIf.setOnStkCallSetUp(this, MSG_ID_CALL_SETUP, null);
        //mCmdIf.setOnSimRefresh(this, MSG_ID_REFRESH, null);
        mCmdIf.setOnStkCallSetUpStatus(this, MSG_ID_CALL_SETUP_STATUS, null);
        mCmdIf.setOnStkSendSmStatus(this, MSG_ID_SEND_SM_STATUS, null);
        mCmdIf.setOnStkCallSetUpResult(this, MSG_ID_CALL_SETUP_RESULT, null);
        mCmdIf.setOnStkSendUssdResult(this,MSG_ID_SEND_SS_USSD_RESULT, null);

        //gjc 20110330 test for cp reset
        mCmdIf.setOnSignalStrengthUpdate(this,MSG_ID_SIGNAL_STRENGTH_UPDATE,null);

        mSimRecords = sr;

        // Register for SIM ready event.
        mSimRecords.registerForRecordsLoaded(this, MSG_ID_SIM_LOADED, null);

        mCmdIf.reportStkServiceIsRunning(null);
        StkLog.d(this, "StkService: is running");
    }

    public void dispose() {
        mSimRecords.unregisterForRecordsLoaded(this);
        mCmdIf.unSetOnStkSessionEnd(this);
        mCmdIf.unSetOnStkProactiveCmd(this);
        mCmdIf.unSetOnStkEvent(this);
        mCmdIf.unSetOnStkCallSetUp(this);
        mCmdIf.unSetOnStkCallSetUpStatus(this);
        mCmdIf.unSetOnStkSendSmStatus(this);
        mCmdIf.unSetOnStkCallSetUpResult(this);
        mCmdIf.unSetOnStkSendUssdResult(this);

        //gjc 20110330 test for cp reset
        mCmdIf.unSetOnSignalStrengthUpdate(this);

        this.removeCallbacksAndMessages(null);
    }

    protected void finalize() {
        StkLog.d(this, "Service finalized");
    }

    private void handleRilMsg(RilMessage rilMsg) {
	 Log.i("STK_FRAMWORK","++++++handleRilMsg+++++"+rilMsg+""+rilMsg.mId+""+rilMsg.mData);
        if (rilMsg == null) {
            return;
        }

        // dispatch messages
        CommandParams cmdParams = null;
        switch (rilMsg.mId) {
        case MSG_ID_EVENT_NOTIFY:
            if (rilMsg.mResCode == ResultCode.OK) {
                cmdParams = (CommandParams) rilMsg.mData;
                if (cmdParams != null) {
                    handleProactiveCommand(cmdParams);
                }
            }
            break;
        case MSG_ID_PROACTIVE_COMMAND:
            cmdParams = (CommandParams) rilMsg.mData;
            if (cmdParams != null) {
                if (rilMsg.mResCode == ResultCode.OK) {
                    handleProactiveCommand(cmdParams);
                } else {
                    // for proactive commands that couldn't be decoded
                    // successfully respond with the code generated by the
                    // message decoder.
                    sendTerminalResponse(cmdParams.cmdDet, rilMsg.mResCode,
                            false, 0, null);
                }
            }
            break;
        case MSG_ID_REFRESH:
            cmdParams = (CommandParams) rilMsg.mData;
            if (cmdParams != null) {
                handleProactiveCommand(cmdParams);
            }
            break;
        case MSG_ID_SESSION_END:
            handleSessionEnd();
            break;
        case MSG_ID_CALL_SETUP:
            // prior event notify command supplied all the information
            // needed for set up call processing.
            break;
        }
    }

    /* linda add for Provide Local Information */
    private static byte DateToByte(int v) {
        byte b;
        b = (byte) (((v%10)<<4)|((v/10)%10));
        return b;
    }

    /**
     * Handles RIL_UNSOL_STK_PROACTIVE_COMMAND unsolicited command from RIL.
     * Sends valid proactive command data to the application using intents.
     *
     */
    private void handleProactiveCommand(CommandParams cmdParams) {
        Log.i("STK_FRAMWORK","handleProactiveCommand"+ cmdParams.getCommandType().name());

        StkCmdMessage cmdMsg = new StkCmdMessage(cmdParams);
        switch (cmdParams.getCommandType()) {
        case SET_UP_MENU:
            if (removeMenu(cmdMsg.getMenu())) {
                mMenuCmd = null;
            } else {
                mMenuCmd = cmdMsg;
            }
            sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, false, 0,
                    null);
            break;
        case DISPLAY_TEXT:
/* Android added by GanHuiliang_2011-9-6 *** cp contrl policy BEGIN */
			if (mCPResetDisableSTKProactiveCmd > 0)
			{
				if (!cmdMsg.geTextMessage().responseNeeded)
				{
					sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, false,
							0, null);
				}
				else
				{
					sendTerminalResponse(cmdParams.cmdDet, ResultCode.BACKWARD_MOVE_BY_USER, false,
							0, null);
				}
				return;
			}
/* Android added by GanHuiliang_2011-9-6 END */
            // when application is not required to respond, or need not user clear, send an immediate
            // response.
            if (!cmdMsg.geTextMessage().responseNeeded) {
                sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, false,
                        0, null);
            }
            break;
        case REFRESH:
            // ME side only handles refresh commands which meant to remove IDLE
            // MODE TEXT.
            //cmdParams.cmdDet.typeOfCommand = CommandType.SET_UP_IDLE_MODE_TEXT
            //       .value();

            // MY - send REFRESH Terminal response
            sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, false, 0,
                    null);

            //Here only display refresh type.
            if((cmdMsg.getRefreshSettings().fileList != null)&&(cmdMsg.getRefreshSettings().fileChanged == true)) {
                Toast.makeText(mContext, "Refreshing... SIM data has changed.", Toast.LENGTH_LONG).show();
            } else if(cmdMsg.getRefreshSettings().fileChanged == false) {
                Toast.makeText(mContext, "Refreshing SIM data", Toast.LENGTH_LONG).show();
            }
            return;
        case SET_UP_IDLE_MODE_TEXT:
            sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, false,
                    0, null);
            break;
        case SET_UP_EVENT_LIST:
            sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, false, 0, null);
			//begin houjiong 2011.02.22 guqi sim card error
			StkLog.d(this,"set_up_event_list, eventType="+((SetEventListParams)cmdParams).events);
			if(((SetEventListParams)cmdParams).events==null){
				return;
			}else{

            mEventCmd = cmdMsg;
			}
			//end houjiong 2011.02.22 guqi sim card error

            if((mEventCmd.getEventSettings().events.length == 1) 
                    && (mEventCmd.getEventSettings().events[0] == EventList.REMOVE_EVENT.value())){  // remove event
                StkLog.d(this, "Remove Event");
                //Intent intent = new Intent(AppInterface.STK_EVENT_REMOVE_EVENT);
                //mContext.sendBroadcast(intent);
                /* here set mEventCmd null, so all previous pending event response will return directly, see  handleEventResponse fuction
                                 so we don't need consider how to control application's states, all the response from app will be discarded*/ 
                mEventCmd = null;  
            } else {
                Intent intent = new Intent(AppInterface.STK_CMD_ACTION);
                intent.putExtra("STK CMD", cmdMsg);
                mContext.sendBroadcast(intent);
            }
            return;
        case LAUNCH_BROWSER:
        case SELECT_ITEM:
        case GET_INPUT:
        case GET_INKEY:
        case SEND_DTMF:
        case SEND_SMS:
        case SEND_SS:
        case SEND_USSD:
        case PLAY_TONE:
        case SET_UP_CALL:
            // nothing to do on telephony!
            break;
        case PROVIDE_LOCAL_INFORMATION:
            CommandDetails localInfoDet = cmdParams.cmdDet;
            switch(localInfoDet.commandQualifier) {
            case 0x03:
                byte[] additionInfo = new byte[9]; //one byte for tag, one byte for len=7, seven bytes for data
                long now = System.currentTimeMillis(); //obtain system time
                Time startDate =  new Time(Time.TIMEZONE_UTC);
                startDate.set(now);
                additionInfo[0] = (byte)(0x80 | ComprehensionTlvTag.DATA_TIME_TIME_ZONE.value());
                additionInfo[1] = 0x07;
                additionInfo[2] = DateToByte(startDate.year);
                additionInfo[3] = DateToByte(startDate.month+1);
                additionInfo[4] = DateToByte(startDate.monthDay);
                additionInfo[5] = DateToByte(startDate.hour);
                additionInfo[6] = DateToByte(startDate.minute);
                additionInfo[7] = DateToByte(startDate.second);
                additionInfo[8] = (byte)0xFF;
                sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, true, additionInfo);
                break;
            case 0x04:
                additionInfo = new byte[4]; //one byte for tag, one byte for len=2, two bytes for data
                additionInfo[0] = (byte)(0x80 | ComprehensionTlvTag.LANGUAGE.value());
                additionInfo[1] = 0x02;
                String sysl = SystemProperties.get("persist.sys.language");
                if(sysl == null) {
                    //use not set system language, will use product language
                    sysl = SystemProperties.get("ro.product.locale.language");
                }
                try {
                    byte[] encode1 = GsmAlphabet.stringToGsm7BitPacked(sysl.substring(0,1));
                    additionInfo[2] = encode1[1];
                    String hexString1 = IccUtils.bytesToHexString(encode1);
                    byte[] encode2 = GsmAlphabet.stringToGsm7BitPacked(sysl.substring(1));
                    String hexString2 = IccUtils.bytesToHexString(encode2);
                    additionInfo[3] = encode2[1];
                    StkLog.d(this, "language is = " + sysl + ", " + hexString1 + ", " + hexString2);
                } catch (EncodeException ex) {
                    StkLog.d(this, "lauange ecode failed use en as the default values");
                    additionInfo[2] = 0x65;
                    additionInfo[3] = 0x6E;
                }
                sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, true, additionInfo);
                break;
            }
            return;
        case LANGUAGE_NOTIFICATION:
            sendTerminalResponse(cmdParams.cmdDet, ResultCode.OK, false, 0, null);
            return;
        default:
            StkLog.d(this, "Unsupported command");
            return;
        }
        //gjc 20110330 test for cp reset
        if (mCPResetDisableSTKProactiveCmd == 2)
        {
            StkLog.d(this, "CP Reset, change state to normal");
            mCPResetDisableSTKProactiveCmd = 0;
        }		
        if (mCPResetDisableSTKProactiveCmd > 0)
        {
            StkLog.d(this,"CP Reset, donnot send CMD to stk app");
            return;
        }		
        mCurrntCmd = cmdMsg;
        Intent intent = new Intent(AppInterface.STK_CMD_ACTION);
        intent.putExtra("STK CMD", cmdMsg);
        mContext.sendBroadcast(intent);
    }

    /**
     * Handles RIL_UNSOL_STK_SESSION_END unsolicited command from RIL.
     *
     */
    private void handleSessionEnd() {
        StkLog.d(this, "SESSION END");

        //gjc 20110330 test for cp reset
        if (mCPResetDisableSTKProactiveCmd == 2)
        {
            StkLog.d(this, "CP Reset, change state to normal");
            mCPResetDisableSTKProactiveCmd = 0;
        }				
        if (mCPResetDisableSTKProactiveCmd > 0)
        {
            StkLog.d(this,"CP Reset, donnot send SESSION END to stk app");
            return;
        }		
        mCurrntCmd = mMenuCmd;
        Intent intent = new Intent(AppInterface.STK_SESSION_END_ACTION);
        mContext.sendBroadcast(intent);
    }

    private void sendTerminalResponse(CommandDetails cmdDet,
            ResultCode resultCode, boolean includeAdditionalInfo,
            int additionalInfo, ResponseData resp) {

        if (cmdDet == null) {
            return;
        }
        ByteArrayOutputStream buf = new ByteArrayOutputStream();

        // command details
        int tag = ComprehensionTlvTag.COMMAND_DETAILS.value();
        if (cmdDet.compRequired) {
            tag |= 0x80;
        }
        buf.write(tag);
        buf.write(0x03); // length
        buf.write(cmdDet.commandNumber);
        buf.write(cmdDet.typeOfCommand);
        buf.write(cmdDet.commandQualifier);

        // device identities
        tag = 0x80 | ComprehensionTlvTag.DEVICE_IDENTITIES.value();
        buf.write(tag);
        buf.write(0x02); // length
        buf.write(DEV_ID_TERMINAL); // source device id
        buf.write(DEV_ID_UICC); // destination device id

        // result
        tag = 0x80 | ComprehensionTlvTag.RESULT.value();
        buf.write(tag);
        int length = includeAdditionalInfo ? 2 : 1;
        buf.write(length);
        buf.write(resultCode.value());

        // additional info
        if (includeAdditionalInfo) {
            buf.write(additionalInfo);
        }

        // Fill optional data for each corresponding command
        if (resp != null) {
            resp.format(buf);
        } else {
            //TS 102 384,27.22.4.2.8.4.2
            //If it is a response for GET_INKEY command 
            //and the response timeout has occured, then 
            //add DURATION Tlv for variable timeout.
            Input cmdInput = null;
            if(mCurrntCmd != null) {
                cmdInput = mCurrntCmd.geInput();
                StkLog.d(this, "linda test cmdInput = " + cmdInput);
            }
            if ((cmdDet.typeOfCommand == AppInterface.CommandType.GET_INKEY.value())
                && (resultCode.value() == ResultCode.NO_RESPONSE_FROM_USER.value())) {
                if(cmdInput != null && cmdInput.duration != null) {
                    tag = 0x80 | ComprehensionTlvTag.DURATION.value();
                    buf.write(tag);
                    buf.write(0x02);//length
                    buf.write(cmdInput.duration.timeUnit.SECOND.value()); //Time Unit, Seconds
                    buf.write(cmdInput.duration.timeInterval); 
                }
            }
        }

        byte[] rawData = buf.toByteArray();
        String hexString = IccUtils.bytesToHexString(rawData);
        if (Config.LOGD) {
            StkLog.d(this, "TERMINAL RESPONSE: " + hexString);
        }

        mCmdIf.sendTerminalResponse(hexString, null);
    }

    /* linda add additional send terminal response */
    private void sendTerminalResponse(CommandDetails cmdDet,
            ResultCode resultCode, boolean includeByteInfo,
            byte[] byteInfo) {

        if (cmdDet == null) {
            return;
        }
        ByteArrayOutputStream buf = new ByteArrayOutputStream();

        // command details
        int tag = ComprehensionTlvTag.COMMAND_DETAILS.value();
        if (cmdDet.compRequired) {
            tag |= 0x80;
        }
        buf.write(tag);
        buf.write(0x03); // length
        buf.write(cmdDet.commandNumber);
        buf.write(cmdDet.typeOfCommand);
        buf.write(cmdDet.commandQualifier);

        // device identities
        tag = 0x80 | ComprehensionTlvTag.DEVICE_IDENTITIES.value();
        buf.write(tag);
        buf.write(0x02); // length
        buf.write(DEV_ID_TERMINAL); // source device id
        buf.write(DEV_ID_UICC); // destination device id

        // result
        tag = 0x80 | ComprehensionTlvTag.RESULT.value();
        buf.write(tag);
        int length = 1;
        buf.write(length);
        buf.write(resultCode.value());

        // additional info
        if (includeByteInfo) {
          for (byte b : byteInfo) {
                buf.write(b);
           }  
        }

        byte[] rawData = buf.toByteArray();
        String hexString = IccUtils.bytesToHexString(rawData);
        if (Config.LOGD) {
            StkLog.d(this, "TERMINAL RESPONSE: " + hexString);
        }

        mCmdIf.sendTerminalResponse(hexString, null);
    }

    private void sendMenuSelection(int menuId, boolean helpRequired) {

        ByteArrayOutputStream buf = new ByteArrayOutputStream();

        // tag
        int tag = BerTlv.BER_MENU_SELECTION_TAG;
        buf.write(tag);

        // length
        buf.write(0x00); // place holder

        // device identities
        tag = 0x80 | ComprehensionTlvTag.DEVICE_IDENTITIES.value();
        buf.write(tag);
        buf.write(0x02); // length
        buf.write(DEV_ID_KEYPAD); // source device id
        buf.write(DEV_ID_UICC); // destination device id

        // item identifier
        tag = 0x80 | ComprehensionTlvTag.ITEM_ID.value();
        buf.write(tag);
        buf.write(0x01); // length
        buf.write(menuId); // menu identifier chosen

        // help request
        if (helpRequired) {
            tag = ComprehensionTlvTag.HELP_REQUEST.value();
            buf.write(tag);
            buf.write(0x00); // length
        }

        byte[] rawData = buf.toByteArray();

        // write real length
        int len = rawData.length - 2; // minus (tag + length)
        rawData[1] = (byte) len;

        String hexString = IccUtils.bytesToHexString(rawData);

        mCmdIf.sendEnvelope(hexString, null);
    }

    private void eventDownload(int event, int sourceId, int destinationId,
            int[] additionalInfo, boolean oneShot) {

        ByteArrayOutputStream buf = new ByteArrayOutputStream();

        // tag
        int tag = BerTlv.BER_EVENT_DOWNLOAD_TAG;
        buf.write(tag);

        // length
        buf.write(0x00); // place holder, assume length < 128.

        // event list
        tag = 0x80 | ComprehensionTlvTag.EVENT_LIST.value();
        buf.write(tag);
        buf.write(0x01); // length
        buf.write(event); // event value

        // device identities
        tag = 0x80 | ComprehensionTlvTag.DEVICE_IDENTITIES.value();
        buf.write(tag);
        buf.write(0x02); // length
        buf.write(sourceId); // source device id
        buf.write(destinationId); // destination device id

        // additional information
        // linda TS 102.223 all eventdownload  the event list object shall contain only one event(value part of length 1 byte)
        /*if (additionalInfo != null) {
            for (byte b : additionalInfo) {
                buf.write(b);
            }
        }*/
        
        StkLog.d(this, "eventDownload event = " + event);
        if(event == EventList.LANGUAGE_SELECTION.value()) {
            tag = 0x80 | ComprehensionTlvTag.LANGUAGE.value();
            buf.write(tag);
            buf.write(0x02); //length
            for (int b : additionalInfo) {
                buf.write(b);
            }
        } else if(event == EventList.BROWER_TERMINATION.value()) {
            tag = 0x80 | ComprehensionTlvTag.BROWSER_TERMINATION_CAUSE.value();
            buf.write(tag);
            buf.write(0x01);//length 1
            for (int b : additionalInfo) {
                buf.write(b);
            }
        }else if(event == EventList.CALL_CONNECTED.value()) {
            tag = 0x80 | ComprehensionTlvTag.TRANSACTION_ID.value();
            buf.write(tag);
            buf.write(0x01);//length 1
            for (int b : additionalInfo) {
                buf.write(b);
            }
        }

        byte[] rawData = buf.toByteArray();

        // write real length
        int len = rawData.length - 2; // minus (tag + length)
        rawData[1] = (byte) len;

        String hexString = IccUtils.bytesToHexString(rawData);
        if (Config.LOGD) {
            StkLog.d(this, "ENVELOPE COMMAND: " + hexString);
        }

        mCmdIf.sendEnvelope(hexString, null);
    }

    /**
     * Used for instantiating/updating the Service from the GsmPhone constructor.
     *
     * @param ci CommandsInterface object
     * @param sr SIMRecords object
     * @param context phone app context
     * @param fh SIM file handler
     * @param sc GSM SIM card
     * @return The only Service object in the system
     */
    public static StkService getInstance(CommandsInterface ci, SIMRecords sr,
            Context context, SIMFileHandler fh, SimCard sc) {
        if (sInstance == null) {
            if (ci == null || sr == null || context == null || fh == null
                    || sc == null) {
                return null;
            }
            HandlerThread thread = new HandlerThread("Stk Telephony service");
            thread.start();
            sInstance = new StkService(ci, sr, context, fh, sc);
            StkLog.d(sInstance, "NEW sInstance");
        } else if ((sr != null) && (mSimRecords != sr)) {
            StkLog.d(sInstance, "Reinitialize the Service with SIMRecords");
            mSimRecords = sr;

            // re-Register for SIM ready event.
            mSimRecords.registerForRecordsLoaded(sInstance, MSG_ID_SIM_LOADED, null);
            StkLog.d(sInstance, "sr changed reinitialize and return current sInstance");
        } else {
            StkLog.d(sInstance, "Return current sInstance");
        }
        return sInstance;
    }

    /**
     * Used by application to get an AppInterface object.
     *
     * @return The only Service object in the system
     */
    public static AppInterface getInstance() {
        return getInstance(null, null, null, null, null);
    }

    @Override
    public void handleMessage(Message msg) {

        switch (msg.what) {
        case MSG_ID_SESSION_END:
        case MSG_ID_PROACTIVE_COMMAND:
        case MSG_ID_EVENT_NOTIFY:
        case MSG_ID_REFRESH:
            StkLog.d(this, "ril message arrived");
            String data = null;
            if (msg.obj != null) {
                AsyncResult ar = (AsyncResult) msg.obj;
                if (ar != null && ar.result != null) {
                    try {
                        data = (String) ar.result;
                    } catch (ClassCastException e) {
                        break;
                    }
                }
            }
            mMsgDecoder.sendStartDecodingMessageParams(new RilMessage(msg.what, data));
            break;
        case MSG_ID_CALL_SETUP:
            mMsgDecoder.sendStartDecodingMessageParams(new RilMessage(msg.what, null));
            break;
        case MSG_ID_SIM_LOADED:
            break;
        case MSG_ID_RIL_MSG_DECODED:
            StkLog.d(this, "ril message decode msg.obj =" + msg.obj);
            handleRilMsg((RilMessage) msg.obj);
            break;
        case MSG_ID_RESPONSE:
            handleCmdResponse((StkResponseMessage) msg.obj);
            break;
        case MSG_ID_CALL_SETUP_STATUS:
            if(msg.obj != null) {
                AsyncResult ar = (AsyncResult) msg.obj;
                if(ar != null && ar.result != null) {
                    try {
                        //"D8 len 01 02 status operationType alphaIdLen
                        data = (String) ar.result;
                        StkLog.d(this, "data len = " + data.length());
                        byte[] Buf = new byte[data.length()/2];
                        Buf = IccUtils.hexStringToBytes(data);
                        if(Buf.length < 5) {
                           StkLog.d(this, "call setup dataus data error");
                        } else if (Buf[4] == 0x00) {
                           Toast.makeText(mContext, "Allowed, no modification", Toast.LENGTH_LONG).show();
                        } else if (Buf[4] == 0x02) {
                           Toast.makeText(mContext, "not Allowed", Toast.LENGTH_LONG).show();
                        } else if (Buf[4] == 0x01) {
                           Toast.makeText(mContext, "Allowed, with modification", Toast.LENGTH_LONG).show();
                        } 
                    } catch (ClassCastException e) {
                        StkLog.d(this, "call setup status get exception");
                        break;
                    }
                }
            }
            break;
        case MSG_ID_SEND_SM_STATUS:
            //delay 1s to deal with it, waiting the EventNotify(SEND SMS display firstly
            if(msg.obj != null) {
                Message delayMsg = this.obtainMessage(MSG_ID_DELAY_SEND_SM_STATUS, msg.obj);
                sendMessageDelayed(delayMsg, DELAY_TIME);
            }

            break;
        case MSG_ID_CALL_SETUP_RESULT:
            if(msg.obj != null) {
                AsyncResult ar = (AsyncResult) msg.obj;
                if(ar != null && ar.result != null) {
                    try {
                        //D9 03 01 01 status
                        data = (String) ar.result;
                        StkLog.d(this, "call setup result data is =" + data);
                        StkLog.d(this, "data len = " + data.length());
                        byte[] Buf = new byte[data.length()/2];
                        Buf = IccUtils.hexStringToBytes(data);
                        if(Buf.length < 5) {
                           StkLog.d(this, "call setup status data error");
                        } else if (Buf[4] == 0x00) {
                            Toast.makeText(mContext, "The user's choice is rejected", Toast.LENGTH_LONG).show();
                        } else if (Buf[4] == 0x01) {
                            Toast.makeText(mContext, "The user's choice is accepted", Toast.LENGTH_LONG).show();
                        } else {
                            //do nothing, this message only return result status(success or failed)
                        }
                    } catch (ClassCastException e) {
                        StkLog.d(this, "call setup status get exception");
                        break;
                    }
                }
            }
            break;
        case MSG_ID_SEND_SS_USSD_RESULT:
            if(msg.obj != null) {
                AsyncResult ar = (AsyncResult) msg.obj;
                if(ar != null && ar.result != null) {
                    try {
                        //DC 04 01 01 status operationType
                        data = (String) ar.result;
                        StkLog.d(this, "send ss ussd result data is =" + data);
                        StkLog.d(this, "data len = " + data.length());
                        byte[] Buf = new byte[data.length()/2];
                        Buf = IccUtils.hexStringToBytes(data);
                        if(Buf.length < 6) {
                           StkLog.d(this, "send ss ussd result data error");
                        } else if (Buf[4] == 0x00) {
                            Toast.makeText(mContext, "Not Done", Toast.LENGTH_LONG).show();
                        } else if (Buf[4] == 0x01) {
                            Toast.makeText(mContext, "Done", Toast.LENGTH_LONG).show();
                        } else {
                            //do nothing, this message only return result status(success or failed)
                        }
                    } catch (ClassCastException e) {
                        StkLog.d(this, "send ss ussd status get exception");
                        break;
                    }
                }
            }
            break;
        case MSG_ID_DELAY_SEND_SM_STATUS:
            if(msg.obj != null) {
                AsyncResult ar = (AsyncResult) msg.obj;
                if(ar != null && ar.result != null) {
                    try {
                        //"DA len 01 01 status alphaIdLen
                        data = (String) ar.result;
                        StkLog.d(this, "data len = " + data.length());
                        byte[] Buf = new byte[data.length()/2];
                        Buf = IccUtils.hexStringToBytes(data);
                        if(Buf.length < 5) {
                           StkLog.d(this, "send sms status data error");
                        } else {
                            //delay 1s send Intent to App
                            int status = Buf[4]&0xFF;
                            StkLog.d(this, "status = " + status);
                            Intent intent = new Intent(AppInterface.STK_EVENT_SEND_SM_STATUS);
                            intent.putExtra("STK SendSmStatus", status);
                            mContext.sendBroadcast(intent);
                        }
                    } catch (ClassCastException e) {
                        StkLog.d(this, "send sm status get exception");
                        break;
                    }
                }
            }
            break;
        case MSG_ID_EVENT_RESPONSE:
            handleEventResponse((StkResponseMessage) msg.obj);
            break;

         //gjc 20110330 test for cp reset
        case MSG_ID_SIGNAL_STRENGTH_UPDATE:
            AsyncResult ar = (AsyncResult) msg.obj;
            int[] ints = (int[])ar.result;
            if(ints.length >= 2 && ints[0] == 67 && ints[1] == 89) {
                StkLog.d(this, "CSQ:67, 89 is regarded as CP Assert!");
                try {
                    FileReader file =  new FileReader("data/system/CPConfig.cfg");
                    char []buf = new char[8];
                    file.read(buf, 0, 8);
                    file.close();

                    if (buf[0] != 1)//0 enable,1 disable, 2 dealy ,3 test
                    {
                        StkLog.d(this, "CP Assert and CP Reset Enable, disable stk proactive cmd");
                        mCPResetDisableSTKProactiveCmd = 1;
                    }					
                }catch (FileNotFoundException e) {
					
            } catch (IOException e) {
					
            }				
        }
        break;
        default:
            throw new AssertionError("Unrecognized STK command: " + msg.what);
        }
    }

    public synchronized void onCmdResponse(StkResponseMessage resMsg) {
	 Log.i("STK_FRAMWORK","++++WPZ++++StkResponseMessage+++="+resMsg);
        if (resMsg == null) {
            return;
        }
        // queue a response message.
        Message msg = this.obtainMessage(MSG_ID_RESPONSE, resMsg);
        msg.sendToTarget();
    }

    public synchronized void onEventResponse(StkResponseMessage resMsg) {
        if (resMsg == null) {
            return;
        }
        //queue a response event
        Message msg = this.obtainMessage(MSG_ID_EVENT_RESPONSE, resMsg);
        msg.sendToTarget();
    }

    private boolean validateResponse(StkResponseMessage resMsg) {
        if (mCurrntCmd != null) {
            return (resMsg.cmdDet.compareTo(mCurrntCmd.mCmdDet));
        }
        return false;
    }

    private boolean removeMenu(Menu menu) {
	 Log.i("STK_FRAMWORK","++++wpz++++removeMenu+++="+menu.items.size()+menu.items.get(0) );
        try {
            if (menu.items.size() == 1 && menu.items.get(0) == null) {
                return true;
            }
        } catch (NullPointerException e) {
            StkLog.d(this, "Unable to get Menu's items size");
            return true;
        }
        return false;
    }

    private void handleEventResponse(StkResponseMessage eventMsg) {
        if(mEventCmd == null) {
            return;
        }
        CommandDetails cmdDet = eventMsg.getCmdDetails();
        switch (AppInterface.CommandType.fromInt(cmdDet.typeOfCommand)) {
        case SET_UP_EVENT_LIST:
            if (eventMsg.eventValue == 0x05 ) {
                    // IDLE_SCREEN_AVAILABLE
                    eventDownload(eventMsg.eventValue,DEV_ID_DISPLAY,DEV_ID_UICC,eventMsg.additionalInfo,false);
                } else
                    eventDownload(eventMsg.eventValue,DEV_ID_TERMINAL,DEV_ID_UICC,eventMsg.additionalInfo,false);
                mEventCmd = null;
            break;
        default:
            StkLog.d(this, "here must control event");
            return;
        }
    }
                
    private void handleCmdResponse(StkResponseMessage resMsg) {
        // Make sure the response details match the last valid command. An invalid
        // response is a one that doesn't have a corresponding proactive command
        // and sending it can "confuse" the baseband/ril.
        // One reason for out of order responses can be UI glitches. For example,
        // if the application launch an activity, and that activity is stored
        // by the framework inside the history stack. That activity will be
        // available for relaunch using the latest application dialog
        // (long press on the home button). Relaunching that activity can send
        // the same command's result again to the StkService and can cause it to
        // get out of sync with the SIM.
        if (!validateResponse(resMsg)) {
        StkLog.d(this, "StkService : the response is not valid");
        return;
        }
        //gjc 20110330 test for cp reset
        if (mCPResetDisableSTKProactiveCmd == 1)
        {
            StkLog.d(this, "CP Reset, change state to waiting CMD");
            mCPResetDisableSTKProactiveCmd = 2;
        }		
        ResponseData resp = null;
        boolean helpRequired = false;
        CommandDetails cmdDet = resMsg.getCmdDetails();
	 Log.i("STK_FRAMWORK","++++++handleCmdResponse+++++"+resMsg.resCode+""+cmdDet);
        switch (resMsg.resCode) {
        case HELP_INFO_REQUIRED:
            helpRequired = true;
            // fall through
        case OK:
        case PRFRMD_WITH_PARTIAL_COMPREHENSION:
        case PRFRMD_WITH_MISSING_INFO:
        case PRFRMD_WITH_ADDITIONAL_EFS_READ:
        case PRFRMD_ICON_NOT_DISPLAYED:
        case PRFRMD_MODIFIED_BY_NAA:
        case PRFRMD_LIMITED_SERVICE:
        case PRFRMD_WITH_MODIFICATION:
        case PRFRMD_NAA_NOT_ACTIVE:
        case PRFRMD_TONE_NOT_PLAYED:
            switch (AppInterface.CommandType.fromInt(cmdDet.typeOfCommand)) {
            case SET_UP_MENU:
                helpRequired = resMsg.resCode == ResultCode.HELP_INFO_REQUIRED;
                sendMenuSelection(resMsg.usersMenuSelection, helpRequired);
                return;
            case SELECT_ITEM:
                resp = new SelectItemResponseData(resMsg.usersMenuSelection);
                break;
            case GET_INPUT:
            case GET_INKEY:
                Input input = mCurrntCmd.geInput();
                if (!input.yesNo) {
                    // when help is requested there is no need to send the text
                    // string object.
                    if (!helpRequired) {
                        resp = new GetInkeyInputResponseData(resMsg.usersInput,
                                input.ucs2, input.packed);
                    }
                } else {
                    resp = new GetInkeyInputResponseData(
                            resMsg.usersYesNoSelection);
                }
                break;
            case DISPLAY_TEXT:
                //if not response needed or not need userclear, Stk Service has already sent response, so return here
                if(!mCurrntCmd.geTextMessage().responseNeeded)
                    return;

            case LAUNCH_BROWSER:
                break;
            case SET_UP_CALL:
                mCmdIf.handleCallSetupRequestFromSim(resMsg.usersConfirm, null);
                // No need to send terminal response for SET UP CALL. The user's
                // confirmation result is send back using a dedicated ril message
                // invoked by the CommandInterface call above.
                mCurrntCmd = null;
                return;
            }
            break;
        case NO_RESPONSE_FROM_USER:
        case UICC_SESSION_TERM_BY_USER:
        case BACKWARD_MOVE_BY_USER:
        //case TERMINAL_CRNTLY_UNABLE_TO_PROCESS :
            resp = null;
            break;
        //linda change, according to the spec, if the genernal result"terminal currently unable to process command",
        //it is mandatory for the terminal to provide additional information.
        case TERMINAL_CRNTLY_UNABLE_TO_PROCESS:
            sendTerminalResponse(cmdDet, resMsg.resCode, true, 1, null);
            if(AppInterface.CommandType.fromInt(cmdDet.typeOfCommand) == AppInterface.CommandType.SET_UP_MENU) {
                mCurrntCmd = mMenuCmd;
            } else {
                mCurrntCmd = null;
            }
            return;
        default:
            return;
        }
        sendTerminalResponse(cmdDet, resMsg.resCode, false, 0, resp);
        if(AppInterface.CommandType.fromInt(cmdDet.typeOfCommand) == AppInterface.CommandType.SET_UP_MENU) {
            mCurrntCmd = mMenuCmd;
        } else {
            mCurrntCmd = null;
        }
    }
}
