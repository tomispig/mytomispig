/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony;

import android.content.pm.PackageManager;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.ServiceManager;
/*ZTE_CONTACTS_MAOYING_013 2010-06-25 begin*/
import android.telephony.PhoneNumberUtils;
import android.util.Log;
import java.util.ArrayList;
/*ZTE_CONTACTS_MAOYING_018 20100709 end*/
import java.util.List;

/**
 * SimPhoneBookInterfaceManager to provide an inter-process communication to
 * access ADN-like SIM records.
 */
public abstract class IccPhoneBookInterfaceManager extends IIccPhoneBook.Stub {
    protected static final boolean DBG = true;

    protected PhoneBase phone;
    protected AdnRecordCache adnCache;
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
    //protected final Object mLock = new Object();
    protected Object mLock = new Object();
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 end*/
    protected int recordSize[];
    protected boolean success;
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
    protected boolean usimsuccess;
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
    protected List<AdnRecord> records;

    protected static final boolean ALLOW_SIM_OP_IN_UI_THREAD = false;

    protected static final int EVENT_GET_SIZE_DONE = 1;
    protected static final int EVENT_LOAD_DONE = 2;
    protected static final int EVENT_UPDATE_DONE = 3;
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
    protected static final int EVENT_USIM_UPDATE_DONE = 4;
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/

    protected Handler mBaseHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            AsyncResult ar;

            switch (msg.what) {
                case EVENT_GET_SIZE_DONE:
                    ar = (AsyncResult) msg.obj;
                    synchronized (mLock) {
                        if (ar.exception == null) {
                            recordSize = (int[])ar.result;
                            // recordSize[0]  is the record length
                            // recordSize[1]  is the total length of the EF file
                            // recordSize[2]  is the number of records in the EF file
                            logd("GET_RECORD_SIZE Size " + recordSize[0] +
                                    " total " + recordSize[1] +
                                    " #record " + recordSize[2]);                    
                        }
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
	//		    else{
	//			recordSize = null;
	//		   }
                            mLock.notifyAll();
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 end*/
                    }
                    break;
                case EVENT_UPDATE_DONE:
                    ar = (AsyncResult) msg.obj;
                    synchronized (mLock) {
                        success = (ar.exception == null);
		        if(ar.exception == null) logd("Success update ADN records");
			else logd("Cannot update ADN records");
                        mLock.notifyAll();
                    }
                    break;
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
                case EVENT_USIM_UPDATE_DONE:
                    ar = (AsyncResult) msg.obj;
                    synchronized (mLock) {
                        usimsuccess = (ar.exception == null);
		        if(ar.exception == null) logd("MY Success update ADN records");
			else logd("MY Cannot update ADN records");
                        mLock.notifyAll();
                    }
                    break;
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 end*/
                case EVENT_LOAD_DONE:
                    ar = (AsyncResult)msg.obj;
                    synchronized (mLock) {
                        if (ar.exception == null) {
                            records = (List<AdnRecord>)
                                    ((ArrayList<AdnRecord>) ar.result);
                        } else {
                            if(DBG) logd("Cannot load ADN records");
                            if (records != null) {
                                records.clear();
                            }
                        }
                        mLock.notifyAll();
                    }
                    break;
            }
        }
    };

    public IccPhoneBookInterfaceManager(PhoneBase phone) {
        this.phone = phone;
    }

    public void dispose() {
    }

    protected void publish() {
        //NOTE service "simphonebook" added by IccSmsInterfaceManagerProxy
        ServiceManager.addService("simphonebook", this);
    }

    protected abstract void logd(String msg);

    protected abstract void loge(String msg);

    /**
     * Replace oldAdn with newAdn in ADN-like record in EF
     *
     * getAdnRecordsInEf must be called at least once before this function,
     * otherwise an error will be returned. Currently the email field
     * if set in the ADN record is ignored.
     * throws SecurityException if no WRITE_CONTACTS permission
     *
     * @param efid must be one among EF_ADN, EF_FDN, and EF_SDN
     * @param oldTag adn tag to be replaced
     * @param oldPhoneNumber adn number to be replaced
     *        Set both oldTag and oldPhoneNubmer to "" means to replace an
     *        empty record, aka, insert new record
     * @param newTag adn tag to be stored
     * @param newPhoneNumber adn number ot be stored
     *        Set both newTag and newPhoneNubmer to "" means to replace the old
     *        record with empty one, aka, delete old record
     * @param pin2 required to update EF_FDN, otherwise must be null
     * @return true for success
     */
    public boolean
    updateAdnRecordsInEfBySearch (int efid,
            String oldTag, String oldPhoneNumber,
            String newTag, String newPhoneNumber, String pin2) {


        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }
        int pbrIndex = 0;

        if (DBG) logd("updateAdnRecordsInEfBySearch: efid=" + efid +
                " ("+ oldTag + "," + oldPhoneNumber + ")"+ "==>" +
                " ("+ newTag + "," + newPhoneNumber + ")"+ " pin2=" + pin2);
        synchronized(mLock) {
            checkThread();
            success = false;
            Message response = mBaseHandler.obtainMessage(EVENT_UPDATE_DONE);
            AdnRecord oldAdn = new AdnRecord(oldTag, oldPhoneNumber);
            AdnRecord newAdn = new AdnRecord(newTag, newPhoneNumber);
	    adnCache.updateAdnBySearch(efid, pbrIndex, oldAdn, newAdn, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }
        return success;
    }
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
    public boolean
    updateEmailRecordsInEfBySearch (int efid,
            String newTag, String newPhoneNumber,
            String newEmail, String pin2) {


        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }

	String[] newEmails = null;
	newEmails = new String[1];
	newEmails[0] = newEmail;//"aaa@aaa.com";
        int index = -1;
	int pbrIndex = 0;

        if (DBG) logd("updateAdnEmailRecordsInEfBySearch: efid=" + efid +
                " ("+ newTag + "," + newPhoneNumber + ")"+ " pin2=" + pin2);
        synchronized(mLock) {
            checkThread();
            success = false;
            Message response = mBaseHandler.obtainMessage(EVENT_UPDATE_DONE);
            //AdnRecord oldAdn = new AdnRecord(oldTag, oldPhoneNumber);
	    AdnRecord newAdn = new AdnRecord(newTag, newPhoneNumber, newEmails);
	    index = adnCache.searchAdnIndex(efid, newAdn);
	    efid = getGetEmailFileld(pbrIndex);
	    if(index == -1) {
	        return false;
	    }
            adnCache.updateEmailByIndex(efid, pbrIndex, newAdn, index, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }

        return success;
    }

    public boolean
    updateEmailRecordsInEfByIndex (int efid, 
            String newTag, String newPhoneNumber,
            String newEmail, int recordNumber, String pin2) {


        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }

	String[] newEmails = null;
	newEmails = new String[1];
	newEmails[0] = newEmail;//"aaa@aaa.com";
        int pbrIndex = 0;

        if (DBG) logd("updateEmailRecordsInEfByIndex: efid=" + efid +
                " ("+ newTag + "," + newPhoneNumber +","+newEmail+")"+recordNumber+ " pin2=" + pin2);
        synchronized(mLock) {
            checkThread();
/*ZTE_CONTACTS_MAOYING_018 20100709 delete begin*/
            //success = false;
            //Message response = mBaseHandler.obtainMessage(EVENT_UPDATE_DONE);
/*ZTE_CONTACTS_MAOYING_018 20100709 delete end*/
/*ZTE_CONTACTS_MAOYING_018 20100709  begin*/
            usimsuccess = false;
            Message response = mBaseHandler.obtainMessage(EVENT_USIM_UPDATE_DONE);
/*ZTE_CONTACTS_MAOYING_018 20100709  end*/
            //AdnRecord oldAdn = new AdnRecord(oldTag, oldPhoneNumber);
	    AdnRecord newAdn = new AdnRecord(newTag, newPhoneNumber, newEmails);
	    if(recordNumber == -1) {
	        return false;
	    }
            adnCache.updateEmailByIndex(efid, pbrIndex, newAdn, recordNumber, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }

/*ZTE_CONTACTS_MAOYING_018 20100709  begin*/
        //return success;
        return usimsuccess;
/*ZTE_CONTACTS_MAOYING_018 20100709  end*/
    }
    public boolean
    updateIapRecordsInEfByIndex(int efid, 
            String newTag, String newPhoneNumber,
            int newIap, int recordNumber, String pin2) {

        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }

        int pbrIndex = 0;

        if (DBG) logd("updateIapRecordsInEfByIndex: efid=" + efid + " recordNumber=" + recordNumber);
        synchronized(mLock) {
            checkThread();
/*ZTE_CONTACTS_MAOYING_018 20100709 delete begin*/
            //success = false;
            //Message response = mBaseHandler.obtainMessage(EVENT_UPDATE_DONE);
 /*ZTE_CONTACTS_MAOYING_018 20100709 delete end*/
 /*ZTE_CONTACTS_MAOYING_018 20100709  begin*/
            usimsuccess = false;
            Message response = mBaseHandler.obtainMessage(EVENT_USIM_UPDATE_DONE);
 /*ZTE_CONTACTS_MAOYING_018 20100709  end*/
            //AdnRecord oldAdn = new AdnRecord(oldTag, oldPhoneNumber);
	    AdnRecord newAdn = new AdnRecord(newTag, newPhoneNumber, newIap);
	    if(recordNumber == -1) {
	        return false;
	    }
            adnCache.updateIapByIndex(efid, pbrIndex, newAdn, recordNumber, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }

/*ZTE_CONTACTS_MAOYING_018 20100709  begin*/
        //return success;
        return usimsuccess;
/*ZTE_CONTACTS_MAOYING_018 20100709  end*/
    }
/*
    public boolean
    updateAnrRecordsInEfByIndex (int efid, 
            String newTag, String newPhoneNumber, String newEmail,
            String newAnr, int recordNumber, String pin2) {


        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }

	String[] newEmails = null;
	newEmails = new String[1];
	newEmails[0] = newEmail;

        int pbrIndex = 0;

        if (DBG) logd("updateAnrRecordsInEfByIndex: efid=" + efid +
                " ("+ newTag + "," + newPhoneNumber +","+ newAnr+")"+ " pin2=" + pin2);
        synchronized(mLock) {
            checkThread();

            usimsuccess = false;
            Message response = mBaseHandler.obtainMessage(EVENT_USIM_UPDATE_DONE);

	    AdnRecord newAdn = new AdnRecord(newTag, newPhoneNumber, newEmails, newAnr);
	    if(recordNumber == -1) {
	        return false;
	    }
            adnCache.updateAnrByIndex(efid, pbrIndex, newAdn, recordNumber, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }
        return usimsuccess;
    }
	*/
//modify by liandongzhou for td need the second the third number 20101222		
    public boolean
    updateAnrRecordsInEfByIndex (int efid, AdnRecord newAdn,int recordNumber, String pin2, int anrIndex) {


        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }
		
       if(newAdn ==null)return false;

        int pbrIndex = 0;

        synchronized(mLock) {
            checkThread();
            usimsuccess = false;
            Message response = mBaseHandler.obtainMessage(EVENT_USIM_UPDATE_DONE);

	    if(recordNumber == -1) {
	        return false;
	    }
            adnCache.updateAnrByIndex(efid, pbrIndex, newAdn, recordNumber, pin2, response, anrIndex);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }
        return usimsuccess;
    }
//end modify by liandongzhou for td need the second the third number 20101222	
//add by liandongzhou for td need the second the third number 20101222	
    public boolean
    updateSneRecordsInEfByIndex (int efid, AdnRecord newAdn, int recordNumber, String pin2) {


        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }

        int pbrIndex = 0;

        synchronized(mLock) {
            checkThread();
            usimsuccess = false;
            Message response = mBaseHandler.obtainMessage(EVENT_USIM_UPDATE_DONE);
	    if(recordNumber == -1) {
	        return false;
	    }
            adnCache.updateSneByIndex(efid, pbrIndex, newAdn, recordNumber, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
        }

        //return success;
        return usimsuccess;
    }

//end add by liandongzhou for td need the second the third number 20101222	

//modify by liandongzhou for td need the second the third number 20101222	
    public boolean
    updateAdnEmailRecordsInEfBySearch (int efid,
            String oldTag, String oldPhoneNumber, String oldEmail, String oldAnr,String oldNumber3, String oldNumber4,String oldNickname,
            String newTag, String newPhoneNumber, String newEmail, String newAnr, String newNumber3, String newNumber4,String newNickname,String pin2) {


        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }
        efid = changeEfForIccType(efid);
        String[] oldEmails = null;
        oldEmails = new String[1];
        oldEmails[0] = oldEmail;
/*ZTE_CONTACTS_MAOYING_004 2010-05-14 temp begin */
        //if (oldEmail == "") oldEmails = null;
/*ZTE_CONTACTS_MAOYING_004 2010-05-14 temp end */
        String[] newEmails = null;
        newEmails = new String[1];
        newEmails[0] = newEmail;//"aaa@aaa.com";
        int recordNumber = -1;
        int pbrIndex = 0;
        //String newAnr = "0123456789";

        if (DBG) logd("updateAdnEmailRecordsInEfBySearch: efid=" + efid +
                " ("+ oldTag + "," + oldPhoneNumber + ","+oldEmail+","+oldAnr+")"+ "==>" +
                " ("+ newTag + "," + newPhoneNumber +","+newEmail+","+ newAnr+")"+" pin2=" + pin2);
         AdnRecord newAdn = new AdnRecord(newTag, newPhoneNumber, newEmails, newAnr, newNumber3, newNumber4, newNickname);		
        synchronized(mLock) {
            checkThread();
            success = false;
            Message response = mBaseHandler.obtainMessage(EVENT_UPDATE_DONE);
            AdnRecord oldAdn = new AdnRecord(oldTag, oldPhoneNumber, oldEmails, oldAnr, oldNumber3, oldNumber4, oldNickname);
            recordNumber = adnCache.updateAdnBySearch(efid, pbrIndex, oldAdn, newAdn, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by search");
            }
/*ZTE_CONTACTS_MAOYING_021 2010-08-11 begin */		
            //efid = getGetEmailFileld(pbrIndex);
/*ZTE_CONTACTS_MAOYING_021 2010-08-11 end */
	     if(recordNumber == -1) {
	        return false;
	     }
           }
        logd("MY 3G before efid ="+efid);
 	 if (success && efid != IccConstants.EF_FDN){
	     if (getIsSupEmail()){
              efid = getGetEmailFileld(pbrIndex);
              logd("MY 3G success="+success);
              updateEmailRecordsInEfByIndex(efid, newTag, newPhoneNumber, newEmail, recordNumber, pin2);
	    }else{
               newEmail = "";
           }
           if (getIsSupIAP()){
/*ZTE_USIM_MAOYING_001 2010-12-01 end */
              efid = getGetIapFileld(pbrIndex);
              if(recordNumber == -1) {
                 return false;
              }            
              if (newEmail == "" && newAnr==""){
                  updateIapRecordsInEfByIndex(efid, newTag, newPhoneNumber, -1, recordNumber, pin2);
              }else{
                  if(newEmails != null || newAnr !=""){
                     updateIapRecordsInEfByIndex(efid, newTag, newPhoneNumber, recordNumber, recordNumber, pin2);
	           }
	       }
/*ZTE_USIM_MAOYING_001 2010-12-01 begin */
           }
	    if (getIsSupANR()){
/*ZTE_USIM_MAOYING_001 2010-12-01 end */
              efid = getGetAnrFileld(pbrIndex);
              if(recordNumber == -1) {
                 return false;
              }
		updateAnrRecordsInEfByIndex(efid, newAdn, recordNumber, pin2, 0);
           }else{
               newAnr = "";
           }
//add by liandongzhou for td need the second the third number 20101222	
	    if (getIsSupANR2()){
              efid = getGetAnr2Fileld(pbrIndex);
              if(recordNumber == -1) {
                 return false;
              }
		updateAnrRecordsInEfByIndex(efid, newAdn, recordNumber, pin2, 1);

           }else{
               newNumber3 = "";
           }
	    if (getIsSupANR3()){

              efid = getGetAnr3Fileld(pbrIndex);
              if(recordNumber == -1) {
                 return false;
              }
		updateAnrRecordsInEfByIndex(efid, newAdn, recordNumber, pin2, 2);

           }else{
               newNumber4 = "";
           }
	    if (getIsSupSNE()){
              efid = getGetSneFileld(pbrIndex);
	       Log.e("ZLian"," update record,support sne efid = " +efid );			  
              if(recordNumber == -1) {
                 return false;
              }
		updateSneRecordsInEfByIndex(efid, newAdn, recordNumber, pin2);

           }else{
               newNickname = "";
           }
//end add by liandongzhou for td need the second the third number 20101222	
       }
         if (efid == IccConstants.EF_FDN){
	       usimsuccess = true;
         }
	  logd("MY 3G success , usimsuccess="+success+ " "+usimsuccess);
	  return success;
    }
//end modify by liandongzhou for td need the second the third number 20101222	
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 end*/
    /**
     * Update an ADN-like EF record by record index
     *
     * This is useful for iteration the whole ADN file, such as write the whole
     * phone book or erase/format the whole phonebook. Currently the email field
     * if set in the ADN record is ignored.
     * throws SecurityException if no WRITE_CONTACTS permission
     *
     * @param efid must be one among EF_ADN, EF_FDN, and EF_SDN
     * @param newTag adn tag to be stored
     * @param newPhoneNumber adn number to be stored
     *        Set both newTag and newPhoneNubmer to "" means to replace the old
     *        record with empty one, aka, delete old record
     * @param index is 1-based adn record index to be updated
     * @param pin2 required to update EF_FDN, otherwise must be null
     * @return true for success
     */
    public boolean
    updateAdnRecordsInEfByIndex(int efid, String newTag,
            String newPhoneNumber, int index, String pin2) {

        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.WRITE_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.WRITE_CONTACTS permission");
        }

        if (DBG) logd("updateAdnRecordsInEfByIndex: efid=" + efid +
                " Index=" + index + " ==> " +
                "("+ newTag + "," + newPhoneNumber + ")"+ " pin2=" + pin2);
        synchronized(mLock) {
            checkThread();
            success = false;
            Message response = mBaseHandler.obtainMessage(EVENT_UPDATE_DONE);
            AdnRecord newAdn = new AdnRecord(newTag, newPhoneNumber);
            adnCache.updateAdnByIndex(efid, newAdn, index, pin2, response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to update by index");
            }
        }
        return success;
    }

    /**
     * Get the capacity of records in efid
     *
     * @param efid the EF id of a ADN-like ICC
     * @return  int[3] array
     *            recordSizes[0]  is the single record length
     *            recordSizes[1]  is the total length of the EF file
     *            recordSizes[2]  is the number of records in the EF file
     */
    public abstract int[] getAdnRecordsSize(int efid);
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 begin*/
    public abstract int getExtensionSize(int efid);
    public abstract int getSimTotalSize(int efid);
    public abstract boolean isSupportUsim();
    public abstract boolean isSupportANR();
    public abstract boolean isSupportEmail();
    public abstract boolean isSupportSne();	
/* ZTE_CONTACTS_LIANDONGZHOU_3G_PB 20101208 end*/
    public abstract int getSimSize(int efid);
    public abstract int getUsimSize(int efid);
    public abstract int getUsimAdnRecordsSize(int efid);

/*ZTE_CONTACTS_MAOYING_007 2010-05-27 begin*/
    public abstract int getTagRecordsSize(int efid);
    public abstract int getEmailRecordsSize(int efid);
    public abstract int getAnrRecordsSize(int efid);
/*ZTE_CONTACTS_MAOYING_007 2010-05-27 end*/

//add by liandongzhou for td need the second the third number 20101223
    public abstract int getAdditionalNumberCount();
//end add by liandongzhou for td need the second the third number 20101223
    /**
     * Loads the AdnRecords in efid and returns them as a
     * List of AdnRecords
     *
     * throws SecurityException if no READ_CONTACTS permission
     *
     * @param efid the EF id of a ADN-like ICC
     * @return List of AdnRecord
     */
    public List<AdnRecord> getAdnRecordsInEf(int efid) {

        if (phone.getContext().checkCallingOrSelfPermission(
                android.Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException(
                    "Requires android.permission.READ_CONTACTS permission");
        }

        efid = updateEfForIccType(efid);
        if (DBG) logd("getAdnRecordsInEF: efid=" + efid);

        synchronized(mLock) {
            checkThread();
            Message response = mBaseHandler.obtainMessage(EVENT_LOAD_DONE);
            adnCache.requestLoadAllAdnLike(efid, adnCache.extensionEfForEf(efid), response);
            try {
                mLock.wait();
            } catch (InterruptedException e) {
                logd("interrupted while trying to load from the SIM");
            }
        }
            return records;
    }

    protected void checkThread() {
        if (!ALLOW_SIM_OP_IN_UI_THREAD) {
            // Make sure this isn't the UI thread, since it will block
            if (mBaseHandler.getLooper().equals(Looper.myLooper())) {
                loge("query() called on the main UI thread!");
                throw new IllegalStateException(
                        "You cannot call query on this provder from the main UI thread.");
            }
        }
    }

    private int updateEfForIccType(int efid) {
        // Check if we are trying to read ADN records
        if (efid == IccConstants.EF_ADN) {
//modify by liandongzhou for isApplicationOnIcc sometimes cannot get right value for USIM. 20110104			
//	 Log.d("ZLian","updateEfForIccType efid =28474");			
 //           if (phone.getIccCard().isApplicationOnIcc(IccCardApplication.AppType.APPTYPE_USIM)) {
 //               return IccConstants.EF_PBR;
  //          }
	    if(phone.getIccCard().getIccCardType()  == IccCard.ICC_CARD_TYPE_USIM
			|| phone.getIccCard().getIccCardType()  == IccCard.ICC_CARD_TYPE_RUIM){
	       Log.d("ZLian","updateEfForIccType getIccCardType()  == IccCard.ICC_CARD_TYPE_USIM ");	
                return IccConstants.EF_PBR;
            }
        }
//end modify by liandongzhou for isApplicationOnIcc sometimes cannot get right value for USIM. 20110104		
        return efid;
    }
    /*ZTE_CONTACTS_LIANDONGZHOU 2010-11-02 begin*/
    public int
    getPbrFileld(){
        return adnCache.requestPbrFileld();
    } 
   public int
    getExt1Size(int efid){
        return adnCache.requestEXT1Size(efid);
    }

   public int
    getAdnSize(int efid){
        return adnCache.requestAdnSize(efid);
    }

   public int
    getAdnTotalSize(int efid){
    	int mRecordTotalSize = -1;
	 Log.d("GSM","MY getAdnTotalSize....................");
        mRecordTotalSize = adnCache.requestAdnTotalSize(efid);
    	Log.d("GSM", "MY getAdnTotalSize................mRecordTotalSize = " +mRecordTotalSize);
    	return mRecordTotalSize;
    }
    public int
    getUsimAdnSize(){
        return adnCache.requestUsimAdnSize();
    }  

    public boolean
    getIsSupUsim(){
        return adnCache.requestIsSupUsim();
    }
    public boolean
    getIsSupANR(){
        return adnCache.requestIsSupANR();
    }
//add by liandongzhou for td need the second the third number 20101222
    public boolean
    getIsSupANR2(){
        return adnCache.requestIsSupANR2();
    }
	
    public boolean
    getIsSupANR3(){
        return adnCache.requestIsSupANR3();
    }

    public boolean
    getIsSupSNE(){
        return adnCache.requestIsSupSNE();
    }
	
//end add by liandongzhou for td need the second the third number 20101222	

    public boolean
    getIsSupEmail(){
        return adnCache.requestIsSupEmail();
    }
    public boolean
    getIsSupIAP(){
        return adnCache.requestIsSupIAP();
    }

    public int
    getGetAdnFileld(int index){
        return adnCache.requestGetAdnFileld(index);
    }       

    public int
    getGetEmailFileld(int index){
        return adnCache.requestGetEmailFileld(index);
    }
    public int
    getGetIapFileld(int index){
        return adnCache.requestGetIapFileld(index);
    }

    public int
    getGetAnrFileld(int index){
        return adnCache.requestGetAnrFileld(index);
    }   
//add by liandongzhou for td need the second the third number 20101222	
    public int
    getGetAnr2Fileld(int index){
        return adnCache.requestGetAnr2Fileld(index);
    }   
    public int
    getGetAnr3Fileld(int index){
        return adnCache.requestGetAnr3Fileld(index);
    }   
    public int
    getGetSneFileld(int index){
        return adnCache.requestGetSneFileld(index);
    }   	
//end add by liandongzhou for td need the second the third number 20101222	
    private int changeEfForIccType(int efid) {
        // Check if we are trying to read ADN records
        if (efid == IccConstants.EF_ADN) {
            if (phone.getIccCard().isApplicationOnIcc(IccCardApplication.AppType.APPTYPE_USIM)) {
                return adnCache.requestGetAdnFileld(0);
            }
        }
        return efid;
    }
    public boolean getSimCardType() {
        return phone.getIccCard().isApplicationOnIcc(IccCardApplication.AppType.APPTYPE_USIM);
    }
    /*ZTE_CONTACTS_LIANDONGZHOU 2010-11-03 end*/    
}

