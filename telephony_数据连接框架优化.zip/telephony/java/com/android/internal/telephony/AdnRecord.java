/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony;

import android.os.Parcel;
import android.os.Parcelable;
import android.telephony.PhoneNumberUtils;
import android.util.Log;

import com.android.internal.telephony.GsmAlphabet;

import java.util.Arrays;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
import com.android.internal.telephony.gsm.UsimPhoneBookManager;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/

// add by liandongzhou for td need the second the third number 20101221
import android.text.TextUtils;
//end add by liandongzhou for td need the second the third number 20101221
/**
 *
 * Used to load or store ADNs (Abbreviated Dialing Numbers).
 *
 * {@hide}
 *
 */
public class AdnRecord implements Parcelable {
    static final String LOG_TAG = "GSM";

    //***** Instance Variables

    String alphaTag = "";
    String number = "";
    String[] emails;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    int iap = -1;
    String anr = "";
// add by liandongzhou for td need the second the third number 20101221
    String anr2 = "";
    String anr3 = "";
    String sne = "";	
//end  add by liandongzhou for td need the second the third number 20101221
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
    int extRecord = 0xff;
    int efid;                   // or 0 if none
    int recordNumber;           // or 0 if none
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    private UsimPhoneBookManager mUsimPhoneBookManager;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
    //***** Constants

    // In an ADN record, everything but the alpha identifier
    // is in a footer that's 14 bytes
    static final int FOOTER_SIZE_BYTES = 14;

    // Maximum size of the un-extended number field
    static final int MAX_NUMBER_SIZE_BYTES = 11;

    static final int EXT_RECORD_LENGTH_BYTES = 13;
    static final int EXT_RECORD_TYPE_ADDITIONAL_DATA = 2;
    static final int EXT_RECORD_TYPE_MASK = 3;
    static final int MAX_EXT_CALLED_PARTY_LENGTH = 0xa;

    // ADN offset
    static final int ADN_BCD_NUMBER_LENGTH = 0;
    static final int ADN_TON_AND_NPI = 1;
    static final int ADN_DAILING_NUMBER_START = 2;
    static final int ADN_DAILING_NUMBER_END = 11;
    static final int ADN_CAPABILITY_ID = 12;
    static final int ADN_EXTENSION_ID = 13;

    //***** Static Methods

    public static final Parcelable.Creator<AdnRecord> CREATOR
            = new Parcelable.Creator<AdnRecord>() {
        public AdnRecord createFromParcel(Parcel source) {
            int efid;
            int recordNumber;
            String alphaTag;
            String number;
            String[] emails;

	    String anr;
// add by liandongzhou for td need the second the third number 20101223
	    String anr2;
	    String anr3;	
	    String sne;	
//end add by liandongzhou for td need the second the third number 20101223		
            efid = source.readInt();
            recordNumber = source.readInt();
            alphaTag = source.readString();
            number = source.readString();
            emails = source.readStringArray();
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
	    anr = source.readString();
// add by liandongzhou for td need the second the third number 20101221
	    anr2 = source.readString();
	    anr3 = source.readString();	
	    sne = source.readString();			
// end add by liandongzhou for td need the second the third number 20101221		
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
            return new AdnRecord(efid, recordNumber, alphaTag, number, emails, anr, anr2, anr3,sne);
        }

        public AdnRecord[] newArray(int size) {
            return new AdnRecord[size];
        }
    };


    //***** Constructor
    public AdnRecord (byte[] record) {
        this(0, 0, record);
    }

    public AdnRecord (int efid, int recordNumber, byte[] record) {
        this.efid = efid;
        this.recordNumber = recordNumber;
        parseRecord(record);
    }

    public AdnRecord (String alphaTag, String number) {
        this(0, 0, alphaTag, number);
    }

    public AdnRecord (String alphaTag, String number, String[] emails) {
        this(0, 0, alphaTag, number, emails);
    }

    public AdnRecord (int efid, int recordNumber, String alphaTag, String number, String[] emails) {
        this.efid = efid;
        this.recordNumber = recordNumber;
        this.alphaTag = alphaTag;
        this.number = number;
        this.emails = emails;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
        this.anr = "";
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
// add by liandongzhou for td need the second the third number 20101221
        this.anr2 = "";
        this.anr3 = "";
        this.sne = "";		
//end  add by liandongzhou for td need the second the third number 20101221
    }

/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    public AdnRecord (String alphaTag, String number,  int iap) {
        this.efid = 0;
        this.recordNumber = 0;
        this.alphaTag = alphaTag;
        this.number = number;
        this.emails = null;
	this.anr = "";
	this.iap = iap;
// add by liandongzhou for td need the second the third number 20101221	
       this.anr2 = "";
       this.anr3 = "";	
	this.sne = "";
// end add by liandongzhou for td need the second the third number 20101221	   
    }

    public AdnRecord (String alphaTag, String number,  String anr) {
        this(0, 0, alphaTag, number, null,  anr,"","","");
    }

    public AdnRecord (String alphaTag, String number, String[] emails, String anr) {
        this(0, 0, alphaTag, number, emails, anr,"","","");
    }
// add by liandongzhou for td need the second the third number 20101221	
    public AdnRecord (String alphaTag, String number, String[] emails, String anr, String anr2) {
        this(0, 0, alphaTag, number, emails, anr,anr2,"","");
    } 

    public AdnRecord (String alphaTag, String number, String[] emails, String anr, String anr2, String anr3) {
        this(0, 0, alphaTag, number, emails, anr, anr2, anr3,"");
    } 
    public AdnRecord (String alphaTag, String number, String[] emails, String anr, String anr2, String anr3, String sne) {
        this(0, 0, alphaTag, number, emails, anr, anr2, anr3,sne);
    } 	
// end add by liandongzhou for td need the second the third number 20101221		
    public AdnRecord (int efid, int recordNumber, String alphaTag, String number, String[] emails, String anr,String anr2, String anr3, String sne) {
        this.efid = efid;
        this.recordNumber = recordNumber;
        this.alphaTag = alphaTag;
        this.number = number;
        this.emails = emails;
	 this.anr = anr;
// add by liandongzhou for td need the second the third number 20101221	
       this.anr2 = anr2;
       this.anr3 = anr3;	
       this.sne = sne;		   
// end add by liandongzhou for td need the second the third number 20101221	  
    }

/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
    public AdnRecord(int efid, int recordNumber, String alphaTag, String number) {
        this.efid = efid;
        this.recordNumber = recordNumber;
        this.alphaTag = alphaTag;
        this.number = number;
        this.emails = null;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
	this.anr = "";
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
// add by liandongzhou for td need the second the third number 20101221	
       this.anr2 = "";
       this.anr3 = "";	
       this.sne = "";		   
// end add by liandongzhou for td need the second the third number 20101221	
    }

    //***** Instance Methods

    public String getAlphaTag() {
        return alphaTag;
    }

    public String getNumber() {
        return number;
    }

    public String[] getEmails() {
        return emails;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    public String getAnr() {
        return anr;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
// add by liandongzhou for td need the second the third number 20101221	
    public String getAnr2() {
        return anr2;
    }
    public String getAnr3() {
        return anr3;
    }
    public String getSne() {
        return sne;
    }	
// end add by liandongzhou for td need the second the third number 20101221	
    public void setEmails(String[] emails) {
        this.emails = emails;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
        if(emails != null)
        {  
	      if (emails[0] != null)
		  {
		    if (emails[0].length() == 0)
     		this.emails = null;
		  }else{
		    this.emails = null;
    }
    }

    }
    public void setAnr(String anr) {
        this.anr = anr;
    }
// add by liandongzhou for td need the second the third number 20101221	
    public void setAnr2(String anr) {
        this.anr2 = anr;
    }
    public void setAnr3(String anr) {
        this.anr3 = anr;
    }
    public void setSne(String sne) {
        this.sne = sne;
    }	
// end add by liandongzhou for td need the second the third number 20101221		
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
    public String toString() {
        return "ADN Record '" + alphaTag + "' '" + number + " " + emails + " " + anr + "'";
    }

    public boolean isEmpty() {
        return alphaTag.equals("") && number.equals("") && emails == null;
    }

    public boolean hasExtendedRecord() {
        return extRecord != 0 && extRecord != 0xff;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    public int getExtNumber(){
	//Log.w("GSM","MY extRecord="+extRecord);
	return extRecord;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
    public boolean isEqual(AdnRecord adn) {
        return ( alphaTag.equals(adn.getAlphaTag()) &&
                number.equals(adn.getNumber()) &&
                Arrays.equals(emails, adn.getEmails()));
    }
//add by liandongzhou for only email is not a record. 20101229
    public boolean isGsmEqual(AdnRecord adn) { //gsm not need email.
        return ( alphaTag.equals(adn.getAlphaTag()) &&
                number.equals(adn.getNumber()));// &&
             //   Arrays.equals(emails, adn.getEmails()));
    }
//end add by liandongzhou for only email is not a record. 20101229	
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    public boolean isFDNEqual(AdnRecord adn){
        return ( alphaTag.equals(adn.getAlphaTag()) &&
                number.equals(adn.getNumber()) );
    }
             
    public boolean isUsimEqual(AdnRecord adn) {
       String email1 ;
	String email2;	
// add by liandongzhou for td need the second the third number 20101223
	String nowAnr2 = adn.getAnr2();
	String nowAnr3 = adn.getAnr3();
	String nowSne = adn.getSne();	

	if(nowAnr2 == null){
		nowAnr2 = "";
	}
	if(nowAnr3 == null){
		nowAnr3 = "";
	}
	if(nowSne == null){
		nowSne = "";
	}
//some cards has not anr2, anr3, sne.
	if(anr2 == null){
		anr2 = "";
	}
	if(anr3 == null){
		anr3 = "";
	}
	if(sne == null){
		sne = "";
	}
// end add by liandongzhou for td need the second the third number 20101223	
        if(emails == null){
		email1 = "";
        }else{
          if(emails[0] == null){
		     email1 = "";
		  }else{
		     if (emails[0].length() == 0){
                 email1 = "";
		     }else{		  
		         email1 = emails[0];
		     }
		  }
	    }
        if(adn.getEmails() == null){
		email2 = "";
        }else{
          if(adn.getEmails()[0] == null){
		     email2 = "";
		  }else{
		     if (adn.getEmails()[0].length() == 0){
                 email2 = "";
		     }else{		  
		         email2 = adn.getEmails()[0];
		     }
		  }
	    }

       return  ( alphaTag.equals(adn.getAlphaTag()) &&
                number.equals(adn.getNumber()) &&
                email1.equals(email2) &&                
                anr.equals(adn.getAnr())&&                
                anr2.equals(nowAnr2)&&                
                anr3.equals(nowAnr3)&&                
                sne.equals(nowSne));

    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
    //***** Parcelable Implementation

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(efid);
        dest.writeInt(recordNumber);
        dest.writeString(alphaTag);
        dest.writeString(number);
        dest.writeStringArray(emails);
	dest.writeString(anr);	
    }

    /**
     * Build adn hex byte array based on record size
     * The format of byte array is defined in 51.011 10.5.1
     *
     * @param recordSize is the size X of EF record
     * @return hex byte[recordSize] to be written to EF record
     *          return nulll for wrong format of dialing nubmer or tag
     */
    //public byte[] buildAdnString(int recordSize) {
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    public byte[] buildAdnString(int recordSize,int extRecId){
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
        byte[] bcdNumber;
        byte[] byteTag;
        byte[] adnString = null;
        int footerOffset = recordSize - FOOTER_SIZE_BYTES;
	  /*ZTE_CONTACTS_LIANDONGZHOU, start, 20101108*/
        Log.d(LOG_TAG, "MY alphaTag is :" + alphaTag + ", recordSize" + recordSize);
        /*ZTE_CONTACTS_LIANDONGZHOU, end, 20101108*/
     //   if (TextUtils.isEmpty(number)||TextUtils.isEmpty(alphaTag)) { //20110520 houjiong usim change 
					 if (TextUtils.isEmpty(number)&&TextUtils.isEmpty(alphaTag)) {
            Log.w(LOG_TAG, "[buildAdnString] Empty alpha tag or number");
            adnString = new byte[recordSize];
            for (int i = 0; i < recordSize; i++) {
                adnString[i] = (byte) 0xFF;
            }
        }else {
            adnString = new byte[recordSize];
            for (int i = 0; i < recordSize; i++) {
                adnString[i] = (byte) 0xFF;
            }

            bcdNumber = PhoneNumberUtils.numberToCalledPartyBCD(number);
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
			if(bcdNumber!=null){//20110520 houjiong usim change  
				 Log.w(LOG_TAG, "bcdNumber!=null");
				 
            if (bcdNumber.length <= MAX_NUMBER_SIZE_BYTES){
            System.arraycopy(bcdNumber, 0, adnString,
                    footerOffset + ADN_TON_AND_NPI, bcdNumber.length);

            adnString[footerOffset + ADN_BCD_NUMBER_LENGTH]
                    = (byte) (bcdNumber.length);
            adnString[footerOffset + ADN_CAPABILITY_ID]
                    = (byte) 0xFF; // Capacility Id
            adnString[footerOffset + ADN_EXTENSION_ID]
                    = (byte) 0xFF; // Extension Record Id
             Log.w("GSM", "MY number is 20"); 
	     }
            else{
	     System.arraycopy(bcdNumber, 0, adnString,
                    footerOffset + ADN_TON_AND_NPI, MAX_NUMBER_SIZE_BYTES);
	     adnString[footerOffset + ADN_BCD_NUMBER_LENGTH]
                    = (byte) (MAX_NUMBER_SIZE_BYTES);
            adnString[footerOffset + ADN_CAPABILITY_ID]
                    = (byte) 0xFF; // Capacility Id
            adnString[footerOffset + ADN_EXTENSION_ID]
                    = (byte) extRecId; // Extension Record Id
            extRecord = extRecId;
             Log.w("GSM", "MY number > 20 extRecId="+extRecId); 
	     }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
				}//20110520 houjiong usim change  

            byteTag = GsmAlphabet.stringToGsm8BitPacked(alphaTag);
            /*ZTE_CONTACTS_LIANDONGZHOU 20101108 add type begin*/
            int spaceCount =0;			
            for(int i =0 ; i<byteTag.length;i++) if(byteTag[i]==0x20) spaceCount ++;
            for(int i =0 ; i<alphaTag.length();i++) if(alphaTag.charAt(i)==0x20) spaceCount --;			
	        if(spaceCount !=0)
	        {//use utf-16 codec
                try 
		       {
                    byteTag = alphaTag.getBytes("utf-16be");
                } catch (java.io.UnsupportedEncodingException ex) {
                    Log.e("AdnRecord", "alphaTag convert byte exception"); 
                }	         
                adnString[0] = (byte)0x80;
                if(byteTag.length < footerOffset)
                {
                    System.arraycopy(byteTag, 0, adnString, 1, byteTag.length);
                }
                else
                {
                    System.arraycopy(byteTag, 0, adnString, 1, footerOffset - 1);
	            }	
	        }else
	        {// use gsm8bit
	         if(byteTag.length > footerOffset)
	         {
	             System.arraycopy(byteTag, 0, adnString, 0, footerOffset);
	         }
	         else
	         {
	             System.arraycopy(byteTag, 0, adnString, 0, byteTag.length);
	         }
	      	}
            /*ZTE_CONTACTS_LIANDONGZHOU 20101108 add type begin*/

        //    System.arraycopy(byteTag, 0, adnString, 0, byteTag.length);

        }

        return adnString;
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    public byte[]buildEmailString(int recordSize, int recordNumber, int pbrIndex, int sfi){
     Log.w(LOG_TAG, "buildEmailString");
        byte[] newEmail = null;
	byte[] bcdEmail = null;

	if(emails[0] == null ||emails[0].equals("")){
	newEmail = new byte[recordSize];
	for (int j = 0; j < recordSize; j++) {
            newEmail[j] = (byte) 0xFF;
	}	
	}else{
	newEmail = new byte[recordSize];
	for (int j = 0; j < recordSize; j++) {
            newEmail[j] = (byte) 0xFF;
	}
	
	bcdEmail = GsmAlphabet.stringToGsm8BitPacked(emails[0]);

	if (bcdEmail.length < recordSize-2)
	System.arraycopy(bcdEmail, 0, newEmail, 0, bcdEmail.length);
	else
	System.arraycopy(bcdEmail, 0, newEmail, 0, recordSize-2);
	newEmail[recordSize-2] = (byte)sfi;
	newEmail[recordSize-1] = (byte)recordNumber;

      }
	return newEmail;
}
// add by liandongzhou for td need the second the third number 20101223	
    public byte[]buildSneString(int recordSize){
       byte[] newSne = null;
	byte[] bcdSne = null;

	if(TextUtils.isEmpty(sne)){
	    newSne = new byte[recordSize];
	    for (int j = 0; j < recordSize; j++) {
               newSne[j] = (byte) 0xFF;
	   }	
	    return newSne;
	}

	newSne = new byte[recordSize];
	for (int j = 0; j < recordSize; j++) {
            newSne[j] = (byte) 0xFF;
	}
	bcdSne = GsmAlphabet.stringToGsm8BitPacked(sne);

       int spaceCount =0;			
       for(int i =0 ; i<bcdSne.length;i++) if(bcdSne[i]==0x20) spaceCount ++;
       for(int i =0 ; i<sne.length();i++) if(sne.charAt(i)==0x20) spaceCount --;			
	if(spaceCount !=0){//use utf-16 codec
           try 
	   {
               bcdSne = sne.getBytes("utf-16be");
          } catch (java.io.UnsupportedEncodingException ex) {
               Log.e("AdnRecord", "alphaTag convert byte exception"); 
          }	         
          newSne[0] = (byte)0x80;
          if(bcdSne.length < recordSize){
                    System.arraycopy(bcdSne, 0, newSne, 1, bcdSne.length);
          }else{
                    System.arraycopy(bcdSne, 0, newSne, 1, recordSize - 1);
	    }	
	 }else{// use gsm8bit
	      if(bcdSne.length > recordSize){
	             System.arraycopy(bcdSne, 0, newSne, 0, recordSize-1);
	      }else{
	             System.arraycopy(bcdSne, 0, newSne, 0, bcdSne.length);
	      }
	 }

	return newSne;
}
// end add by liandongzhou for td need the second the third number 20101223		
    public byte[]buildIapString(int recordNumber, int pbrIndex){
        byte[] Iap = null;

	if(iap == -1){
	Iap = new byte[1];
		    
        Iap[0] = (byte) 0xFF;
	}else{
	Iap = new byte[1];
		    
        Iap[0] = (byte) recordNumber;
	}
	return Iap;
}

    public String getEmail() {
        return emails[0];
    }

    public byte[]buildAnrString(int recordSize, int recordNumber, int pbrIndex, int sfi,int anrIndex){
        byte[] newAnr = null;
	byte[] bcdAnr = null;
// add by liandongzhou for td need the second the third number 20101222	
	String anr = "";
	if(anrIndex == 1){
		anr = this.anr2;
	}else if(anrIndex == 2){
		anr = this.anr3;
	}else {
		anr = this.anr;
	}
// add by liandongzhou for td need the second the third number 20101222	
	if(anr == null ||anr.equals("")){
	newAnr = new byte[recordSize];
		    
	for (int j = 0; j < recordSize; j++) {
            newAnr[j] = (byte) 0xFF;
	}
	}else{
	newAnr = new byte[recordSize];
		    
	for (int j = 0; j < recordSize; j++) {
            newAnr[j] = (byte) 0xFF;
	}

	bcdAnr = PhoneNumberUtils.numberToCalledPartyBCD(anr);

       //if (bcdAnr.length < MAX_NUMBER_SIZE_BYTES){
       if (bcdAnr.length <= MAX_NUMBER_SIZE_BYTES){
        System.arraycopy(bcdAnr, 0, newAnr, 2, bcdAnr.length);
           newAnr[0] = (byte) 0x00;
           newAnr[1] = (byte) (bcdAnr.length);
	}else{
	    //System.arraycopy(bcdAnr, 0, newAnr, 2, MAX_NUMBER_SIZE_BYTES-1);
		System.arraycopy(bcdAnr, 0, newAnr, 2, MAX_NUMBER_SIZE_BYTES);
           newAnr[0] = (byte) 0x00;
           newAnr[1] = (byte) (MAX_NUMBER_SIZE_BYTES);
	}

           newAnr[ADN_EXTENSION_ID+1]
                    = (byte) 0xFF; // Extension Record Id
              
           if (recordSize > 15){
           newAnr[ADN_EXTENSION_ID+2] 
                    = (byte) sfi;
           newAnr[ADN_EXTENSION_ID+3] 
                    = (byte) recordNumber;
            }

           //newAnr[1] = (byte) (bcdAnr.length);
	}
	return newAnr;
    }

    public byte[]buildEXT1String(int recordSize){
        byte[] ext1BcdNumber;
        byte[] ext1AdnString = null;
	 int bcdLen = 0;
	 String EXT1Number;
	 if (number == null || number.equals("") ){
            ext1AdnString = new byte[recordSize];
            for (int i = 0; i < recordSize; i++) {
                ext1AdnString[i] = (byte) 0xFF;
            }
	 }else{
		
            ext1AdnString = new byte[recordSize];
            for (int i = 0; i < recordSize; i++) {
                ext1AdnString[i] = (byte) 0xFF;
            }
        EXT1Number = number.substring(20,number.length());
	Log.w("GSM", "MY ext1BcdNumber EXTNumber="+EXT1Number); 
            ext1BcdNumber = PhoneNumberUtils.numberToCalledPartyBCD(EXT1Number);
		
	     for (int i=0; i< ext1BcdNumber.length;i++)
	     Log.w("GSM", "MY ext1BcdNumber["+i+"]"+"="+ext1BcdNumber[i]); 
	     System.arraycopy(ext1BcdNumber, 1, ext1AdnString,2, ext1BcdNumber.length-1);
	     ext1AdnString[ ADN_BCD_NUMBER_LENGTH]
                    = (byte) 0x02;
	     ext1AdnString[1]
                    = (byte) (ext1BcdNumber.length-1);
            ext1AdnString[12]
                    = (byte) 0xFF; 
	 }
	  return ext1AdnString;
}
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/

    /**
     * See TS 51.011 10.5.10
     */
    public void
    appendExtRecord (byte[] extRecord) {
        try {
            if (extRecord.length != EXT_RECORD_LENGTH_BYTES) {
                return;
            }

            if ((extRecord[0] & EXT_RECORD_TYPE_MASK)
                    != EXT_RECORD_TYPE_ADDITIONAL_DATA) {
                return;
            }

            if ((0xff & extRecord[1]) > MAX_EXT_CALLED_PARTY_LENGTH) {
                // invalid or empty record
                return;
            }

            number += PhoneNumberUtils.calledPartyBCDFragmentToString(
                                        extRecord, 2, 0xff & extRecord[1]);

            // We don't support ext record chaining.

        } catch (RuntimeException ex) {
            Log.w(LOG_TAG, "Error parsing AdnRecord ext record", ex);
        }
    }

    //***** Private Methods

    /**
     * alphaTag and number are set to null on invalid format
     */
    private void
    parseRecord(byte[] record) {
        try {
            alphaTag = IccUtils.adnStringFieldToString(
                            record, 0, record.length - FOOTER_SIZE_BYTES);

            int footerOffset = record.length - FOOTER_SIZE_BYTES;

            int numberLength = 0xff & record[footerOffset];

            if (numberLength > MAX_NUMBER_SIZE_BYTES) {
                // Invalid number length
                number = "";
                return;
            }

            // Please note 51.011 10.5.1:
            //
            // "If the Dialling Number/SSC String does not contain
            // a dialling number, e.g. a control string deactivating
            // a service, the TON/NPI byte shall be set to 'FF' by
            // the ME (see note 2)."

            number = PhoneNumberUtils.calledPartyBCDToString(
                            record, footerOffset + 1, numberLength);

            Log.w("ZLian", "parseRecord: new adn alphaTag = " + alphaTag+ " number = "+ number);
            extRecord = 0xff & record[record.length - 1];

            emails = null;

            anr = "";
// add by liandongzhou for td need the second the third number 20101221	
            anr2 = "";
            anr3 = "";
	     sne = "";
// end add by liandongzhou for td need the second the third number 20101221	
        } catch (RuntimeException ex) {
            Log.w(LOG_TAG, "Error parsing AdnRecord", ex);
            number = "";
            alphaTag = "";
            emails = null;
	     anr = "";
// add by liandongzhou for td need the second the third number 20101221	
            anr2 = "";
            anr3 = "";
            sne = "";			
// end add by liandongzhou for td need the second the third number 20101221			
        }
    }
}
