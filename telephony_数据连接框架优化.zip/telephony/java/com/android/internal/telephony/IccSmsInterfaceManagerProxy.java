/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony;

import android.app.PendingIntent;
import android.os.ServiceManager;
import com.android.internal.telephony.gsm.SmsBroadcastConfigInfo;
import java.util.List;

public class IccSmsInterfaceManagerProxy extends ISms.Stub {
    private IccSmsInterfaceManager mIccSmsInterfaceManager;

    public IccSmsInterfaceManagerProxy(IccSmsInterfaceManager
            iccSmsInterfaceManager) {
        this.mIccSmsInterfaceManager = iccSmsInterfaceManager;
        if(ServiceManager.getService("isms") == null) {
            ServiceManager.addService("isms", this);
        }
    }

    public void setmIccSmsInterfaceManager(IccSmsInterfaceManager iccSmsInterfaceManager) {
        this.mIccSmsInterfaceManager = iccSmsInterfaceManager;
    }

    public boolean
    updateMessageOnIccEf(int index, int status, byte[] pdu) throws android.os.RemoteException {
         return mIccSmsInterfaceManager.updateMessageOnIccEf(index, status, pdu);
    }

    public boolean copyMessageToIccEf(int status, byte[] pdu,
            byte[] smsc) throws android.os.RemoteException {
        return mIccSmsInterfaceManager.copyMessageToIccEf(status, pdu, smsc);
    }

    //add by zzq
    public int copyMessageToIccSimEf(int status, byte[] pdu,
            byte[] smsc) throws android.os.RemoteException {
        return mIccSmsInterfaceManager.copyMessageToIccSimEf(status, pdu, smsc);
    }
    //add by zzq
    public List<SmsRawData> getAllMessagesFromIccEf() throws android.os.RemoteException {
        return mIccSmsInterfaceManager.getAllMessagesFromIccEf();
    }
    
    public List<SmsBroadcastConfigInfo> getCellBroadcastConfig() throws android.os.RemoteException {
        return mIccSmsInterfaceManager.getCellBroadcastConfig();
    }

    public void sendData(String destAddr, String scAddr, int destPort,
            byte[] data, PendingIntent sentIntent, PendingIntent deliveryIntent) {
        mIccSmsInterfaceManager.sendData(destAddr, scAddr, destPort, data,
                sentIntent, deliveryIntent);
    }

    public void sendText(String destAddr, String scAddr,
            String text, PendingIntent sentIntent, PendingIntent deliveryIntent) {
        mIccSmsInterfaceManager.sendText(destAddr, scAddr, text, sentIntent, deliveryIntent);
    }

    /*luowenping added: extended param*/
    public void sendTextExtra(String destAddr, String scAddr,
            String text, PendingIntent sentIntent, PendingIntent deliveryIntent, int vp) {
        mIccSmsInterfaceManager.sendTextExtra(destAddr, scAddr, text, sentIntent, deliveryIntent, vp);
    }


    /* huangqinbo realize sim sms storage 20101207 begin*/
	public void setNewSmsIndication(int storarge) {
        //log("huangqinbo setNewSmsIndication: storarge=" + storarge );

        mIccSmsInterfaceManager.setNewSmsIndication(storarge);

	}
	/* huangqinbo realize sim sms storage 20101207 end */
	

    public void sendMultipartText(String destAddr, String scAddr,
            List<String> parts, List<PendingIntent> sentIntents,
            List<PendingIntent> deliveryIntents) throws android.os.RemoteException {
        mIccSmsInterfaceManager.sendMultipartText(destAddr, scAddr,
                parts, sentIntents, deliveryIntents);
    }

    /*luowenping added: extended param*/
    public void sendMultipartTextExtra(String destAddr, String scAddr,
            List<String> parts, List<PendingIntent> sentIntents,
            List<PendingIntent> deliveryIntents, int vp) throws android.os.RemoteException {
        mIccSmsInterfaceManager.sendMultipartTextExtra(destAddr, scAddr,
                parts, sentIntents, deliveryIntents, vp);
    }
	    /*huangwei added: extended param  for U8xx  EC 614001012414   2011-09-14*/
    public void sendMultipartTextAndMultiSmsExtra(String destAddr, String scAddr,
            List<String> parts, List<PendingIntent> sentIntents,
            List<PendingIntent> deliveryIntents, int vp,boolean isSendMultiSms) throws android.os.RemoteException {
        mIccSmsInterfaceManager.sendMultipartTextAndMultiSmsExtra(destAddr, scAddr,
                parts, sentIntents, deliveryIntents, vp,isSendMultiSms);
    }
     /*huangwei added: extended param  for U8xx  EC 614001012414   2011-09-14*/
    public boolean enableCellBroadcast(int messageIdentifier) throws android.os.RemoteException {
        return mIccSmsInterfaceManager.enableCellBroadcast(messageIdentifier);
    }

    public boolean disableCellBroadcast(int messageIdentifier) throws android.os.RemoteException {
        return mIccSmsInterfaceManager.disableCellBroadcast(messageIdentifier);
    }

    public boolean enableCellBroadcastRange(int startMessageId, int endMessageId)
            throws android.os.RemoteException {
        return mIccSmsInterfaceManager.enableCellBroadcastRange(startMessageId, endMessageId);
    }
    
    public boolean disableCellBroadcastRangeParameter(int startMessageId, int endMessageId, int startDcsId,
            int endDcsId)throws android.os.RemoteException{
        return mIccSmsInterfaceManager.disableCellBroadcastRangeParameter(startMessageId, endMessageId, startDcsId,
                endDcsId);
    }
    
    public boolean enableCellBroadcastRangeParameter(int startMessageId, int endMessageId, int startDcsId,
            int endDcsId)throws android.os.RemoteException{
        return mIccSmsInterfaceManager.enableCellBroadcastRangeParameter(startMessageId, endMessageId, startDcsId,
                endDcsId);
    }

    public boolean disableCellBroadcastRange(int startMessageId, int endMessageId)
            throws android.os.RemoteException {
        return mIccSmsInterfaceManager.disableCellBroadcastRange(startMessageId, endMessageId);
    }
    
    
    public boolean setCellBroadcastActivation  (boolean activate) throws android.os.RemoteException{
        return mIccSmsInterfaceManager.setCellBroadcastActivation(activate);
    }
}
