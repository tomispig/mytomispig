/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony;

import java.util.ArrayList;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.android.internal.telephony.GsmAlphabet;

public class AdnRecordLoader extends Handler {
    static String LOG_TAG;

    //***** Instance Variables

    PhoneBase phone;
    int ef;
    int extensionEF;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    int pbrIndex = 0;
    int extInx = 0;
    int[] adnEfid = null;
    int[] emailEfid = null;
    int[] iapEfid = null;
    int[] sfi = null;
    int[] anrEfid = null;
// add by liandongzhou for td need the second the third number 20101223
    int[] snelEfid = null;	
// end add by liandongzhou for td need the second the third number 20101223	
    int extRecId;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
    int pendingExtLoads;
    Message userResponse;
    String pin2;

//add by liandongzhou for td need the second the third number 20101222
    int anrIndex;
//end add by liandongzhou for td need the second the third number 20101222	
    // For "load one"
    int recordNumber;

    // for "load all"
    ArrayList<AdnRecord> adns; // only valid after EVENT_ADN_LOAD_ALL_DONE

    // Either an AdnRecord or a reference to adns depending
    // if this is a load one or load all operation
    Object result;

    //***** Event Constants

    static final int EVENT_ADN_LOAD_DONE = 1;
    static final int EVENT_EXT_RECORD_LOAD_DONE = 2;
    static final int EVENT_ADN_LOAD_ALL_DONE = 3;
    static final int EVENT_EF_LINEAR_RECORD_SIZE_DONE = 4;
    static final int EVENT_UPDATE_RECORD_DONE = 5;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    static final int EVENT_EF_LINEAR_EMAIL_RECORD_SIZE_DONE= 6;
    static final int EVENT_UPDATE_EMAIL_RECORD_DONE = 7;
    static final int EVENT_EF_LINEAR_ANR_RECORD_SIZE_DONE = 8;
    static final int EVENT_UPDATE_ANR_RECORD_DONE = 9;
    static final int EVENT_EF_LINEAR_IAP_RECORD_SIZE_DONE= 10;
    static final int EVENT_UPDATE_IAP_RECORD_DONE = 11;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/

//add by liandongzhou for td need the second the third number 20101223
    static final int EVENT_EF_LINEAR_SNE_RECORD_SIZE_DONE = 12;
    static final int EVENT_UPDATE_SNE_RECORD_DONE = 13;
//end add by liandongzhou for td need the second the third number 20101223	

    //***** Constructor

    public AdnRecordLoader(PhoneBase phone) {
        // The telephony unit-test cases may create AdnRecords
        // in secondary threads
        super(phone.getHandler().getLooper());

        this.phone = phone;
        LOG_TAG = phone.getPhoneName();
    }

    /**
     * Resulting AdnRecord is placed in response.obj.result
     * or response.obj.exception is set
     */
    public void
    loadFromEF(int ef, int extensionEF, int recordNumber,
                Message response) {
        this.ef = ef;
        this.extensionEF = extensionEF;
        this.recordNumber = recordNumber;
        this.userResponse = response;

        phone.mIccFileHandler.loadEFLinearFixed(
                    ef, recordNumber,
                    obtainMessage(EVENT_ADN_LOAD_DONE));

    }


    /**
     * Resulting ArrayList&lt;adnRecord> is placed in response.obj.result
     * or response.obj.exception is set
     */
    public void
    loadAllFromEF(int ef, int extensionEF,
                Message response) {
        this.ef = ef;
        this.extensionEF = extensionEF;
        this.userResponse = response;

        phone.mIccFileHandler.loadEFLinearFixedAll(
                    ef,
                    obtainMessage(EVENT_ADN_LOAD_ALL_DONE));

    }

    /**
     * Write adn to a EF SIM record
     * It will get the record size of EF record and compose hex adn array
     * then write the hex array to EF record
     *
     * @param adn is set with alphaTag and phoneNubmer
     * @param ef EF fileid
     * @param extensionEF extension EF fileid
     * @param recordNumber 1-based record index
     * @param pin2 for CHV2 operations, must be null if pin2 is not needed
     * @param response will be sent to its handler when completed
     */
    public void
    updateEF(AdnRecord adn, int ef, int extensionEF, int recordNumber,
            String pin2, Message response) {
        this.ef = ef;
        this.extensionEF = extensionEF;
        this.recordNumber = recordNumber;
        this.userResponse = response;
        this.pin2 = pin2;

        phone.mIccFileHandler.getEFLinearRecordSize( ef,
            obtainMessage(EVENT_EF_LINEAR_RECORD_SIZE_DONE, adn));
    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
    public void
    updateAdnEF(AdnRecord adn, int ef, int extensionEF, int recordNumber, int pbrIndex, 
            int[] adnEfid,  String pin2, int extRecId, Message response) {
        this.ef = ef;
        this.extensionEF = extensionEF;
        this.recordNumber = recordNumber;
	this.pbrIndex = pbrIndex;
	this.adnEfid = adnEfid;
        this.userResponse = response;
        this.pin2 = pin2;
	  this.extRecId = extRecId;

        phone.mIccFileHandler.getEFLinearRecordSize( ef,
            obtainMessage(EVENT_EF_LINEAR_RECORD_SIZE_DONE, adn));
    }

    public void
    updateEmailEF(AdnRecord adn, int ef, int extensionEF, int recordNumber, int pbrIndex,
            int[] emailEfid, int[] sfi, String pin2, Message response) {
        this.ef = ef;
        this.extensionEF = extensionEF;
        this.recordNumber = recordNumber;
	this.pbrIndex = pbrIndex;
	this.emailEfid = emailEfid;
	this.sfi = sfi;
        this.userResponse = response;
        this.pin2 = pin2;

        phone.mIccFileHandler.getEFLinearRecordSize( ef,
            obtainMessage(EVENT_EF_LINEAR_EMAIL_RECORD_SIZE_DONE, adn));
		
    }

    public void
    updateIapEF(AdnRecord adn, int ef, int extensionEF, int recordNumber, int pbrIndex,
            int[] iapEfid, String pin2, Message response) {
        this.ef = ef;
        this.recordNumber = recordNumber;
	this.pbrIndex = pbrIndex;
	this.iapEfid = iapEfid;
        this.userResponse = response;

        phone.mIccFileHandler.getEFLinearRecordSize( ef,
            obtainMessage(EVENT_EF_LINEAR_IAP_RECORD_SIZE_DONE, adn));
		
    }

    public void
    updateAnrEF(AdnRecord adn, int ef, int extensionEF, int recordNumber, int pbrIndex,
            int[] anrEfid, int[] sfi, String pin2, Message response, int anrIndex) {
        this.ef = ef;
        this.extensionEF = extensionEF;
        this.recordNumber = recordNumber;
	 this.pbrIndex = pbrIndex;
	 this.anrEfid = anrEfid;
	 this.sfi = sfi;
        this.userResponse = response;
        this.pin2 = pin2;
//add by liandongzhou for td need the second the third number 20101222			
        this.anrIndex = anrIndex;
//end add by liandongzhou for td need the second the third number 20101222	
        phone.mIccFileHandler.getEFLinearRecordSize( ef,
            obtainMessage(EVENT_EF_LINEAR_ANR_RECORD_SIZE_DONE, adn));

    }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
//add by liandongzhou for td need the second the third number 20101222	
    public void
    updateSneEF(AdnRecord adn, int ef, int extensionEF, int recordNumber, int pbrIndex,
            int[] snelEfid, int[] sfi, String pin2, Message response) {
        this.ef = ef;
        this.extensionEF = extensionEF;
        this.recordNumber = recordNumber;
	this.pbrIndex = pbrIndex;
	this.snelEfid = snelEfid;
	this.sfi = sfi;
        this.userResponse = response;
        this.pin2 = pin2;

        phone.mIccFileHandler.getEFLinearRecordSize( ef,
            obtainMessage(EVENT_EF_LINEAR_SNE_RECORD_SIZE_DONE, adn));
		
    }
//end add by liandongzhou for td need the second the third number 20101222	
    public void
    handleMessage(Message msg) {
        AsyncResult ar;
        byte data[];
        AdnRecord adn;

        try {
            switch (msg.what) {
                case EVENT_EF_LINEAR_RECORD_SIZE_DONE:
                    ar = (AsyncResult)(msg.obj);
                    adn = (AdnRecord)(ar.userObj);

                    if (ar.exception != null) {
                        throw new RuntimeException("get EF record size failed",
                                ar.exception);
                    }

                    int[] recordSize = (int[])ar.result;
                    // recordSize is int[3] array
                    // int[0]  is the record length
                    // int[1]  is the total length of the EF file
                    // int[2]  is the number of records in the EF file
                    // So int[0] * int[2] = int[1]
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/

                   /*if (recordSize.length != 3 || recordNumber > recordSize[2]) {
                        throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                    }*/
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/

/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
                   if((ef == 0x6F3A) && (pbrIndex ==0)&& (recordSize.length != 3 || recordNumber > recordSize[2])) {
                       Log.w("GSM","MY  ++++++++++error  1"+"recordSize.length="+recordSize.length+"recordNumber="+recordNumber+"recordSize[2]"+recordSize[2]);
                             throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                   }else if((ef == 0x6F3A) && (extInx >0) && (recordSize.length != 3 || extRecId > recordSize[2])) {
                       Log.w("GSM","MY  ++++++++++error  2"+"recordSize.length="+recordSize.length+"extRecId="+extRecId+"recordSize[2]"+recordSize[2]);
                             throw new RuntimeException("get wrong EF record size format",
                                 ar.exception);
                  }      

                  else if((ef != 0x6F3A) && ((pbrIndex >0) && (extInx >0)) && (recordSize.length != 3 || extRecId > recordSize[2])) {

                       Log.w("GSM","MY  ++++++++++error  3"+"recordSize.length="+recordSize.length+"recordNumber="+recordNumber+"recordSize[2]"+recordSize[2]);
                             throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                  }  

                  else if((ef != 0x6F3A) && ((pbrIndex >0) && (extInx == 0)) && (recordSize.length != 3 || recordNumber > recordSize[2])) {
                       Log.w("GSM","MY  ++++++++++error  4"+"recordSize.length="+recordSize.length+"recordNumber="+recordNumber+"recordSize[2]"+recordSize[2]);
                             throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                  }  
                  else if((ef != 0x6F3A) && ((pbrIndex >0) && (extInx > 0)) && (recordSize.length != 3 || recordNumber > 500)) {
                       Log.w("GSM","MY  ++++++++++error  5"+"recordSize.length="+recordSize.length+"recordNumber="+recordNumber);
                        throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                    }

                 if((ef != 0x6F3A) && (pbrIndex ==0) && (recordNumber > recordSize[2])){
                     recordNumber = recordNumber - recordSize[2];
                     ef = adnEfid[1];//get second record's efid
                     Log.w("GSM","MY  >250 getEFLinearRecordSize [ef]="+ef+" recordNumber="+recordNumber);
                     phone.mIccFileHandler.getEFLinearRecordSize( ef,
                            obtainMessage(EVENT_EF_LINEAR_RECORD_SIZE_DONE, adn));
                     pbrIndex++;
                     break;	
                  }

 /*                   data = adn.buildAdnString(recordSize[0]);
                    if(data == null) {
                        throw new RuntimeException("worong ADN format",
                                ar.exception);
                    }
                    phone.mIccFileHandler.updateEFLinearFixed(ef, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_RECORD_DONE));
                    pendingExtLoads = 1;
*/

		    if((extInx ==0)){
			Log.w("GSM","MY  buildAdnString [ef]="+ef);
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
                      data = adn.buildAdnString(recordSize[0],extRecId);

                    if(data == null) {
                        throw new RuntimeException("worong ADN format",
                                ar.exception);
                    }

                    phone.mIccFileHandler.updateEFLinearFixed(ef, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_RECORD_DONE));

                    pendingExtLoads = 1;
		     }
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
		    if((extInx ==0) && (adn.getNumber().length() >20)){
                       Log.w("GSM","MY  getEFLinearRecordSize [extensionEF]="+extensionEF);
                       phone.mIccFileHandler.getEFLinearRecordSize(extensionEF,
                            obtainMessage(EVENT_EF_LINEAR_RECORD_SIZE_DONE, adn));
                       extInx++;
                       break;
                   }
                   if (((extensionEF == 0x6F4A) ||(extensionEF == 0x4F4A)) && (extInx !=0)){
                       Log.w("GSM","MY  buildEXT1String [ef]="+ef+"recordSize[0]"+recordSize[0]);
                       data = adn.buildEXT1String(recordSize[0]);
			
                       if(data == null) {
                          throw new RuntimeException("worong ADN format",
                                ar.exception);
                       }

                       phone.mIccFileHandler.updateEFLinearFixed(extensionEF, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_RECORD_DONE));

                       pendingExtLoads = 1;
                    }
                    if ((extensionEF == 0x6F4B) && (extInx !=0)){

                        Log.w("GSM","MY  buildEXT2String [ef]="+ef+"recordSize[0]"+recordSize[0]);
                        data = adn.buildEXT1String(recordSize[0]);
			
                        if(data == null) {
                           throw new RuntimeException("worong ADN format",
                                ar.exception);
                        }

                        phone.mIccFileHandler.updateEFLinearFixed(extensionEF, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_RECORD_DONE));

                        pendingExtLoads = 1;
		     }

                    break;

		/*write email by xuyang*/
		case EVENT_EF_LINEAR_EMAIL_RECORD_SIZE_DONE:
		    ar = (AsyncResult)(msg.obj);
                    adn = (AdnRecord)(ar.userObj);

                    if (ar.exception != null) {
                        throw new RuntimeException("get email EF record size failed",
                                ar.exception);
                    }
                    int[] recordSizeEmail = (int[])ar.result;
		    
		    if((pbrIndex >0) && (recordSizeEmail.length != 3 || recordNumber > recordSizeEmail[2])) {
                        throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                    }

		    if((pbrIndex ==0) && (recordNumber > recordSizeEmail[2])){
                        recordNumber = recordNumber - recordSizeEmail[2];
			ef = emailEfid[1];//get second record's efid
			
                        phone.mIccFileHandler.getEFLinearRecordSize( ef,
                            obtainMessage(EVENT_EF_LINEAR_EMAIL_RECORD_SIZE_DONE, adn));
                        pbrIndex++;
			break;
		    }
			
		    data = adn.buildEmailString(recordSizeEmail[0], recordNumber, pbrIndex, sfi[pbrIndex]);
		    if(data == null) {
                        throw new RuntimeException("worong ADN format",
                                ar.exception);
				}
		    phone.mIccFileHandler.updateEFLinearFixed(ef, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_EMAIL_RECORD_DONE));
		    

                    pendingExtLoads = 1;

                    break;
//add by liandongzhou for td need the second the third number 20101223	
		case EVENT_EF_LINEAR_SNE_RECORD_SIZE_DONE:
		    ar = (AsyncResult)(msg.obj);
                    adn = (AdnRecord)(ar.userObj);

                    if (ar.exception != null) {
                        throw new RuntimeException("get email EF record size failed",
                                ar.exception);
                    }
                    int[] recordSizeSne = (int[])ar.result;
		    
		    if((pbrIndex >0) && (recordSizeSne.length != 3 || recordNumber > recordSizeSne[2])) {
                        throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                    }

		    if((pbrIndex ==0) && (recordNumber > recordSizeSne[2])){
                        recordNumber = recordNumber - recordSizeSne[2];
			ef = snelEfid[1];//get second record's efid
			
                        phone.mIccFileHandler.getEFLinearRecordSize( ef,
                            obtainMessage(EVENT_EF_LINEAR_SNE_RECORD_SIZE_DONE, adn));
                        pbrIndex++;
			break;
		    }
			
		    data = adn.buildSneString(recordSizeSne[0]);
		    Log.e("ZLian","AdnRecordLoader: EVENT_EF_LINEAR_SNE_RECORD_SIZE_DONE: data = "+IccUtils.bytesToHexString(data));
		    if(data == null) {
                        throw new RuntimeException("worong ADN format",
                                ar.exception);
				}
		    phone.mIccFileHandler.updateEFLinearFixed(ef, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_SNE_RECORD_DONE));
		    

                  pendingExtLoads = 1;

                 break;
//end add by liandongzhou for td need the second the third number 20101223

		case EVENT_EF_LINEAR_IAP_RECORD_SIZE_DONE:
		    ar = (AsyncResult)(msg.obj);
                    adn = (AdnRecord)(ar.userObj);

                    if (ar.exception != null) {
                        throw new RuntimeException("get email EF record size failed",
                                ar.exception);
                    }
                    int[] recordSizeIap = (int[])ar.result;
		    
		    if((pbrIndex >0) && (recordSizeIap.length != 3 || recordNumber > recordSizeIap[2])) {
                        throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                    }

		    if((pbrIndex ==0) && (recordNumber > recordSizeIap[2])){
                        recordNumber = recordNumber - recordSizeIap[2];
			ef = iapEfid[1];//get second record's efid
			
                        phone.mIccFileHandler.getEFLinearRecordSize( ef,
                            obtainMessage(EVENT_EF_LINEAR_IAP_RECORD_SIZE_DONE, adn));
                        pbrIndex++;
			break;
		    }
			
		    data = adn.buildIapString(recordNumber, pbrIndex);
		    if(data == null) {
                        throw new RuntimeException("worong ADN format",
                                ar.exception);
				}
		    phone.mIccFileHandler.updateEFLinearFixed(ef, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_IAP_RECORD_DONE));
		    

                    pendingExtLoads = 1;

                    break;
		case EVENT_EF_LINEAR_ANR_RECORD_SIZE_DONE:
		    ar = (AsyncResult)(msg.obj);
                    adn = (AdnRecord)(ar.userObj);

                    if (ar.exception != null) {
                        throw new RuntimeException("get email EF record size failed",
                                ar.exception);
                    }
                    int[] recordSizeAnr = (int[])ar.result;
		    
		    if((pbrIndex >0) && (recordSizeAnr.length != 3 || recordNumber > recordSizeAnr[2])) {
                        throw new RuntimeException("get wrong EF record size format",
                                ar.exception);
                    }

		    if((pbrIndex ==0) && (recordNumber > recordSizeAnr[2])){
                        recordNumber = recordNumber - recordSizeAnr[2];
			ef = anrEfid[1];//get second record's efid
			
                        phone.mIccFileHandler.getEFLinearRecordSize( ef,
                            obtainMessage(EVENT_EF_LINEAR_ANR_RECORD_SIZE_DONE, adn));
                        pbrIndex++;
			break;
		    }
			
		    data = adn.buildAnrString(recordSizeAnr[0], recordNumber, pbrIndex, sfi[pbrIndex], anrIndex);		
		    if(data == null) {
			
                        throw new RuntimeException("worong ADN format",
                                ar.exception);
				}
		    
		    phone.mIccFileHandler.updateEFLinearFixed(ef, recordNumber,
                            data, pin2, obtainMessage(EVENT_UPDATE_ANR_RECORD_DONE));

                    pendingExtLoads = 1;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
                    break;
                case EVENT_UPDATE_RECORD_DONE:
                    ar = (AsyncResult)(msg.obj);
                    if (ar.exception != null) {
                        throw new RuntimeException("update EF adn record failed",
                                ar.exception);
                    }
                    pendingExtLoads = 0;
                    result = null;
                    break;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 begin*/
		case EVENT_UPDATE_EMAIL_RECORD_DONE:
	            ar = (AsyncResult)(msg.obj);
                    if (ar.exception != null) {
                        throw new RuntimeException("update EF adn email record failed",
                                ar.exception);
                    }
                    pendingExtLoads = 0;
                    result = null;
                    break;
//add by liandongzhou for td need the second the third number 20101223
		case EVENT_UPDATE_SNE_RECORD_DONE:
	            ar = (AsyncResult)(msg.obj);
                    if (ar.exception != null) {
                        throw new RuntimeException("update EF adn sne record failed",
                                ar.exception);
                    }
                    pendingExtLoads = 0;
                    result = null;
                    break;
//end add by liandongzhou for td need the second the third number 20101223
					
		case EVENT_UPDATE_ANR_RECORD_DONE:
	            ar = (AsyncResult)(msg.obj);
                    if (ar.exception != null) {
                        throw new RuntimeException("update EF adn anr record failed",
                                ar.exception);
                    }
                    pendingExtLoads = 0;
                    result = null;
                    break;
		case EVENT_UPDATE_IAP_RECORD_DONE:
	            ar = (AsyncResult)(msg.obj);
                    if (ar.exception != null) {
                        throw new RuntimeException("update EF adn anr record failed",
                                ar.exception);
                    }
                    pendingExtLoads = 0;
                    result = null;
                    break;
/*ZTE_CONTACTS_LIANDONGZHOU_3G 20101207 end*/
                case EVENT_ADN_LOAD_DONE:
                    ar = (AsyncResult)(msg.obj);
                    data = (byte[])(ar.result);

                    if (ar.exception != null) {
                        throw new RuntimeException("load failed", ar.exception);
                    }

                    if (false) {
                        Log.d(LOG_TAG,"ADN EF: 0x"
                            + Integer.toHexString(ef)
                            + ":" + recordNumber
                            + "\n" + IccUtils.bytesToHexString(data));
                    }

                    adn = new AdnRecord(ef, recordNumber, data);
                    result = adn;

                    if (adn.hasExtendedRecord()) {
                        // If we have a valid value in the ext record field,
                        // we're not done yet: we need to read the corresponding
                        // ext record and append it

                        pendingExtLoads = 1;

                        phone.mIccFileHandler.loadEFLinearFixed(
                            extensionEF, adn.extRecord,
                            obtainMessage(EVENT_EXT_RECORD_LOAD_DONE, adn));
                    }
                break;

                case EVENT_EXT_RECORD_LOAD_DONE:
                    ar = (AsyncResult)(msg.obj);
                    data = (byte[])(ar.result);
                    adn = (AdnRecord)(ar.userObj);

                    if (ar.exception != null) {
                        throw new RuntimeException("load failed", ar.exception);
                    }

                    Log.d(LOG_TAG,"ADN extention EF: 0x"
                        + Integer.toHexString(extensionEF)
                        + ":" + adn.extRecord
                        + "\n" + IccUtils.bytesToHexString(data));

                    adn.appendExtRecord(data);

                    pendingExtLoads--;
                    // result should have been set in
                    // EVENT_ADN_LOAD_DONE or EVENT_ADN_LOAD_ALL_DONE
                break;

                case EVENT_ADN_LOAD_ALL_DONE:
                    ar = (AsyncResult)(msg.obj);
                    ArrayList<byte[]> datas = (ArrayList<byte[]>)(ar.result);

                    if (ar.exception != null) {
                        throw new RuntimeException("load failed", ar.exception);
                    }

                    adns = new ArrayList<AdnRecord>(datas.size());
                    result = adns;
                    pendingExtLoads = 0;

                    for(int i = 0, s = datas.size() ; i < s ; i++) {
                        adn = new AdnRecord(ef, 1 + i, datas.get(i));
                        adns.add(adn);

                        if (adn.hasExtendedRecord()) {
                            // If we have a valid value in the ext record field,
                            // we're not done yet: we need to read the corresponding
                            // ext record and append it

                            pendingExtLoads++;

                            phone.mIccFileHandler.loadEFLinearFixed(
                                extensionEF, adn.extRecord,
                                obtainMessage(EVENT_EXT_RECORD_LOAD_DONE, adn));
                        }
                    }
                break;
            }
        } catch (RuntimeException exc) {
            if (userResponse != null) {
                AsyncResult.forMessage(userResponse)
                                .exception = exc;
                userResponse.sendToTarget();
                // Loading is all or nothing--either every load succeeds
                // or we fail the whole thing.
                userResponse = null;
            }
            return;
        }

        if (userResponse != null && pendingExtLoads == 0) {
            AsyncResult.forMessage(userResponse).result
                = result;

            userResponse.sendToTarget();
            userResponse = null;
        }
    }


}
