/*
===============================================================================================================
when          who            what, where, why                                          comment tag
--------      ----           -------------------------------------       ----------------------------------
2011-06-23    sunyanjun      Upgrade to Gingerbread                 ZTE_SYJ_20110623
===============================================================================================================
*/
/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.internal.telephony;
import android.util.Log;

/**
 * {@hide}
 */
public abstract class Connection {

    // Number presentation type for caller id display
    public static int PRESENTATION_ALLOWED = 1;    // normal
    public static int PRESENTATION_RESTRICTED = 2; // block by user
    public static int PRESENTATION_UNKNOWN = 3;    // no specified or unknown by network
    public static int PRESENTATION_PAYPHONE = 4;   // show pay phone info


    private static String LOG_TAG = "TelephonyConnection";

    public enum DisconnectCause {
        NOT_DISCONNECTED,               /* has not yet disconnected */
        INCOMING_MISSED,                /* an incoming call that was missed and never answered */
        NORMAL,                         /* normal; remote */
        LOCAL,                          /* normal; local hangup */
        BUSY,                           /* outgoing call to busy line */
        CONGESTION,                     /* outgoing call to congested network */
        MMI,                            /* not presently used; dial() returns null */
        INVALID_NUMBER,                 /* invalid dial string */
        NUMBER_UNREACHABLE,             /* cannot reach the peer */
        SERVER_UNREACHABLE,             /* cannot reach the server */
        INVALID_CREDENTIALS,            /* invalid credentials */
        OUT_OF_NETWORK,                 /* calling from out of network is not allowed */
        SERVER_ERROR,                   /* server error */
        TIMED_OUT,                      /* client timed out */
        LOST_SIGNAL,
        LIMIT_EXCEEDED,                 /* eg GSM ACM limit exceeded */
        INCOMING_REJECTED,              /* an incoming call that was rejected */
        POWER_OFF,                      /* radio is turned off explicitly */
        OUT_OF_SERVICE,                 /* out of service */
        ICC_ERROR,                      /* No ICC, ICC locked, or other ICC error */
        CALL_BARRED,                    /* call was blocked by call barring */
        FDN_BLOCKED,                    /* call was blocked by fixed dial number */
        CS_RESTRICTED,                  /* call was blocked by restricted all voice access */
        CS_RESTRICTED_NORMAL,           /* call was blocked by restricted normal voice access */
        CS_RESTRICTED_EMERGENCY,        /* call was blocked by restricted emergency voice access */
        UNOBTAINABLE_NUMBER,            /* Unassigned number (3GPP TS 24.008 table 10.5.123) */
        VT_NO_ANSWER,
        VT_CALL_REJECTED,
	FALLBACK_VT,			/* MT hope fallback VT call to normal voice call */
	VT_BEARER_CAP_NOT_AVAIL,	/* VT Bearer capability is not available. Phone app should enter fallback process*/
	VT_BEARER_CAP_NOT_AUTHORIZED,	/* VT Bearer capability is not authorized. Phone app should enter fallback process*/
	VT_RESOURCE_NOT_AVAIL,		/* VT resource is tempararily unavailable. Phone app should enter fallback process*/
        IMSI_UNKNOWN_IN_VLR,            /* IMSI is not known at the VLR */
        IMEI_NOT_ACCEPTED,              /* network does not accept emergency call establishment using an IMEI */
        
        CDMA_LOCKED_UNTIL_POWER_CYCLE,  /* MS is locked until next power cycle */
        CDMA_DROP,
        CDMA_INTERCEPT,                 /* INTERCEPT order received, MS state idle entered */
        CDMA_REORDER,                   /* MS has been redirected, call is cancelled */
        CDMA_SO_REJECT,                 /* service option rejection */
        CDMA_RETRY_ORDER,               /* requested service is rejected, retry delay is set */
        CDMA_ACCESS_FAILURE,
        CDMA_PREEMPTED,
        CDMA_NOT_EMERGENCY,              /* not an emergency call */
        CDMA_ACCESS_BLOCKED,            /* Access Blocked by CDMA network */
        ERROR_UNSPECIFIED,
        USER_ALERTING_NO_ANSWER, // 19 
        NO_ROUTE_TO_DESTINATION, // 3 
        CHANNEL_UNACCEPTABLE, // 6
        OPERATOR_DETERMINED_BARRING, // 8
        NO_USER_RESPONDING, //18
        CALL_REJECTED, // 21
        NUMBER_CHANGED, // 22
        PRE_EMPTION, // 25
        NON_SELECTED_USER_CLEARING, // 26
        DESTINATION_OUT_OF_ORDER, // 27
        INVALID_NUMBER_FORMAT, // 28
        FACILITY_REJECTED, // 29
        STATUS_ENQUIRY, // 30
        NORMAL_UNSPECIFIED, // 31
        NETWORK_OUT_OF_ORDER, // 38
        TEMPORARY_FAILURE, //41 
        SWITCHING_CONGESTION, //42
        ACCESS_INFORMATION_DISCARDED, // 43
        CHANNEL_NOT_AVAIL, //44
        RESOURCES_UNAVAILABLE_UNSPECIFIED, // 47
        QOS_NOT_AVAIL, //49
        REQUESTED_FACILITY_NOT_SUBSCRIBED, // 50
        INCOMING_CALLS_BARRED_WITHIN_THE_CUG, // 55
        BEARER_CAPABILITY_NOT_AUTHORIZED, // 57
        BEARER_NOT_AVAIL, //58
        SERVICE_OR_OPTION_NOT_AVAILABLE_UNSPECIFIED, // 63
        BEARER_SERVICE_NOT_IMPLEMENTED, // 65
        REQUESTED_FACILITY_NOT_IMPLEMENTED, // 69
        ONLY_RESTRICTED_DIGITAL_INFO_BC_AVAILABLE, // 70
        SERVICE_OR_OPTION_NOT_IMPLEMENTED, // 79
        INVALID_TRANSACTION_IDENTIFIER_VALUE, // 81
        USER_NOT_MEMBER_OF_CUG, // 87
        INCOMPATIBLE_DESTINATION, // 88
        INVALID_TRANSIT_NETWORK_SELECTION, // 91
        SEMANTICALLY_INCORRECT_MESSAGE, // 95
        INVALID_MANDATORY_INFORMATION, // 96
        MESSAGE_TYPE_NON_EXISTENT, // 97
        MESSAGE_TYPE_NOT_COMPATIBLE_PROTOCOL_STATE, // 98
        INFORMATION_ELEMENT_NON_EXISTENT, // 99
        CONDITIONAL_IE_ERROR, // 100
        MESSAGE_NOT_COMPATIBLE_PROTOCOL_STATE, // 101
        RECOVERY_ON_TIMER_EXPIRY, // 102
        PROTOCOL_ERROR_UNSPECIFIED, // 111
        INTERWORKING_UNSPECIFIED // 127
    }

    Object userData;

    boolean vtFlag;

    /* Instance Methods */

    /**
     * Gets address (e.g. phone number) associated with connection.
     * TODO: distinguish reasons for unavailability
     *
     * @return address or null if unavailable
     */

    public abstract String getAddress();

    /**
     * Gets CDMA CNAP name associated with connection.
     * @return cnap name or null if unavailable
     */
    public String getCnapName() {
        return null;
    }

    /**
     * Get original dial string.
     * @return original dial string or null if unavailable
     */
    public String getOrigDialString(){
        return null;
    }

    /**
     * Gets CDMA CNAP presentation associated with connection.
     * @return cnap name or null if unavailable
     */

    public int getCnapNamePresentation() {
       return 0;
    };

    /**
     * @return Call that owns this Connection, or null if none
     */
    public abstract Call getCall();

    /**
     * Connection create time in currentTimeMillis() format
     * Basically, set when object is created.
     * Effectively, when an incoming call starts ringing or an
     * outgoing call starts dialing
     */
    public abstract long getCreateTime();

    /**
     * Connection connect time in currentTimeMillis() format.
     * For outgoing calls: Begins at (DIALING|ALERTING) -> ACTIVE transition.
     * For incoming calls: Begins at (INCOMING|WAITING) -> ACTIVE transition.
     * Returns 0 before then.
     */
    public abstract long getConnectTime();

    /**
     * Disconnect time in currentTimeMillis() format.
     * The time when this Connection makes a transition into ENDED or FAIL.
     * Returns 0 before then.
     */
    public abstract long getDisconnectTime();

    /**
     * Returns the number of milliseconds the call has been connected,
     * or 0 if the call has never connected.
     * If the call is still connected, then returns the elapsed
     * time since connect.
     */
    public abstract long getDurationMillis();

    /**
     * If this connection is HOLDING, return the number of milliseconds
     * that it has been on hold for (approximately).
     * If this connection is in any other state, return 0.
     */

    public abstract long getHoldDurationMillis();

    /**
     * Returns "NOT_DISCONNECTED" if not yet disconnected.
     */
    public abstract DisconnectCause getDisconnectCause();

    /**
     * Returns true of this connection originated elsewhere
     * ("MT" or mobile terminated; another party called this terminal)
     * or false if this call originated here (MO or mobile originated).
     */
    public abstract boolean isIncoming();

    public abstract boolean isForeign();
    /**
     * If this Connection is connected, then it is associated with
     * a Call.
     *
     * Returns getCall().getState() or Call.State.IDLE if not
     * connected
     */
    public Call.State getState() {
        Call c;

        c = getCall();

        if (c == null) {
            return Call.State.IDLE;
        } else {
            return c.getState();
        }
    }

    /**
     * isAlive()
     *
     * @return true if the connection isn't disconnected
     * (could be active, holding, ringing, dialing, etc)
     */
    public boolean
    isAlive() {
        return getState().isAlive();
    }

    /**
     * isVideoCall()
     *
     * @return true if the connection isn't disconnected
     * (could be active, holding, ringing, dialing, etc)
     */
    public boolean
    isVideoCall() {
        return vtFlag;
    }

    public boolean
    setVTFlag(boolean flag) {
        return vtFlag = flag;
    }

    /**
     * Returns true if Connection is connected and is INCOMING or WAITING
     */
    public boolean
    isRinging() {
        return getState().isRinging();
    }

    /**
     *
     * @return the userdata set in setUserData()
     */
    public Object getUserData() {
        return userData;
    }

    /**
     *
     * @param userdata user can store an any userdata in the Connection object.
     */
    public void setUserData(Object userdata) {
        this.userData = userdata;
    }

    /**
     * Hangup individual Connection
     */
    public abstract void hangup() throws CallStateException;

    /**
     * Hangup individual Connection
     */
    public abstract void hangupVT() throws CallStateException;

    /**
     * Fallback individual VT Connection to voice call
     */
    public abstract void fallbackVT() throws CallStateException;

    /**
     * Separate this call from its owner Call and assigns it to a new Call
     * (eg if it is currently part of a Conference call
     * TODO: Throw exception? Does GSM require error display on failure here?
     */
    public abstract void separate() throws CallStateException;

    public enum PostDialState {
        NOT_STARTED,    /* The post dial string playback hasn't
                           been started, or this call is not yet
                           connected, or this is an incoming call */
        STARTED,        /* The post dial string playback has begun */
        WAIT,           /* The post dial string playback is waiting for a
                           call to proceedAfterWaitChar() */
        WILD,           /* The post dial string playback is waiting for a
                           call to proceedAfterWildChar() */
        COMPLETE,       /* The post dial string playback is complete */
        CANCELLED,       /* The post dial string playback was cancelled
                           with cancelPostDial() */
        PAUSE           /* The post dial string playback is pausing for a
                           call to processNextPostDialChar*/
    }

    public void clearUserData(){
        userData = null;
    }

    public abstract PostDialState getPostDialState();

    /**
     * Returns the portion of the post dial string that has not
     * yet been dialed, or "" if none
     */
    public abstract String getRemainingPostDialString();

    /**
     * See Phone.setOnPostDialWaitCharacter()
     */

    public abstract void proceedAfterWaitChar();

    /**
     * See Phone.setOnPostDialWildCharacter()
     */
    public abstract void proceedAfterWildChar(String str);
    /**
     * Cancel any post
     */
    public abstract void cancelPostDial();

    /**
     * Returns the caller id presentation type for incoming and waiting calls
     * @return one of PRESENTATION_*
     */
    public abstract int getNumberPresentation();

    /**
     * Returns the User to User Signaling (UUS) information associated with
     * incoming and waiting calls
     * @return UUSInfo containing the UUS userdata.
     */
    public abstract UUSInfo getUUSInfo();

    /**
     * Build a human representation of a connection instance, suitable for debugging.
     * Don't log personal stuff unless in debug mode.
     * @return a string representing the internal state of this connection.
     */
    public String toString() {
        StringBuilder str = new StringBuilder(128);

        if (Log.isLoggable(LOG_TAG, Log.DEBUG)) {
            str.append("addr: " + getAddress())
                    .append(" pres.: " + getNumberPresentation())
                    .append(" dial: " + getOrigDialString())
                    .append(" postdial: " + getRemainingPostDialString())
                    .append(" cnap name: " + getCnapName())
                    .append("(" + getCnapNamePresentation() + ")");
        }
        str.append(" incoming: " + isIncoming())
                .append(" state: " + getState())
                .append(" post dial state: " + getPostDialState());
        return str.toString();
    }
}
