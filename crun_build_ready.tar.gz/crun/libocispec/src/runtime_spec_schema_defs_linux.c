// Generated from defs-linux.json. Do not edit!
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <string.h>
#include <read-file.h>
#include "runtime_spec_schema_defs_linux.h"

#define YAJL_GET_ARRAY_NO_CHECK(v) (&(v)->u.array)
#define YAJL_GET_OBJECT_NO_CHECK(v) (&(v)->u.object)
runtime_spec_schema_defs_linux_personality *
make_runtime_spec_schema_defs_linux_personality (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_personality *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "domain", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->domain = strdup (str ? str : "");
            if (ret->domain == NULL)
              {
                free_runtime_spec_schema_defs_linux_personality (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val tmp = get_val (tree, "flags", yajl_t_array);
        if (tmp != NULL && YAJL_GET_ARRAY (tmp) != NULL && YAJL_GET_ARRAY_NO_CHECK (tmp)->len > 0)
          {
            size_t i;
            size_t len = YAJL_GET_ARRAY_NO_CHECK (tmp)->len;
            yajl_val *values = YAJL_GET_ARRAY_NO_CHECK (tmp)->values;
            ret->flags_len = len;
            ret->flags = calloc (len + 1, sizeof (*ret->flags));
            if (ret->flags == NULL)
              {
                free_runtime_spec_schema_defs_linux_personality (ret);
                return NULL;
              }
            for (i = 0; i < len; i++)
              {
                yajl_val val = values[i];
                if (val != NULL)
                  {
                    char *str = YAJL_GET_STRING (val);
                    ret->flags[i] = strdup (str ? str : "");
                    if (ret->flags[i] == NULL)
                      {
                        free_runtime_spec_schema_defs_linux_personality (ret);
                        return NULL;
                      }
                  }
              }
        }
      }
    while (0);

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "domain")
                && strcmp (tree->u.object.keys[i], "flags") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_personality (runtime_spec_schema_defs_linux_personality *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr->domain);
    ptr->domain = NULL;
    if (ptr->flags != NULL)
      {
        size_t i;
        for (i = 0; i < ptr->flags_len; i++)
          {
            if (ptr->flags[i] != NULL)
              {
                free (ptr->flags[i]);
                ptr->flags[i] = NULL;
              }
          }
        free (ptr->flags);
        ptr->flags = NULL;
    }
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_personality (yajl_gen g, const runtime_spec_schema_defs_linux_personality *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->domain != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("domain"), 6 /* strlen ("domain") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->domain != NULL)
            str = ptr->domain;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->flags != NULL))
      {
        size_t len = 0, i;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("flags"), 5 /* strlen ("flags") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->flags != NULL)
          len = ptr->flags_len;
        if (!len && !(ctx->options & OPT_GEN_SIMPLIFY))
            yajl_gen_config (g, yajl_gen_beautify, 0);
        stat = yajl_gen_array_open ((yajl_gen) g);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        for (i = 0; i < len; i++)
          {
            stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(ptr->flags[i]), strlen (ptr->flags[i]));
            if (stat != yajl_gen_status_ok)
                GEN_SET_ERROR_AND_RETURN (stat, err);
          }
        stat = yajl_gen_array_close ((yajl_gen) g);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (!len && !(ctx->options & OPT_GEN_SIMPLIFY))
            yajl_gen_config (g, yajl_gen_beautify, 1);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_syscall_arg *
make_runtime_spec_schema_defs_linux_syscall_arg (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_syscall_arg *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "index", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint32 (YAJL_GET_NUMBER (val), &ret->index);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint32' for key 'index': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_syscall_arg (ret);
                return NULL;
            }
            ret->index_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "value", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint64 (YAJL_GET_NUMBER (val), &ret->value);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint64' for key 'value': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_syscall_arg (ret);
                return NULL;
            }
            ret->value_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "valueTwo", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint64 (YAJL_GET_NUMBER (val), &ret->value_two);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint64' for key 'valueTwo': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_syscall_arg (ret);
                return NULL;
            }
            ret->value_two_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "op", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->op = strdup (str ? str : "");
            if (ret->op == NULL)
              {
                free_runtime_spec_schema_defs_linux_syscall_arg (ret);
                return NULL;
              }
          }
      }
    while (0);
    if (ret->op == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "op") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_linux_syscall_arg (ret);
        return NULL;
      }

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "index")
                && strcmp (tree->u.object.keys[i], "value")
                && strcmp (tree->u.object.keys[i], "valueTwo")
                && strcmp (tree->u.object.keys[i], "op") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_syscall_arg (runtime_spec_schema_defs_linux_syscall_arg *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr->op);
    ptr->op = NULL;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_syscall_arg (yajl_gen g, const runtime_spec_schema_defs_linux_syscall_arg *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->index_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("index"), 5 /* strlen ("index") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->index)
            num = (long long unsigned int)ptr->index;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->value_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("value"), 5 /* strlen ("value") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->value)
            num = (long long unsigned int)ptr->value;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->value_two_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("valueTwo"), 8 /* strlen ("valueTwo") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->value_two)
            num = (long long unsigned int)ptr->value_two;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->op != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("op"), 2 /* strlen ("op") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->op != NULL)
            str = ptr->op;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_syscall *
make_runtime_spec_schema_defs_linux_syscall (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_syscall *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val tmp = get_val (tree, "names", yajl_t_array);
        if (tmp != NULL && YAJL_GET_ARRAY (tmp) != NULL && YAJL_GET_ARRAY_NO_CHECK (tmp)->len > 0)
          {
            size_t i;
            size_t len = YAJL_GET_ARRAY_NO_CHECK (tmp)->len;
            yajl_val *values = YAJL_GET_ARRAY_NO_CHECK (tmp)->values;
            ret->names_len = len;
            ret->names = calloc (len + 1, sizeof (*ret->names));
            if (ret->names == NULL)
              {
                free_runtime_spec_schema_defs_linux_syscall (ret);
                return NULL;
              }
            for (i = 0; i < len; i++)
              {
                yajl_val val = values[i];
                if (val != NULL)
                  {
                    char *str = YAJL_GET_STRING (val);
                    ret->names[i] = strdup (str ? str : "");
                    if (ret->names[i] == NULL)
                      {
                        free_runtime_spec_schema_defs_linux_syscall (ret);
                        return NULL;
                      }
                  }
              }
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "action", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->action = strdup (str ? str : "");
            if (ret->action == NULL)
              {
                free_runtime_spec_schema_defs_linux_syscall (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "errnoRet", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint32 (YAJL_GET_NUMBER (val), &ret->errno_ret);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint32' for key 'errnoRet': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_syscall (ret);
                return NULL;
            }
            ret->errno_ret_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val tmp = get_val (tree, "args", yajl_t_array);
        if (tmp != NULL && YAJL_GET_ARRAY (tmp) != NULL && YAJL_GET_ARRAY_NO_CHECK (tmp)->len > 0)
          {
            size_t i;
            size_t len = YAJL_GET_ARRAY_NO_CHECK (tmp)->len;
            yajl_val *values = YAJL_GET_ARRAY_NO_CHECK (tmp)->values;
            ret->args_len = len;
            ret->args = calloc (len + 1, sizeof (*ret->args));
            if (ret->args == NULL)
              {
                free_runtime_spec_schema_defs_linux_syscall (ret);
                return NULL;
              }
            for (i = 0; i < len; i++)
              {
                yajl_val val = values[i];
                ret->args[i] = make_runtime_spec_schema_defs_linux_syscall_arg (val, ctx, err);
                if (ret->args[i] == NULL)
                  {
                    free_runtime_spec_schema_defs_linux_syscall (ret);
                    return NULL;
                }
            }
        }
      }
    while (0);
    if (ret->names == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "names") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_linux_syscall (ret);
        return NULL;
      }
    if (ret->action == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "action") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_linux_syscall (ret);
        return NULL;
      }

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "names")
                && strcmp (tree->u.object.keys[i], "action")
                && strcmp (tree->u.object.keys[i], "errnoRet")
                && strcmp (tree->u.object.keys[i], "args") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_syscall (runtime_spec_schema_defs_linux_syscall *ptr)
{
    if (ptr == NULL)
        return;
    if (ptr->names != NULL)
      {
        size_t i;
        for (i = 0; i < ptr->names_len; i++)
          {
            if (ptr->names[i] != NULL)
              {
                free (ptr->names[i]);
                ptr->names[i] = NULL;
              }
          }
        free (ptr->names);
        ptr->names = NULL;
    }
    free (ptr->action);
    ptr->action = NULL;
    if (ptr->args != NULL)
      {
        size_t i;
        for (i = 0; i < ptr->args_len; i++)
          if (ptr->args[i] != NULL)
            {
              free_runtime_spec_schema_defs_linux_syscall_arg (ptr->args[i]);
              ptr->args[i] = NULL;
            }
        free (ptr->args);
        ptr->args = NULL;
      }
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_syscall (yajl_gen g, const runtime_spec_schema_defs_linux_syscall *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->names != NULL))
      {
        size_t len = 0, i;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("names"), 5 /* strlen ("names") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->names != NULL)
          len = ptr->names_len;
        if (!len && !(ctx->options & OPT_GEN_SIMPLIFY))
            yajl_gen_config (g, yajl_gen_beautify, 0);
        stat = yajl_gen_array_open ((yajl_gen) g);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        for (i = 0; i < len; i++)
          {
            stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(ptr->names[i]), strlen (ptr->names[i]));
            if (stat != yajl_gen_status_ok)
                GEN_SET_ERROR_AND_RETURN (stat, err);
          }
        stat = yajl_gen_array_close ((yajl_gen) g);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (!len && !(ctx->options & OPT_GEN_SIMPLIFY))
            yajl_gen_config (g, yajl_gen_beautify, 1);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->action != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("action"), 6 /* strlen ("action") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->action != NULL)
            str = ptr->action;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->errno_ret_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("errnoRet"), 8 /* strlen ("errnoRet") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->errno_ret)
            num = (long long unsigned int)ptr->errno_ret;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->args != NULL))
      {
        size_t len = 0, i;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("args"), 4 /* strlen ("args") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->args != NULL)
            len = ptr->args_len;
        if (!len && !(ctx->options & OPT_GEN_SIMPLIFY))
            yajl_gen_config (g, yajl_gen_beautify, 0);
        stat = yajl_gen_array_open ((yajl_gen) g);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        for (i = 0; i < len; i++)
          {
            stat = gen_runtime_spec_schema_defs_linux_syscall_arg (g, ptr->args[i], ctx, err);
            if (stat != yajl_gen_status_ok)
                GEN_SET_ERROR_AND_RETURN (stat, err);
        }
        stat = yajl_gen_array_close ((yajl_gen) g);
        if (!len && !(ctx->options & OPT_GEN_SIMPLIFY))
            yajl_gen_config (g, yajl_gen_beautify, 1);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_device *
make_runtime_spec_schema_defs_linux_device (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_device *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "type", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->type = strdup (str ? str : "");
            if (ret->type == NULL)
              {
                free_runtime_spec_schema_defs_linux_device (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "path", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->path = strdup (str ? str : "");
            if (ret->path == NULL)
              {
                free_runtime_spec_schema_defs_linux_device (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "fileMode", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int (YAJL_GET_NUMBER (val), (int *)&ret->file_mode);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'integer' for key 'fileMode': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_device (ret);
                return NULL;
            }
            ret->file_mode_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "major", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->major);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'major': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_device (ret);
                return NULL;
            }
            ret->major_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "minor", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->minor);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'minor': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_device (ret);
                return NULL;
            }
            ret->minor_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "uid", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint (YAJL_GET_NUMBER (val), (unsigned int *)&ret->uid);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'UID' for key 'uid': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_device (ret);
                return NULL;
            }
            ret->uid_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "gid", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint (YAJL_GET_NUMBER (val), (unsigned int *)&ret->gid);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'GID' for key 'gid': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_device (ret);
                return NULL;
            }
            ret->gid_present = 1;
        }
      }
    while (0);
    if (ret->type == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "type") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_linux_device (ret);
        return NULL;
      }
    if (ret->path == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "path") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_linux_device (ret);
        return NULL;
      }

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "type")
                && strcmp (tree->u.object.keys[i], "path")
                && strcmp (tree->u.object.keys[i], "fileMode")
                && strcmp (tree->u.object.keys[i], "major")
                && strcmp (tree->u.object.keys[i], "minor")
                && strcmp (tree->u.object.keys[i], "uid")
                && strcmp (tree->u.object.keys[i], "gid") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_device (runtime_spec_schema_defs_linux_device *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr->type);
    ptr->type = NULL;
    free (ptr->path);
    ptr->path = NULL;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_device (yajl_gen g, const runtime_spec_schema_defs_linux_device *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->type != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("type"), 4 /* strlen ("type") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->type != NULL)
            str = ptr->type;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->path != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("path"), 4 /* strlen ("path") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->path != NULL)
            str = ptr->path;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->file_mode_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("fileMode"), 8 /* strlen ("fileMode") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->file_mode)
            num = (long long int)ptr->file_mode;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->major_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("major"), 5 /* strlen ("major") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->major)
            num = (long long int)ptr->major;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->minor_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("minor"), 5 /* strlen ("minor") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->minor)
            num = (long long int)ptr->minor;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->uid_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("uid"), 3 /* strlen ("uid") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->uid)
            num = (long long unsigned int)ptr->uid;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->gid_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("gid"), 3 /* strlen ("gid") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->gid)
            num = (long long unsigned int)ptr->gid;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_block_io_device *
make_runtime_spec_schema_defs_linux_block_io_device (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_block_io_device *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "major", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->major);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'major': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device (ret);
                return NULL;
            }
            ret->major_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "minor", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->minor);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'minor': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device (ret);
                return NULL;
            }
            ret->minor_present = 1;
        }
      }
    while (0);

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "major")
                && strcmp (tree->u.object.keys[i], "minor") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_block_io_device (runtime_spec_schema_defs_linux_block_io_device *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_block_io_device (yajl_gen g, const runtime_spec_schema_defs_linux_block_io_device *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->major_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("major"), 5 /* strlen ("major") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->major)
            num = (long long int)ptr->major;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->minor_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("minor"), 5 /* strlen ("minor") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->minor)
            num = (long long int)ptr->minor;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_block_io_device_weight *
make_runtime_spec_schema_defs_linux_block_io_device_weight (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_block_io_device_weight *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "major", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->major);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'major': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device_weight (ret);
                return NULL;
            }
            ret->major_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "minor", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->minor);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'minor': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device_weight (ret);
                return NULL;
            }
            ret->minor_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "weight", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint16 (YAJL_GET_NUMBER (val), &ret->weight);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint16' for key 'weight': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device_weight (ret);
                return NULL;
            }
            ret->weight_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "leafWeight", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint16 (YAJL_GET_NUMBER (val), &ret->leaf_weight);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint16' for key 'leafWeight': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device_weight (ret);
                return NULL;
            }
            ret->leaf_weight_present = 1;
        }
      }
    while (0);

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "major")
                && strcmp (tree->u.object.keys[i], "minor")
                && strcmp (tree->u.object.keys[i], "weight")
                && strcmp (tree->u.object.keys[i], "leafWeight") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_block_io_device_weight (runtime_spec_schema_defs_linux_block_io_device_weight *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_block_io_device_weight (yajl_gen g, const runtime_spec_schema_defs_linux_block_io_device_weight *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->major_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("major"), 5 /* strlen ("major") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->major)
            num = (long long int)ptr->major;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->minor_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("minor"), 5 /* strlen ("minor") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->minor)
            num = (long long int)ptr->minor;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->weight_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("weight"), 6 /* strlen ("weight") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->weight)
            num = (long long unsigned int)ptr->weight;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->leaf_weight_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("leafWeight"), 10 /* strlen ("leafWeight") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->leaf_weight)
            num = (long long unsigned int)ptr->leaf_weight;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_block_io_device_throttle *
make_runtime_spec_schema_defs_linux_block_io_device_throttle (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_block_io_device_throttle *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "major", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->major);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'major': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device_throttle (ret);
                return NULL;
            }
            ret->major_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "minor", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->minor);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'minor': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device_throttle (ret);
                return NULL;
            }
            ret->minor_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "rate", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint64 (YAJL_GET_NUMBER (val), &ret->rate);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint64' for key 'rate': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_block_io_device_throttle (ret);
                return NULL;
            }
            ret->rate_present = 1;
        }
      }
    while (0);

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "major")
                && strcmp (tree->u.object.keys[i], "minor")
                && strcmp (tree->u.object.keys[i], "rate") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_block_io_device_throttle (runtime_spec_schema_defs_linux_block_io_device_throttle *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_block_io_device_throttle (yajl_gen g, const runtime_spec_schema_defs_linux_block_io_device_throttle *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->major_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("major"), 5 /* strlen ("major") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->major)
            num = (long long int)ptr->major;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->minor_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("minor"), 5 /* strlen ("minor") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->minor)
            num = (long long int)ptr->minor;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->rate_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("rate"), 4 /* strlen ("rate") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->rate)
            num = (long long unsigned int)ptr->rate;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_device_cgroup *
make_runtime_spec_schema_defs_linux_device_cgroup (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_device_cgroup *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "allow", yajl_t_true);
        if (val != NULL)
          {
            ret->allow = YAJL_IS_TRUE(val);
            ret->allow_present = 1;
          }
        else
          {
            val = get_val (tree, "allow", yajl_t_false);
            if (val != NULL)
              {
                ret->allow = 0;
                ret->allow_present = 1;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "type", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->type = strdup (str ? str : "");
            if (ret->type == NULL)
              {
                free_runtime_spec_schema_defs_linux_device_cgroup (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "major", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->major);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'major': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_device_cgroup (ret);
                return NULL;
            }
            ret->major_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "minor", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_int64 (YAJL_GET_NUMBER (val), &ret->minor);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'int64' for key 'minor': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_device_cgroup (ret);
                return NULL;
            }
            ret->minor_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "access", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->access = strdup (str ? str : "");
            if (ret->access == NULL)
              {
                free_runtime_spec_schema_defs_linux_device_cgroup (ret);
                return NULL;
              }
          }
      }
    while (0);

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "allow")
                && strcmp (tree->u.object.keys[i], "type")
                && strcmp (tree->u.object.keys[i], "major")
                && strcmp (tree->u.object.keys[i], "minor")
                && strcmp (tree->u.object.keys[i], "access") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_device_cgroup (runtime_spec_schema_defs_linux_device_cgroup *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr->type);
    ptr->type = NULL;
    free (ptr->access);
    ptr->access = NULL;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_device_cgroup (yajl_gen g, const runtime_spec_schema_defs_linux_device_cgroup *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->allow_present))
      {
        bool b = false;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("allow"), 5 /* strlen ("allow") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->allow)
            b = ptr->allow;
        
        stat = yajl_gen_bool ((yajl_gen)g, (int)(b));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->type != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("type"), 4 /* strlen ("type") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->type != NULL)
            str = ptr->type;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->major_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("major"), 5 /* strlen ("major") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->major)
            num = (long long int)ptr->major;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->minor_present))
      {
        long long int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("minor"), 5 /* strlen ("minor") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->minor)
            num = (long long int)ptr->minor;
        stat = map_int (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->access != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("access"), 6 /* strlen ("access") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->access != NULL)
            str = ptr->access;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_network_interface_priority *
make_runtime_spec_schema_defs_linux_network_interface_priority (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_network_interface_priority *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "name", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->name = strdup (str ? str : "");
            if (ret->name == NULL)
              {
                free_runtime_spec_schema_defs_linux_network_interface_priority (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "priority", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint32 (YAJL_GET_NUMBER (val), &ret->priority);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint32' for key 'priority': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_network_interface_priority (ret);
                return NULL;
            }
            ret->priority_present = 1;
        }
      }
    while (0);
    if (ret->name == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "name") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_linux_network_interface_priority (ret);
        return NULL;
      }

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "name")
                && strcmp (tree->u.object.keys[i], "priority") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_network_interface_priority (runtime_spec_schema_defs_linux_network_interface_priority *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr->name);
    ptr->name = NULL;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_network_interface_priority (yajl_gen g, const runtime_spec_schema_defs_linux_network_interface_priority *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->name != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("name"), 4 /* strlen ("name") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->name != NULL)
            str = ptr->name;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->priority_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("priority"), 8 /* strlen ("priority") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->priority)
            num = (long long unsigned int)ptr->priority;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_rdma *
make_runtime_spec_schema_defs_linux_rdma (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_rdma *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "hcaHandles", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint32 (YAJL_GET_NUMBER (val), &ret->hca_handles);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint32' for key 'hcaHandles': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_rdma (ret);
                return NULL;
            }
            ret->hca_handles_present = 1;
        }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "hcaObjects", yajl_t_number);
        if (val != NULL)
          {
            int invalid = common_safe_uint32 (YAJL_GET_NUMBER (val), &ret->hca_objects);
            if (invalid)
              {
                if (asprintf (err, "Invalid value '%s' with type 'uint32' for key 'hcaObjects': %s", YAJL_GET_NUMBER (val), strerror (-invalid)) < 0)
                    *err = strdup ("error allocating memory");
                free_runtime_spec_schema_defs_linux_rdma (ret);
                return NULL;
            }
            ret->hca_objects_present = 1;
        }
      }
    while (0);

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "hcaHandles")
                && strcmp (tree->u.object.keys[i], "hcaObjects") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_rdma (runtime_spec_schema_defs_linux_rdma *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_rdma (yajl_gen g, const runtime_spec_schema_defs_linux_rdma *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->hca_handles_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("hcaHandles"), 10 /* strlen ("hcaHandles") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->hca_handles)
            num = (long long unsigned int)ptr->hca_handles;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->hca_objects_present))
      {
        long long unsigned int num = 0;
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("hcaObjects"), 10 /* strlen ("hcaObjects") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->hca_objects)
            num = (long long unsigned int)ptr->hca_objects;
        stat = map_uint (g, num);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

runtime_spec_schema_defs_linux_namespace_reference *
make_runtime_spec_schema_defs_linux_namespace_reference (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_linux_namespace_reference *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "type", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->type = strdup (str ? str : "");
            if (ret->type == NULL)
              {
                free_runtime_spec_schema_defs_linux_namespace_reference (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "path", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->path = strdup (str ? str : "");
            if (ret->path == NULL)
              {
                free_runtime_spec_schema_defs_linux_namespace_reference (ret);
                return NULL;
              }
          }
      }
    while (0);
    if (ret->type == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "type") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_linux_namespace_reference (ret);
        return NULL;
      }

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "type")
                && strcmp (tree->u.object.keys[i], "path") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_linux_namespace_reference (runtime_spec_schema_defs_linux_namespace_reference *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr->type);
    ptr->type = NULL;
    free (ptr->path);
    ptr->path = NULL;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_linux_namespace_reference (yajl_gen g, const runtime_spec_schema_defs_linux_namespace_reference *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->type != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("type"), 4 /* strlen ("type") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->type != NULL)
            str = ptr->type;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->path != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("path"), 4 /* strlen ("path") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->path != NULL)
            str = ptr->path;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

