// Generated from defs-windows.json. Do not edit!
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <string.h>
#include <read-file.h>
#include "runtime_spec_schema_defs_windows.h"

#define YAJL_GET_ARRAY_NO_CHECK(v) (&(v)->u.array)
#define YAJL_GET_OBJECT_NO_CHECK(v) (&(v)->u.object)
runtime_spec_schema_defs_windows_device *
make_runtime_spec_schema_defs_windows_device (yajl_val tree, const struct parser_context *ctx, parser_error *err)
{
    runtime_spec_schema_defs_windows_device *ret = NULL;
    *err = NULL;
    (void) ctx;  /* Silence compiler warning.  */
    if (tree == NULL)
      return ret;
    ret = calloc (1, sizeof (*ret));
    if (ret == NULL)
      return NULL;
    do
      {
        yajl_val val = get_val (tree, "id", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->id = strdup (str ? str : "");
            if (ret->id == NULL)
              {
                free_runtime_spec_schema_defs_windows_device (ret);
                return NULL;
              }
          }
      }
    while (0);
    do
      {
        yajl_val val = get_val (tree, "idType", yajl_t_string);
        if (val != NULL)
          {
            char *str = YAJL_GET_STRING (val);
            ret->id_type = strdup (str ? str : "");
            if (ret->id_type == NULL)
              {
                free_runtime_spec_schema_defs_windows_device (ret);
                return NULL;
              }
          }
      }
    while (0);
    if (ret->id == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "id") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_windows_device (ret);
        return NULL;
      }
    if (ret->id_type == NULL)
      {
        if (asprintf (err, "Required field '%s' not present",  "idType") < 0)
            *err = strdup ("error allocating memory");
        free_runtime_spec_schema_defs_windows_device (ret);
        return NULL;
      }

    if (tree->type == yajl_t_object && (ctx->options & OPT_PARSE_STRICT))
      {
        size_t i;
        for (i = 0; i < tree->u.object.len; i++)
          {
            if (strcmp (tree->u.object.keys[i], "id")
                && strcmp (tree->u.object.keys[i], "idType") && ctx->errfile != NULL)
              {
                (void) fprintf (ctx->errfile, "WARNING: unknown key found: %s\n",
                        tree->u.object.keys[i]);
              }
          }
      }
    return ret;
}

void
free_runtime_spec_schema_defs_windows_device (runtime_spec_schema_defs_windows_device *ptr)
{
    if (ptr == NULL)
        return;
    free (ptr->id);
    ptr->id = NULL;
    free (ptr->id_type);
    ptr->id_type = NULL;
    free (ptr);
}

yajl_gen_status
gen_runtime_spec_schema_defs_windows_device (yajl_gen g, const runtime_spec_schema_defs_windows_device *ptr, const struct parser_context *ctx, parser_error *err)
{
    yajl_gen_status stat = yajl_gen_status_ok;
    *err = NULL;
    (void) ptr;  /* Silence compiler warning.  */
    stat = yajl_gen_map_open ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->id != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("id"), 2 /* strlen ("id") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->id != NULL)
            str = ptr->id;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    if ((ctx->options & OPT_GEN_KEY_VALUE) || (ptr != NULL && ptr->id_type != NULL))
      {
        char *str = "";
        stat = yajl_gen_string ((yajl_gen) g, (const unsigned char *)("idType"), 6 /* strlen ("idType") */);
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
        if (ptr != NULL && ptr->id_type != NULL)
            str = ptr->id_type;
        stat = yajl_gen_string ((yajl_gen)g, (const unsigned char *)(str), strlen (str));
        if (stat != yajl_gen_status_ok)
            GEN_SET_ERROR_AND_RETURN (stat, err);
      }
    stat = yajl_gen_map_close ((yajl_gen) g);
    if (stat != yajl_gen_status_ok)
        GEN_SET_ERROR_AND_RETURN (stat, err);
    return yajl_gen_status_ok;
}

