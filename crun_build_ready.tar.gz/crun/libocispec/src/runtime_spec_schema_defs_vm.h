// Generated from defs-vm.json. Do not edit!
#ifndef RUNTIME_SPEC_SCHEMA_DEFS_VM_SCHEMA_H
#define RUNTIME_SPEC_SCHEMA_DEFS_VM_SCHEMA_H

#include <sys/types.h>
#include <stdint.h>
#include "json_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

