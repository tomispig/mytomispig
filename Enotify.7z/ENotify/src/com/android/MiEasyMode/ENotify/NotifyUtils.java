package com.android.MiEasyMode.ENotify;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Calendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import com.android.MiEasyMode.ENotify.R;

public class NotifyUtils {
	private static final String TAG = "NotifyUtils";
	public static final String NOTIFY_ID = "notify_id";
    public static final String NOTIFY_ALARM_ACTION = "com.android.MiEasyMode.ENotify.NOTIFY_ALARM";
	private static final boolean DBG = true;

	public static void setNextAlert(final Context context){
    	Notify nextAlarmNotify = calculateNextAlarmNotify(context);
    	
    	if(nextAlarmNotify != null) {
    		enableAlert(context, nextAlarmNotify);
    	} else {
    		disableAlert(context);
    	}
        

    }
    
    private static void enableAlert(Context context, Notify nextAlarmNotify) {
        AlarmManager am = (AlarmManager)
                context.getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(NOTIFY_ALARM_ACTION);

        // XXX: This is a slight hack to avoid an exception in the remote
        // AlarmManagerService process. The AlarmManager adds extra data to
        // this Intent which causes it to inflate. Since the remote process
        // does not know about the Alarm class, it throws a
        // ClassNotFoundException.
        //
        // To avoid this, we marshall the data ourselves and then parcel a plain
        // byte[] array. The AlarmReceiver class knows to build the Alarm
        // object from the byte[] array.
        intent.putExtra(NOTIFY_ID, nextAlarmNotify.getNotifyId());
        Log.e(TAG, "enableAlert() notifyId = " + nextAlarmNotify.getNotifyId());

        PendingIntent sender = PendingIntent.getBroadcast(
                context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        am.set(AlarmManager.RTC_WAKEUP, nextAlarmNotify.getAlarmTime(), sender);
        Log.e(TAG, "enableAlert() alarmTime = " + nextAlarmNotify.getAlarmTime());
    }
    
    static void disableAlert(Context context) {
        AlarmManager am = (AlarmManager)
                context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent sender = PendingIntent.getBroadcast(
                context, 0, new Intent(NOTIFY_ALARM_ACTION),
                PendingIntent.FLAG_CANCEL_CURRENT);
        am.cancel(sender);
        // Intentionally verbose: always log the lack of a next alarm to provide useful
        // information in bug reports.
        Log.e(TAG, "disableAlert() No next alarm");
    }
    
	public static long calculateAlarmTime(int hour, int minute) {
        // start with now
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(System.currentTimeMillis());

        int nowHour = c.get(Calendar.HOUR_OF_DAY);
        int nowMinute = c.get(Calendar.MINUTE);
        
        // if alarm is behind current time, advance one day
        if (hour < nowHour  ||
            hour == nowHour && minute <= nowMinute) {
            c.add(Calendar.DAY_OF_YEAR, 1);
        }
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
		return c.getTimeInMillis();
	}
    
    private static Notify calculateNextAlarmNotify(final Context context) {
        Cursor cursor = context.getContentResolver().query(NotifyProvider.CONTENT_URI,
        		NotifyList.NOTIFY_PROJECTION, "enabled=1", null, "alarmtime ASC");
        int notifyPosition = -1;
        long now = System.currentTimeMillis();
        long nextAlarmTime = -1;
        Notify nextAlarmNotify = null;
        //boolean isFind = false;
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                    	int hour = cursor.getInt(cursor.getColumnIndexOrThrow(Notify.COLUMN_HOUR_NAME));
                    	int minute = cursor.getInt(cursor.getColumnIndexOrThrow(Notify.COLUMN_MINUTE_NAME));
                    	long alarmTime = calculateAlarmTime(hour, minute);
                    	if(DBG) Log.e(TAG, "calculateNextAlarmNotify() alarmTime = "
                    	      + alarmTime + "   now = " + now + "  position = " + cursor.getPosition());
                		if(nextAlarmTime < 0 || alarmTime < nextAlarmTime) {
                			nextAlarmTime = alarmTime;
                			notifyPosition = cursor.getPosition();
                		}
                    	/*if (alarmTime >= now) {
                    		//find first item
                    		if(!isFind) {
                    			nextAlarmTime = alarmTime;
                    		}
                    		
                    		nextAlarmTime = alarmTime < nextAlarmTime ? alarmTime : nextAlarmTime;
                    		notifyPosition = cursor.getPosition();
                    	}*/
                    } while (cursor.moveToNext());
                }
            } finally {
            	if(notifyPosition >= 0) {
            		boolean success = cursor.moveToPosition(notifyPosition);
            		if(DBG) Log.e(TAG, "enableAlert() finally success = " 
              		      + success + "  notifyPosition = " + notifyPosition);
            		nextAlarmNotify = Notify.from(context, cursor);
            		nextAlarmNotify.setAlarmTime(nextAlarmTime);
            		if(DBG) Log.e(TAG, "enableAlert() finally notifyId = " 
            		      + nextAlarmNotify.getNotifyId() + "  position = " + cursor.getPosition());
            	}
                cursor.close();
            }
        }
        if(DBG) Log.e(TAG, "calculateNextAlarmNotify() nextAlarmNotify = " + nextAlarmNotify);
        return nextAlarmNotify;
    }
    
	public static Object invokeMethod(Class targetClass, Object targetObject,
			String methodName, Class[] parameterTypes, Object... args){
		Method method = null;
		Object ret = null;
		
		//get the method object
		try {
			method = targetClass.getDeclaredMethod(methodName, parameterTypes);
			method.setAccessible(true);   
			if(DBG) Log.e(TAG , "method = " + method);
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException NoSuchMethodException e2 = " + e);
			e.printStackTrace();
		}
		
		//invoke the method
		try {
			if(method != null) {
				ret = method.invoke(targetObject, args);
				if(DBG) Log.e(TAG, "invoke OK Object = " + ret);
			} 
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException e1 = " + e1);
			e1.printStackTrace();
		} catch (IllegalAccessException e2) {
			if(DBG) Log.e(TAG, "reflectException e2 = " + e2);
			// TODO Auto-generated catch block
			e2.printStackTrace();

		} catch (InvocationTargetException e3) {
			if(DBG) Log.e(TAG, "reflectException e3 = " + e3);
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException TargetException = " + e3.getTargetException());
		}
		
		return ret;
    }
	
	public static Object getField(Class targetClass, Object targetObject,
			String fieldName) {
		Object ret = null;
		
		try {
			Field filed = targetClass.getDeclaredField(fieldName);
			//filed.setAccessible(true);
			//AccessibleObject[] objects = new AccessibleObject[1];
			//objects[0] = filed;
			//AccessibleObject.setAccessible(objects, true);
			filed.setAccessible(true);
			ret = filed.get(targetObject);
			if(DBG) Log.e(TAG, "fieldName = " + fieldName + "   filed = " + ret);
		} catch (NoSuchFieldException e5) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException e5 = " + e5);
			e5.printStackTrace();
		} catch (IllegalArgumentException e6) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException e6 = " + e6);
			e6.printStackTrace();
		} catch (IllegalAccessException e7) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException e7 = " + e7);
			e7.printStackTrace();
		}
		
		return ret;
    }
    
	public static Object setField(Class targetClass, Object targetObject,
			String fieldName, Object value) {
		Object ret = null;
		
		try {
			Field filed = targetClass.getDeclaredField(fieldName);
			filed.setAccessible(true);
			
			if(DBG) Log.e(TAG, "fieldName = " + fieldName + "   old filed = " + filed.get(targetObject));
			
			filed.set(targetObject, value);
			if(DBG) Log.e(TAG, "fieldName = " + fieldName + "   new filed = " + filed.get(targetObject));
		} catch (NoSuchFieldException e5) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException e5 = " + e5);
			e5.printStackTrace();
		} catch (IllegalArgumentException e6) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException e6 = " + e6);
			e6.printStackTrace();
		} catch (IllegalAccessException e7) {
			// TODO Auto-generated catch block
			if(DBG) Log.e(TAG, "reflectException e7 = " + e7);
			e7.printStackTrace();
		}
		
		return ret;
    }
	
    public static int sp2Px(float spValue, float fontScale) {
  	  return (int) (spValue * fontScale + 0.5f);
	}
	
	public static void recursionView(ViewGroup viewGroup) {
		int count = viewGroup.getChildCount();
		for(int i = 0; i < count; i++) {
			View v = viewGroup.getChildAt(i);
			if(v instanceof ViewGroup) {
				Log.e(TAG, "begin---- " + v.getClass());
				recursionView((ViewGroup) v);
				Log.e(TAG, "end---- " + v.getClass());
			} else {
			    Log.e(TAG, "getChildAt(" + i + ") = " + v);
			}
		}
	}
	
}
