package com.android.MiEasyMode.ENotify;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.MiEasyMode.ENotify.R;

public class NotifyTitleView extends LinearLayout {

	public NotifyTitleView(Context context) {
		super(context);
	}

    public NotifyTitleView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public NotifyTitleView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
	
    @Override
	protected void onFinishInflate() {
    	super.onFinishInflate();
    	
    	TextView title = (TextView) findViewById(R.id.notify_activity_title);
    	Context context = getContext();

    	if(context instanceof Activity) {
    		//title.setText(((Activity)context).getTitle());
    	}
    }
	
}
