package com.android.MiEasyMode.ENotify;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;

import com.android.MiEasyMode.ENotify.R;

public class NotifyAlarmReceiver extends BroadcastReceiver {
	private static final String TAG = "NotifyAlarmReceiver";

	@Override
	public void onReceive(Context context, Intent intent) {
		Log.e(TAG, "action = " + intent.getAction());
		
		NotifyUtils.setNextAlert(context);
		
		long notifyId = intent.getLongExtra(NotifyUtils.NOTIFY_ID, -1);
		Log.e(TAG, "notifyId = " + notifyId);
		if (notifyId < 0) {
			//Invalid notify id, don't alert
			return;
		}
		
		//NotifyAlertWakeLock.acquireCpuWakeLock(context);
		
		//SystemClock.sleep(5000);
		//Log.e(TAG, "onReceive() sleep 5s done!");
        // Play the alarm alert and vibrate the device.
		Intent notifyIntent = new Intent(context.getApplicationContext(), NotifyAlertActivity.class);
		notifyIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		notifyIntent.putExtra(NotifyUtils.NOTIFY_ID, notifyId);
		context.startActivity(notifyIntent);
	}

}
