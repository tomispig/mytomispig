package com.android.MiEasyMode.ENotify;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

import com.android.MiEasyMode.ENotify.R;

public class NotifyListAdapter extends CursorAdapter {
    private static final String TAG = "NotifyListAdapter";
    private final LayoutInflater mFactory;
    private OnContentChangedListener mOnContentChangedListener;

	public NotifyListAdapter(Context context, Cursor c) {
		super(context, c, true);
		// TODO Auto-generated constructor stub
		mFactory = LayoutInflater.from(context);
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
        if (!(view instanceof NotifyListItem)) {
            Log.e(TAG, "Unexpected bound view: " + view);
            return;
        }

        NotifyListItem headerView = (NotifyListItem) view;
        Notify conv = Notify.from(context, cursor);
        headerView.bind(context, conv);
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
		// TODO Auto-generated method stub
		return mFactory.inflate(R.layout.notify_notify_list_item, parent, false);
	}

    public interface OnContentChangedListener {
        void onContentChanged(NotifyListAdapter adapter);
    }
    
    public void setOnContentChangedListener(OnContentChangedListener l) {
        mOnContentChangedListener = l;
    }
    
    @Override
    protected void onContentChanged() {
        if (getCursor() != null && !getCursor().isClosed()) {
            if (mOnContentChangedListener != null) {
                mOnContentChangedListener.onContentChanged(this);
            }
        }
    }
}
