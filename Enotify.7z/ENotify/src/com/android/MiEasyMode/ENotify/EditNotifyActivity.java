package com.android.MiEasyMode.ENotify;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

import com.android.MiEasyMode.ENotify.R;

public class EditNotifyActivity extends Activity {
    private static final String TAG = "EditNotifyActivity";
    public static final Uri CONTENT_URI =
            Uri.parse("content://notify_provider/notify");
    
	private View mBackBtn;
	private View mDoneBtn;
	private EditText mNotifyEdit;
	private GridView gridview;
	
    private View.OnClickListener mBtnListener = new View.OnClickListener() {
        @Override
		public void onClick(View v) {
            switch(v.getId()) {
                case R.id.back_btn:
                    Log.e(TAG, "mBtnListener: cancle_btn");
                    EditNotifyActivity.this.finish();
                    break;
                case R.id.done_btn:
                    Log.e(TAG, "mBtnListener: next_btn");
                    saveNotify();
                    
                    NotifyUtils.setNextAlert(EditNotifyActivity.this);
                    
                    EditNotifyActivity.this.setResult(SelectTimeActivity.COMPLETE_CREATE_NOTIFY);
                    EditNotifyActivity.this.finish();
                    break;
            }
        }
    };
	
    private final TextWatcher mNotifyMessageWatcher = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
        	Notify.getFakeNotify().setMessage(s.toString());
        }
    };
    
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notify_activity_edit_notify);
        
        PRESET_NOTIFY_STR = new String[] 
    		    { EditNotifyActivity.this.getString(R.string.preset_notify1), 
    			  EditNotifyActivity.this.getString(R.string.preset_notify2), 
    			  EditNotifyActivity.this.getString(R.string.preset_notify3), 
    			  EditNotifyActivity.this.getString(R.string.preset_notify4), 
    			  EditNotifyActivity.this.getString(R.string.preset_notify5), 
    			  EditNotifyActivity.this.getString(R.string.preset_notify6)};
        
        initGridView();
        
        mBackBtn = findViewById(R.id.back_btn);
        mDoneBtn = findViewById(R.id.done_btn);
        mBackBtn.setOnClickListener(mBtnListener);
        mDoneBtn.setOnClickListener(mBtnListener);
        
        mNotifyEdit = (EditText) findViewById(R.id.notify_edit);
        mNotifyEdit.addTextChangedListener(mNotifyMessageWatcher);
        mNotifyEdit.setText(Notify.getFakeNotify().getMessage());
        mNotifyEdit.setSelection(mNotifyEdit.getText().length());
    }

	private String[] PRESET_NOTIFY_STR;
	
	private OnItemClickListener mGridItemClickListener = new OnItemClickListener() {
		
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			View v = view.findViewById(R.id.preset_notify_item);
			if(v instanceof TextView) {
				CharSequence presetText = ((TextView) v).getText();
				
				int index = mNotifyEdit.getSelectionStart();
				mNotifyEdit.getText().insert(index, presetText);
				//Update cursor to the new position 
				mNotifyEdit.setSelection(index + presetText.length());
			}
		}
	};
    private void initGridView() {
        List<Map<String, Object>> items = new ArrayList<Map<String,Object>>();
        for (int i = 0; i < PRESET_NOTIFY_STR.length; i++) {
            Map<String, Object> item = new HashMap<String, Object>();
            item.put("presetNotifyItem", PRESET_NOTIFY_STR[i]);
            items.add(item);
        }
        //ʵ����һ��������
        SimpleAdapter adapter = new SimpleAdapter(this, items, R.layout.notify_grid_item, 
        		new String[]{"presetNotifyItem"}, new int[]{R.id.preset_notify_item});
        //���GridViewʵ��
        gridview = (GridView)findViewById(R.id.preset_notify);
        //��GridView����������������
        gridview.setAdapter(adapter);
        gridview.setOnItemClickListener(mGridItemClickListener);
	}



	private ContentValues createContentValues() {
    	Notify fakeNotify = Notify.getFakeNotify();
        ContentValues values = new ContentValues(8);

        //long time = NotifyUtils.calculateAlarmTime(fakeNotify.getHour(), 
        //											fakeNotify.getMinute());
        
        values.put(Notify.COLUMN_ENABLED_NAME, 1);//now we always enable
        values.put(Notify.COLUMN_HOUR_NAME, fakeNotify.getHour());
        values.put(Notify.COLUMN_MINUTE_NAME, fakeNotify.getMinute());
        values.put(Notify.COLUMN_MESSAGE_NAME, fakeNotify.getMessage());
        //values.put(Notify.COLUMN_ALARM_TIME_NAME, time);

        return values;
    }

	private void saveNotify() {
		Log.e(TAG, "saveNotify() begin...");
        ContentValues values = createContentValues();
        Uri uri = null;
        Notify fakeNotify = Notify.getFakeNotify();
        long notifyId = fakeNotify.getNotifyId();
        if(notifyId >= 0) {//Update exist Notify
        	Uri notifyIdUri = ContentUris.withAppendedId(NotifyProvider.CONTENT_URI, notifyId);
        	getContentResolver().update(notifyIdUri, values, null, null);
        } else {//New Notify
        	uri = getContentResolver().insert(NotifyProvider.CONTENT_URI, values);
        }
        

		//After save the notify in database, clear the fake notify.
		Notify.clearFakeNotify();	
		Log.e(TAG, "saveNotify() end... uri = " + uri);
	}
	

}
