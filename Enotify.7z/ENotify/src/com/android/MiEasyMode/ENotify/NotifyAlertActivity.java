package com.android.MiEasyMode.ENotify;

import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.Engine;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.speech.tts.TextToSpeech.OnUtteranceCompletedListener;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.android.MiEasyMode.ENotify.R;

public class NotifyAlertActivity extends Activity {
	private static final String TAG = "NotifyAlertActivity";
	
    // Volume suggested by media team for in-call alarms.
    private static final float IN_CALL_VOLUME = 0.125f;
    
    private static final long[] sVibratePattern = new long[] { 500, 500 };
    
    //Play alarm up to 5 minutes before silencing
    public static final int ALARM_TIMEOUT = 1 * 60 * 1000;

	private boolean mPlaying = false;
	private MediaPlayer mMediaPlayer;
	private Vibrator mVibrator;
	private TelephonyManager mTelephonyManager;
	
	private View mCloseAlertBtn;
	private TextView mNotifyContent;
	private Notify mNotify;
	
	// Internal messages
    private static final int KILLER = 1000;
    private static final int RELEASE_WAK_LOCK = 1001;
    private Handler mHandler = new Handler() {
        @Override
		public void handleMessage(Message msg) {
            switch (msg.what) {
                case KILLER:
	                Log.e(TAG, "*********** Alarm killer triggered ***********");
	                stopAlarm();
	                break;
                case RELEASE_WAK_LOCK:
	                Log.e(TAG, "*********** RELEASE_WAK_LOCK ***********");
	                NotifyAlertWakeLock.releaseCpuLock();
	                break;
            }
        }
    };
	
    private PhoneStateListener mPhoneStateListener = new PhoneStateListener() {
        @Override
        public void onCallStateChanged(int state, String ignored) {
            // The user might already be in a call when the alarm fires. When
            // we register onCallStateChanged, we get the initial in-call state
            // which kills the alarm. Check against the initial call state so
            // we don't kill the alarm during a call.
        	
            //if (state != TelephonyManager.CALL_STATE_IDLE
            //        && state != mInitialCallState) {

            //}
        }
    };
    
    private View.OnClickListener mBtnListener = new View.OnClickListener() {
        @Override
		public void onClick(View v) {
            switch(v.getId()) {
                case R.id.close_alert_btn:
                    Log.e(TAG, "mBtnListener: close_alert_btn");
                    finish();
                    break;
            }
        }
    };
    
    private static final int SPEAK_NOTIFY_CONTENT = 100;
    private static final int SPEAK_NOTIFY_TIME_OUT = 101;
    private static final int SPEAK_NOTIFY_STOP = 102;
    private static final int PLAY_AGAIN_DELAY = 2 * 1000;
	private static final String SPEAK_NOTIFY_ID = "speak_notify_id";
	private boolean mIsSpeakEnable = false;
    TextToSpeech mTts = null;
    Handler mSpeechHandler =  new Handler() {
        @Override
		public void handleMessage(Message msg) {
            switch (msg.what) {
                case SPEAK_NOTIFY_CONTENT:
	                if(mNotify != null) {
	                	int success= mTts.setSpeechRate(0.8F);
	                	Log.e(TAG, "setSpeechRate() success = " + success);
	                	Log.e(TAG, "Speak Notify Content: " + mNotify.getMessage());
	                	HashMap<String,String> idHash = new HashMap();
	        	        idHash.put(Engine.KEY_PARAM_STREAM, "" + AudioManager.STREAM_ALARM);
	                	idHash.put(Engine.KEY_PARAM_UTTERANCE_ID, SPEAK_NOTIFY_ID);
	                	idHash.put(Engine.KEY_PARAM_VOLUME, "1.0f");
	                	mTts.speak(mNotify.getMessage(), TextToSpeech.QUEUE_ADD, idHash);
	                }
	                break;
                case SPEAK_NOTIFY_STOP:
                	Log.e(TAG, "SPEAK_NOTIFY_STOP");
                	stopTextToSpeech();
                	break;
                case SPEAK_NOTIFY_TIME_OUT:
                	mIsSpeakEnable = false;
                	Log.e(TAG, "SPEAK_NOTIFY_TIME_OUT mIsSpeakEnable = " + mIsSpeakEnable);
                	break;
            }
        }
    };
    OnInitListener mOnInitCompletedListener = new OnInitListener() {
        @Override
		public void onInit(int status) {
        	Log.e(TAG, "onInit() status = " + status);
            if(TextToSpeech.SUCCESS == status && mSpeechHandler != null) {
            	mIsSpeakEnable = true;
            	//Post this message delay 1s to avoid speech is killed when activity start from screen off
            	mSpeechHandler.sendEmptyMessageDelayed(SPEAK_NOTIFY_CONTENT, 1000);
            } else if(TextToSpeech.ERROR == status) {
            	startAlarmPlay();
            }
        }
    };
    
    OnUtteranceCompletedListener mOnUtteranceCompletedListener = new OnUtteranceCompletedListener() {
        @Override
		public void onUtteranceCompleted(String utteranceId) {
        	Log.e(TAG, "onUtteranceCompleted() utteranceId = " + utteranceId + "   mIsSpeakEnable = "+ mIsSpeakEnable);
            if(mSpeechHandler != null && mIsSpeakEnable) {
            	mSpeechHandler.sendEmptyMessageDelayed(SPEAK_NOTIFY_CONTENT, PLAY_AGAIN_DELAY);
            }
            
        }
    };
    
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        final Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        win.addFlags(/*WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | */WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);
        
        setContentView(R.layout.notify_activity_notify_alert);
        
        mVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // Listen for incoming calls to kill the alarm.
        mTelephonyManager =
                (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        mTelephonyManager.listen(
                mPhoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        
        mNotifyContent = (TextView) findViewById(R.id.notify_content);
        mCloseAlertBtn = findViewById(R.id.close_alert_btn);
        mCloseAlertBtn.setOnClickListener(mBtnListener);
        
        initNotifyAlert(getIntent());
        
        //mTts = new TextToSpeech(this, mOnInitCompletedListener);
        //mTts.setEngineByPackageName("com.iflytek.tts");
        //int ret = mTts.setOnUtteranceCompletedListener(mOnUtteranceCompletedListener);
        

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        Log.e(TAG, "OnNewIntent()");

        initNotifyAlert(intent);
    }
	
    private void initNotifyAlert(Intent intent) {
    	//Reset FULL_WAKE_LOCK to 1 minutes
    	NotifyAlertWakeLock.releaseCpuLock();
    	NotifyAlertWakeLock.acquireCpuWakeLock(this);
    	mHandler.removeMessages(RELEASE_WAK_LOCK);
    	mHandler.sendEmptyMessageDelayed(RELEASE_WAK_LOCK, ALARM_TIMEOUT);
    	
        long alarmId = intent.getLongExtra(NotifyUtils.NOTIFY_ID, -1);
        Cursor cursor = getContentResolver().query(NotifyProvider.CONTENT_URI, 
        		NotifyList.NOTIFY_PROJECTION, "_id=" + alarmId, null, null);
        
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                	mNotify = Notify.from(this, cursor);
                	Log.e(TAG, "alarmId = " + alarmId+ "mNotify = " + mNotify);
                }
            } finally {
                cursor.close();
            }
        }
        
        if(mNotify == null || mNotify.getNotifyId() < 0) {
            finish();
            return;
        }
        
        mNotifyContent.setText(mNotify.getMessage());
        
        if(!TextUtils.isEmpty(mNotify.getMessage())) {
        	initTextToSpeech();
        } else {
        	startAlarmPlay();
        }
    }
    
    private void initTextToSpeech() {
    	mSpeechHandler.removeMessages(SPEAK_NOTIFY_TIME_OUT);
    	mSpeechHandler.sendEmptyMessageDelayed(SPEAK_NOTIFY_TIME_OUT, ALARM_TIMEOUT);
    	
    	if(mTts != null) {
    		mIsSpeakEnable = true;
        	//Post this message delay 1s to avoid speech is killed when activity start from screen off
        	mSpeechHandler.sendEmptyMessageDelayed(SPEAK_NOTIFY_CONTENT, 1000);
    		return;
    	}
    	
        mTts = new TextToSpeech(this, mOnInitCompletedListener, "com.iflytek.tts");
        @SuppressWarnings("deprecation")
		int ret = mTts.setOnUtteranceCompletedListener(mOnUtteranceCompletedListener);
    }
    
    //Stop TextToSpeech
    private void stopTextToSpeech() {
    	if(mTts == null) {
    		return;
    	}
    	
        if (mTts.isSpeaking()) {
        	mTts.stop();
        }
        mSpeechHandler.removeMessages(SPEAK_NOTIFY_CONTENT);
        mIsSpeakEnable = false;
    }
    
    //Destroy TextToSpeech object
    private void destroyTextToSpeech() {
    	if(mTts == null) {
    		return;
    	}
    	
    	stopTextToSpeech();
    	
        mTts.shutdown();
        mTts = null;
    }
    
    protected void onStart() {
    	super.onStart();
    	Log.e(TAG, "onStart()");
    	
    	mSpeechHandler.removeMessages(SPEAK_NOTIFY_STOP);
    }
    
    protected void onResume() {
    	super.onResume();
    	Log.e(TAG, "onResume()");
    }
    
    protected void onPause() {
    	super.onPause();
    	Log.e(TAG, "onPause()");
    }
    
    @Override
    protected void onStop() {
        super.onStop();

        //TODO
        //Delay 1 second to avoid stopping notify when activity start from screen off onStop() called
        mSpeechHandler.sendEmptyMessageDelayed(SPEAK_NOTIFY_STOP, 1000);
        
        Log.e(TAG, "onStop() sendMessage KILLER");
		//mHandler.sendEmptyMessage(KILLER);
        stopAlarm();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy()");
        
        destroyTextToSpeech();
        
        stopAlarm();
        
        // Stop listening for incoming calls.
        mTelephonyManager.listen(mPhoneStateListener, 0);
        
        NotifyAlertWakeLock.releaseCpuLock();
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.e(TAG, "onKeyDown(keycode " + keyCode + ")...");

        switch (keyCode) {
        	case KeyEvent.KEYCODE_BACK:
        		return true;
        }
        
        return super.onKeyDown(keyCode, event);
    }        
    
	//Init alarm ringtone in a thread
	private void startAlarmPlay() {
		new Thread(new Runnable() {
            @Override
			public void run() {
            	//TODO
                //Delay 2 second to avoid stopping notify when activity start from screen off onStop() called
            	SystemClock.sleep(2000);
            	play();
            }
        }).start();
		
		mHandler.removeMessages(KILLER);
		mHandler.sendEmptyMessageDelayed(KILLER,
                ALARM_TIMEOUT);
	}
	
	private void play() {
        // stop() checks to see if we are already playing.
		stopAlarm();
        
        // RingtoneManager.
        mMediaPlayer = new MediaPlayer();
        mMediaPlayer.setOnErrorListener(new OnErrorListener() {
            @Override
			public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.e(TAG, "Error occurred while playing audio.");
                mp.stop();
                mp.release();
                mMediaPlayer = null;
                return true;
            }
        });
        
        try {
            // Check if we are in a call. If we are, use the in-call alarm
            // resource at a low volume to not disrupt the call.
            if (mTelephonyManager.getCallState()
                    != TelephonyManager.CALL_STATE_IDLE) {
            	Log.e(TAG, "Using the in-call alarm");
                mMediaPlayer.setVolume(IN_CALL_VOLUME, IN_CALL_VOLUME);
                setDataSourceFromResource(getResources(), mMediaPlayer,
                        R.raw.notify_in_call_alarm);
            } else {
                //Get system alarm ringtone
                Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                mMediaPlayer.setDataSource(this, alert);
            }
            startAlarm(mMediaPlayer);
        } catch (Exception ex) {
            Log.e(TAG, "Using the fallback ringtone", ex);
            // The alert may be on the sd card which could be busy right
            // now. Use the fallback ringtone.
            try {
                // Must reset the media player to clear the error state.
                mMediaPlayer.reset();
                setDataSourceFromResource(getResources(), mMediaPlayer,
                        R.raw.notify_fallbackring);
                startAlarm(mMediaPlayer);
            } catch (Exception ex2) {
                // At this point we just don't play anything.
                Log.e(TAG, "Failed to play fallback ringtone", ex2);
            }
        }
        
        /* Start the vibrator after everything is ok with the media player */
        mVibrator.vibrate(sVibratePattern, 0);

        mPlaying = true;
    }

    /**
     * Stops alarm audio
     * repeating
     */
	private void stopAlarm() {
        Log.e(TAG, "AlarmKlaxon.stop() mPlaying = " + mPlaying);
        if (mPlaying) {
            mPlaying = false;

            // Stop audio playing
            if (mMediaPlayer != null) {
                mMediaPlayer.stop();
                mMediaPlayer.release();
                mMediaPlayer = null;
            }

            // Stop vibrator
            mVibrator.cancel();
        }
	}
	
    // Do the common stuff when starting the alarm.
    private void startAlarm(MediaPlayer player)
            throws java.io.IOException, IllegalArgumentException,
                   IllegalStateException {
        final AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        // do not play alarms if stream volume is 0
        // (typically because ringer mode is silent).
        if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
            player.setAudioStreamType(AudioManager.STREAM_ALARM);
            player.setLooping(true);
            player.prepare();
            player.start();
        }
    }
	
    private void setDataSourceFromResource(Resources resources,
            MediaPlayer player, int res) throws java.io.IOException {
        AssetFileDescriptor afd = resources.openRawResourceFd(res);
        Log.e(TAG, "setDataSourceFromResource() afd = " + afd);
        if (afd != null) {
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(),
                    afd.getLength());
            afd.close();
        }
    }
	
}
