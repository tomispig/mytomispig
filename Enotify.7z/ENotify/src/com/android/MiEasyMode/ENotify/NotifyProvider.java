package com.android.MiEasyMode.ENotify;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import com.android.MiEasyMode.ENotify.R;

public class NotifyProvider extends ContentProvider {
	private static final String TAG = "NotifyProvider";
    private NotifyDatabaseHelper mOpenHelper;

    private static final int NOTIFY = 1;
    private static final int NOTIFY_ID = 2;
    private static final UriMatcher sURLMatcher = new UriMatcher(
            UriMatcher.NO_MATCH);
    public static final Uri CONTENT_URI =
            Uri.parse("content://notify_provider/notify");

    static {
        sURLMatcher.addURI("notify_provider", "notify", NOTIFY);
        sURLMatcher.addURI("notify_provider", "notify/#", NOTIFY_ID);
    }

    public NotifyProvider() {
    }

    @Override
    public boolean onCreate() {
        mOpenHelper = new NotifyDatabaseHelper(getContext());
        return true;
    }

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(Uri uri, String where, String[] whereArgs) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int count;
        long rowId = 0;
        switch (sURLMatcher.match(uri)) {
            case NOTIFY:
                break;
            case NOTIFY_ID:
                String segment = uri.getPathSegments().get(1);
                rowId = Long.parseLong(segment);
                if (TextUtils.isEmpty(where)) {
                    where = "_id=" + segment;
                } else {
                    where = "_id=" + segment + " AND (" + where + ")";
                }
                break;
            default:
                throw new IllegalArgumentException("Cannot delete from URL: " + uri);
        }
        Log.e(TAG, "delete notify uri = " + uri);
        count = db.delete("notify", where, whereArgs);
        notifyChange(uri);
        return count;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        db.beginTransaction();
        long rowId = -1;
        Cursor cursor = null;
        try {
            rowId = db.insert("notify", null, values);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            if(cursor != null) {
                cursor.close();
            }
        }
        if (rowId < 0) {
            throw new SQLException("Failed to insert row");
        }
        Log.e(TAG, "Added notify rowId = " + rowId);

        Uri retUri =  ContentUris.withAppendedId(CONTENT_URI, rowId);
        notifyChange(retUri);
        return retUri;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        // Generate the body of the query
        int match = sURLMatcher.match(uri);
        switch (match) {
            case NOTIFY:
                qb.setTables("notify");
                break;
            case NOTIFY_ID:
                qb.setTables("notify");
                qb.appendWhere("_id=");
                qb.appendWhere(uri.getPathSegments().get(1));
                break;
            default:
                throw new IllegalArgumentException("Unknown URL " + uri);
        }

        SQLiteDatabase db = mOpenHelper.getReadableDatabase();
        Cursor ret = qb.query(db, projection, selection, selectionArgs,
                              null, null, sortOrder);

        if (ret == null) {
            Log.e(TAG, "Notify.query: failed");
        } else {
            ret.setNotificationUri(getContext().getContentResolver(), uri);
        }

        return ret;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
        int count;
        long rowId = 0;
        int match = sURLMatcher.match(uri);
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        switch (match) {
            case NOTIFY_ID: {
                String segment = uri.getPathSegments().get(1);
                rowId = Long.parseLong(segment);
                count = db.update("notify", values, "_id=" + rowId, null);
                break;
            }
            default: {
                throw new UnsupportedOperationException(
                        "Cannot update URL: " + uri);
            }
        }
        Log.e(TAG, "*** notifyChange() rowId: " + rowId + " url " + uri);
        notifyChange(uri);
        return count;
	}

    private void notifyChange(Uri uri) {
        ContentResolver cr = getContext().getContentResolver();
        cr.notifyChange(CONTENT_URI, null);
    }
	
}
