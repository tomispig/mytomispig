package com.android.MiEasyMode.ENotify;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class NotifyDatabaseHelper extends SQLiteOpenHelper {
	private static final String TAG = "NotifyDatabaseHelper";
	private static final String DATABASE_NAME = "notify.db";
    private static final int DATABASE_VERSION = 1;

    public NotifyDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
	@Override
	public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE notify (" +
                "_id INTEGER PRIMARY KEY," +
                "year INTEGER, " +
                "month INTEGER, " +
                "day INTEGER, " +
                "hour INTEGER, " +
                "minute INTEGER, " +
                "enabled INTEGER DEFAULT 1, " +
                "message TEXT, " +
                "alarmtime INTEGER, " +
                "repeatway INTEGER);");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int currentVersion) {
        Log.e(TAG, "Upgrading alarms database from version " +
                oldVersion + " to " + currentVersion +
                ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS notify");
        onCreate(db);
	}

}
