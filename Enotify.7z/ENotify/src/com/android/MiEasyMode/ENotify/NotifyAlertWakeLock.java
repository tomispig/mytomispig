package com.android.MiEasyMode.ENotify;

import android.content.Context;
import android.os.PowerManager;

import com.android.MiEasyMode.ENotify.R;

public class NotifyAlertWakeLock {
    private static final String WAKE_LOCK_TAG = "com.android.MiEasyMode.ENotify";
	private static PowerManager.WakeLock sCpuWakeLock;

    static void acquireCpuWakeLock(Context context) {
        if (sCpuWakeLock != null) {
            return;
        }

        PowerManager pm =
                (PowerManager) context.getSystemService(Context.POWER_SERVICE);

        sCpuWakeLock = pm.newWakeLock(
                PowerManager.FULL_WAKE_LOCK |
                PowerManager.ACQUIRE_CAUSES_WAKEUP |
                PowerManager.ON_AFTER_RELEASE, WAKE_LOCK_TAG);
        sCpuWakeLock.acquire();
    }

    static void releaseCpuLock() {
        if (sCpuWakeLock != null) {
            sCpuWakeLock.release();
            sCpuWakeLock = null;
        }
    }
}
