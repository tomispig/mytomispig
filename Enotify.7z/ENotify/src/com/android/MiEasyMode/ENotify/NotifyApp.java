package com.android.MiEasyMode.ENotify;

import android.app.Application;

import com.android.MiEasyMode.ENotify.R;

public class NotifyApp extends Application {
	
	private Notify mFakeNotify = null;

    @Override
    public void onCreate() {
    	super.onCreate();
    }
    
    public Notify getFakeNotify() {
    	if(mFakeNotify == null) {
    		mFakeNotify = new Notify();
    	}
    	return mFakeNotify;
    }
    
    public void resetFakeNotify() {
    	mFakeNotify = null;
    }
}
