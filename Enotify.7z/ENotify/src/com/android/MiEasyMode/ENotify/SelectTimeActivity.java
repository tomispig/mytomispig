package com.android.MiEasyMode.ENotify;

import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.MiEasyMode.ENotify.R;

public class SelectTimeActivity extends Activity {
    private static final String TAG = "SelectTimeActivity";
    private static final boolean DBG = true;

	public static final int COMPLETE_CREATE_NOTIFY = 1000;
	private static final int TIME_PICKER_TEXT_SIZE = 40;
	
	private TimePicker mTimePicker;
	private View mCancleBtn;
	private View mNextBtn;
	
	private DisplayMetrics mMetrics = new DisplayMetrics();
	
    private View.OnClickListener mBtnListener = new View.OnClickListener() {
        @Override
		public void onClick(View v) {
            switch(v.getId()) {
                case R.id.cancle_btn:
                    Log.e(TAG, "mBtnListener: cancle_btn");
                    SelectTimeActivity.this.finish();
                    break;
                case R.id.next_btn:
                    Log.e(TAG, "mBtnListener: next_btn");
                    startEditMsgActivity();
                    break;
            }
        }
    };
    
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notify_activity_select_time);
        
        mCancleBtn = this.findViewById(R.id.cancle_btn);
        mNextBtn = this.findViewById(R.id.next_btn);
        mCancleBtn.setOnClickListener(mBtnListener);
        mNextBtn.setOnClickListener(mBtnListener);
        
        //Save system metrics in mMetrics
        getWindowManager().getDefaultDisplay().getMetrics(mMetrics);
        
        initTimePicker();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	Log.e(TAG, "onActivityResult: resultCode = " + resultCode);
    	if(resultCode == COMPLETE_CREATE_NOTIFY) {
    		finish();
    	}
    }
	
   
	public static void recursionChangeViewTextSize(ViewGroup viewGroup, DisplayMetrics metrics) {
		int count = viewGroup.getChildCount();
		for(int i = 0; i < count; i++) {
			View v = viewGroup.getChildAt(i);
			if(v instanceof ViewGroup) {
				if(DBG) Log.e(TAG, "begin---- " + v.getClass());
				if("android.widget.NumberPicker".equals(v.getClass().getName())) {
				try {
						Class c = Class.forName("android.widget.NumberPicker");
						
						
						Paint pt = (Paint)NotifyUtils.getField(c, v, "mSelectorWheelPaint");
						pt.setTextSize(NotifyUtils.sp2Px(TIME_PICKER_TEXT_SIZE, metrics.scaledDensity));
						
						NotifyUtils.setField(c, v, "mTextSize", 
								NotifyUtils.sp2Px(TIME_PICKER_TEXT_SIZE, metrics.scaledDensity));
						
						NotifyUtils.setField(c, v, "mTextSize", 
								NotifyUtils.sp2Px(TIME_PICKER_TEXT_SIZE, metrics.scaledDensity));
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						Log.e(TAG, "ClassNotFoundException e = " + e);
						e.printStackTrace();
					}
				}
				
				recursionChangeViewTextSize((ViewGroup) v, metrics);
				if(DBG) Log.e(TAG, "end---- " + v.getClass());
			} else if (v instanceof TextView) {
				if(DBG) Log.e(TAG, "TextView v = " + v);
				((TextView) v).setTextSize(TypedValue.COMPLEX_UNIT_PX, 
						NotifyUtils.sp2Px(TIME_PICKER_TEXT_SIZE, metrics.scaledDensity));
			} else {
				if(DBG) Log.e(TAG, "getChildAt(" + i + ") = " + v);
			}
		}
	}
    
	private void initTimePicker() {
        mTimePicker = (TimePicker) findViewById(R.id.notify_time_picker);
        
        recursionChangeViewTextSize(mTimePicker, mMetrics);
        
        mTimePicker.setIs24HourView(true);
        
        final Calendar calendar = Calendar.getInstance();
        
        Notify fakeNotify = Notify.getFakeNotify();
        int hour = 0;
        int minute = 0;
        if(fakeNotify.getNotifyId() >= 0) {
        	hour = fakeNotify.getHour();
        	minute = fakeNotify.getMinute();
        } else {
        	hour = calendar.get(Calendar.HOUR_OF_DAY);
        	minute = calendar.get(Calendar.MINUTE);
        }
        Log.e(TAG, "initTimePicker() hour = " + hour + "   minute = " + minute);
        mTimePicker.setCurrentHour(hour);
        mTimePicker.setCurrentMinute(minute);
	}
	
	private void startEditMsgActivity() {
		//Before goto another activity, save the selected time in a fake object
		mTimePicker.clearFocus();//Ensure numberpicker edit text to be updateed 
		int hour = mTimePicker.getCurrentHour();
		int minute = mTimePicker.getCurrentMinute();
		Notify fakeNotify = Notify.getFakeNotify();
		fakeNotify.setHour(hour);
		fakeNotify.setMinute(minute);
		
        Intent intent = new Intent(this, EditNotifyActivity.class);
		this.startActivityForResult(intent, 0);
	}
}
