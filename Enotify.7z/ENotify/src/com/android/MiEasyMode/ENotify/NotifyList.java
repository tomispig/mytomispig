package com.android.MiEasyMode.ENotify;

import java.util.HashMap;

import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.Engine;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.speech.tts.TextToSpeech.OnUtteranceCompletedListener;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.android.MiEasyMode.ENotify.R;

public class NotifyList extends ListActivity {
    private static final String TAG = "NotifyList";

    private static final String ORDER_BY = "enabled desc, hour asc, minute asc";
    
	private static final int NOTIFY_LIST_QUERY_TOKEN = 100;
	private static final int NOTIFY_LIST_DELETE_TOKEN = 101;
    public static final String[] NOTIFY_PROJECTION = new String[] {
        Notify.COLUMN_ID_NAME,
        Notify.COLUMN_HOUR_NAME,
        Notify.COLUMN_MINUTE_NAME,
        Notify.COLUMN_ENABLED_NAME,
        Notify.COLUMN_MESSAGE_NAME,
        Notify.COLUMN_ALARM_TIME_NAME};

    //keep the activity dialog reference
	private static AlertDialog sDialog = null;
	
	private String mEmptyTips = "";
	
	private NotifyListAdapter mListAdapter;
	private View mNewNotifyBtn;
	private ToggleButton mSpeechSwitchBtn;
	private TextView mEmptyView;
	
	private boolean hasSpeechEmptyTips = false;
	
	private AsyncQueryHandler mQueryHandler;
	
    private static final int SPEAK_NOTIFY = 100;
    private static final int CLOSE_SPEECH_ENGIN = 101;
    private final String emptyNotifyUtteranceId = "empty_notify";
	private TextToSpeech mTts = null;
    Handler mSpeechHandler = new Handler() {
        @Override
		public void handleMessage(Message msg) {
            switch (msg.what) {
                case SPEAK_NOTIFY:
                    Log.e(TAG, "mSpeechHandler SPEAK_NOTIFY");
                    startSpeechNotify(mEmptyTips);
	                break;
                case CLOSE_SPEECH_ENGIN:
                	Log.e(TAG, "mSpeechHandler CLOSE_SPEECH_ENGIN");
	                shutdownTextToSpeech();
	                break;
            }
        }
    };
	
	private void startSpeechNotify(String notifyStr) {
		if(mTts != null) {
	        HashMap<String,String> idHash = new HashMap();
	        
	        idHash.put(Engine.KEY_PARAM_STREAM, "" + AudioManager.STREAM_ALARM);
		    idHash.put(Engine.KEY_PARAM_UTTERANCE_ID, emptyNotifyUtteranceId);
		    idHash.put(Engine.KEY_PARAM_VOLUME, "1.0f");
		    mTts.speak(notifyStr, TextToSpeech.QUEUE_ADD, idHash);
		    mSpeechSwitchBtn.setChecked(true);
		}
	}
    
	private void stopSpeechNotify() {
		if(mTts != null) {
			mTts.stop();
			//Speech done, unchecked the button
			mSpeechSwitchBtn.setChecked(false);
		}
	}
	
    private View.OnClickListener mBtnListener = new View.OnClickListener() {
        @Override
		public void onClick(View v) {
            switch(v.getId()) {
                case R.id.new_notify_btn:
                    Log.e(TAG, "mBtnListener: new_message_btn");
                    createNewNotify(v.getContext());
                    break;
                case R.id.speech_switch_btn:
                    if(mSpeechSwitchBtn.isChecked()) {
                    	Log.e(TAG, "mBtnListener: speech_switch_btn Checked");
                    	mSpeechHandler.removeMessages(SPEAK_NOTIFY);
                    	mSpeechHandler.sendEmptyMessage(SPEAK_NOTIFY);
                    } else {
                    	Log.e(TAG, "mBtnListener: speech_switch_btn not Checked");
                    	stopSpeechNotify();
                    }
                    break;
            }
        }
    };
   
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        //getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.notify_activity_notify_list_title);
        setContentView(R.layout.notify_activity_notify_list);
        
        mQueryHandler = new NotifyListQueryHandler(getContentResolver());
        
        getListView().setEmptyView(findViewById(R.id.empty));
        initListAdapter();

        mNewNotifyBtn = findViewById(R.id.new_notify_btn);
        mNewNotifyBtn.setOnClickListener(mBtnListener);
        
        mSpeechSwitchBtn = (ToggleButton) findViewById(R.id.speech_switch_btn);
        mSpeechSwitchBtn.setOnClickListener(mBtnListener);
        
        TextView emptyView = (TextView) findViewById(R.id.empty);
        mEmptyTips = emptyView.getText().toString();
        
        long time = System.currentTimeMillis();
        Log.e(TAG, "time = " + time);
    }
	
    /*private void setActivitTitle() {
    	TextView title = (TextView) findViewById(R.id.notify_activity_title);
    	title.setText(R.string.title_activity_notify_list);
    }*/
	
    private void initListAdapter() {
        mListAdapter = new NotifyListAdapter(this, null);

        setListAdapter(mListAdapter);
        //getListView().setRecyclerListener(mListAdapter);
    }
    
    @Override
    protected void onStart() {
        super.onStart();
        
        initListAdapter();
        
        startAsyncQuery();
    }
    
    @Override
    protected void onStop() {
        super.onStop();

        mSpeechHandler.sendEmptyMessage(CLOSE_SPEECH_ENGIN);//stopSpeechNotify();
        
        mListAdapter.changeCursor(null);
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy()");
        mSpeechHandler.sendEmptyMessage(CLOSE_SPEECH_ENGIN);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
    	TextView textView = (TextView) v.findViewById(R.id.subject);
    	updateFakeNotify(position);
    	showDetailDialog(new NotifyDetailListener(id, mQueryHandler), textView.getText().toString(), this);
    }
    
    private void updateFakeNotify(int position) {
    	Cursor cursor = (Cursor) mListAdapter.getItem(position);
    	Notify tempNotify = Notify.from(this, cursor);
    	Notify fakeNotify = Notify.getFakeNotify();
    	
    	fakeNotify.copyFrom(tempNotify);
    	Log.e(TAG, "updateFakeNotify() fakeNotify = " + fakeNotify);
    }
    
    public static void showDetailDialog(NotifyDetailListener listener, String subjectText, 
    		                            Context context) {
        View contents = View.inflate(context, R.layout.notify_notify_detail_dialog_view, null);
        TextView msg = (TextView)contents.findViewById(R.id.notify_detail);
        msg.setText(subjectText);
        View editNotify = contents.findViewById(R.id.notify_detail_edit_btn);
        View deleteNotify = contents.findViewById(R.id.delete_notify_btn);
        View notifyDetailCancle = contents.findViewById(R.id.notify_detail_cancle_btn);
        editNotify.setOnClickListener(listener);
        deleteNotify.setOnClickListener(listener);
        notifyDetailCancle.setOnClickListener(listener);
        
        AlertDialog dialog = new AlertDialog.Builder(context)
        .setCancelable(true)
        .setView(contents)
        .create();
        
        sDialog  = dialog;
        dialog.show();
	}

	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.notify_activity_notify_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menu_clear_all:
            	confirmDeleteNotifyDialog(new DeleteNotifyListener(-1, mQueryHandler), 
            			                  true, this);
                break;
            default:
                return true;
        }
        return false;
    }

    /**
     * Build and show the proper delete thread dialog. The UI is slightly different
     * depending on whether there are locked messages in the thread(s) and whether we're
     * deleting a single thread or all threads.
     * @param listener gets called when the delete button is pressed
     * @param deleteAll whether to show a single thread or all threads UI
     * @param hasLockedMessages whether the thread(s) contain locked messages
     * @param context used to load the various UI elements
     */
    public static void confirmDeleteNotifyDialog(final DeleteNotifyListener listener,
            boolean deleteAll,
            Context context) {
        View contents = View.inflate(context, R.layout.notify_delete_notify_dialog_view, null);
        TextView msg = (TextView)contents.findViewById(R.id.delete_notify_tips);
        msg.setText(deleteAll
                ? R.string.confirm_delete_all_notifies
                        : R.string.confirm_delete_notify);
        View deleteAllOk = contents.findViewById(R.id.delete_all_ok_btn);
        View deleteAllCancle = contents.findViewById(R.id.delete_all_cancle_btn);
        deleteAllOk.setOnClickListener(listener);
        deleteAllCancle.setOnClickListener(listener);
        
        AlertDialog dialog = new AlertDialog.Builder(context)
        .setCancelable(true)
        .setView(contents)
        .create();
        
        sDialog  = dialog;
        dialog.show();
    }
    
    private void startAsyncQuery() {
        mQueryHandler.cancelOperation(NOTIFY_LIST_QUERY_TOKEN);
        mQueryHandler.startQuery(NOTIFY_LIST_QUERY_TOKEN, null, NotifyProvider.CONTENT_URI,
        		NOTIFY_PROJECTION, null, null, ORDER_BY);
    }
    
	private static void startSelectTimeActivity(Context context) {
        Intent intent = new Intent(context, SelectTimeActivity.class);
        context.startActivity(intent);
	}
    
	private static void createNewNotify(Context context) {
		//Before create a new notify, reset fake notify object
		Notify.clearFakeNotify();
		
		startSelectTimeActivity(context);
	}

	private static void editNotify(Context context) {
		startSelectTimeActivity(context);
	}
	
	OnInitListener mInitListener = new OnInitListener() {
        @Override
		public void onInit(int status) {
            Log.e(TAG, "onInit() hasSpeechEmptyTips = " + hasSpeechEmptyTips);
            if(!hasSpeechEmptyTips) {
            	mSpeechHandler.sendEmptyMessageDelayed(SPEAK_NOTIFY, 1000);
            	hasSpeechEmptyTips = true;
            }
        }
    };
	
    OnUtteranceCompletedListener mOnUtteranceCompletedListener = new OnUtteranceCompletedListener() {
        public void onUtteranceCompleted(String utteranceId) {
        	Log.e(TAG, "mOnUtteranceCompletedListener() speech done utteranceId = " + utteranceId);
        	mSpeechSwitchBtn.post(new Runnable() {
				@Override
				public void run() {
					stopSpeechNotify();
				}
        	});
        }
    };
    
    private void initSpeechEngin() {
    	if(mTts == null) {
	        mTts = new TextToSpeech(this, mInitListener, "com.iflytek.tts");
	        
	        @SuppressWarnings("deprecation")
			int ret = mTts.setOnUtteranceCompletedListener(mOnUtteranceCompletedListener);
	        Log.e(TAG, "ret = " + ret);
    	}
	}
    
    private void shutdownTextToSpeech() {
    	if(mTts == null) {
            Log.e(TAG, "shutdownTextToSpeech() mTts is already null");
    		return;
    	}

    	stopSpeechNotify();
        
        mTts.shutdown();
        mTts = null;
        Log.e(TAG, "shutdownTextToSpeech() done");
    }
    
    private final class NotifyListQueryHandler extends AsyncQueryHandler {
        public NotifyListQueryHandler(ContentResolver contentResolver) {
            super(contentResolver);
        }
        
        @Override
		protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
            switch (token) {
            	case NOTIFY_LIST_QUERY_TOKEN:
            		mListAdapter.changeCursor(cursor);
            		
            		boolean hasNotify = mListAdapter.getCount() > 0;
            		if(!hasNotify) {
            			initSpeechEngin();
            		}
            		mSpeechSwitchBtn.setVisibility(hasNotify ? View.INVISIBLE : View.VISIBLE);
            	break;
            }
        	
        }

		@Override
		protected void onDeleteComplete(int token, Object cookie, int result) {
        	startAsyncQuery();
        }
    }
    
    public static class NotifyDetailListener implements OnClickListener {
        private final long mNotifyId;
        private final AsyncQueryHandler mQueryHandler;
    	
        public NotifyDetailListener(long notifyId, AsyncQueryHandler handler) {
        	mNotifyId = notifyId;
        	mQueryHandler = handler;
        }
        
		@Override
		public void onClick(View v) {
            switch(v.getId()) {
            case R.id.notify_detail_edit_btn:
            	closeDialog();
            	editNotify(v.getContext());
            	break;
            case R.id.delete_notify_btn:
                Log.e(TAG, "mBtnListener: new_message_btn");
                closeDialog();
            	confirmDeleteNotifyDialog(new DeleteNotifyListener(mNotifyId, mQueryHandler), 
		                  false, v.getContext());
                
                break;
            case R.id.notify_detail_cancle_btn:
            	closeDialog();
            	break;
            }
		}
    	
    }
    
    public static class DeleteNotifyListener implements OnClickListener {
        private final long mNotifyId;
        private final AsyncQueryHandler mHandler;
        //private final Context mContext;

        public DeleteNotifyListener(long notifyId, AsyncQueryHandler handler) {
        	mNotifyId = notifyId;
            mHandler = handler;
            //mContext = context;
        }

        public void onClick(final int whichButton) {

        }

		@Override
		public void onClick(View v) {
            switch(v.getId()) {
            case R.id.delete_all_ok_btn:
                Log.e(TAG, "mBtnListener: new_message_btn");
                if (mNotifyId == -1) {
                	mHandler.startDelete(NOTIFY_LIST_DELETE_TOKEN, null, 
                			NotifyProvider.CONTENT_URI, null, null);
                } else {
                	Uri uri = ContentUris.withAppendedId(NotifyProvider.CONTENT_URI, mNotifyId);
                	mHandler.startDelete(NOTIFY_LIST_DELETE_TOKEN, null, 
                			             uri, null, null);
                }
                closeDialog();
                break;
            case R.id.delete_all_cancle_btn:
            	closeDialog();
            }

		}
    }
    
    private static void closeDialog() {
    	if(sDialog != null) {
        	sDialog.dismiss();
        	sDialog = null;
    	}

    }
}
