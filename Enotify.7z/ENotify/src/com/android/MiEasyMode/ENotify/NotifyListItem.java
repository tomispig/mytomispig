package com.android.MiEasyMode.ENotify;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.MiEasyMode.ENotify.R;

public class NotifyListItem extends LinearLayout {
    private static final String TAG = "NotifyListItem";

    private TextView mSubjectView;
	private CheckBox mEnabledView;
	
	private Notify mNotify;
    
	OnCheckedChangeListener mCheckedChangeListener = new OnCheckedChangeListener() {
        /**
         * Called when the checked state of a compound button has changed.
         *
         * @param buttonView The compound button view whose state has changed.
         * @param isChecked  The new checked state of buttonView.
         */
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            ContentValues values = new ContentValues(1);
            values.put(Notify.COLUMN_ENABLED_NAME, isChecked ? 1 : 0);
        	Uri notifyIdUri = ContentUris.withAppendedId(NotifyProvider.CONTENT_URI, mNotify.getNotifyId());
        	getContext().getContentResolver().update(notifyIdUri, values, null, null);
        	NotifyUtils.setNextAlert(getContext());
        }
    };
	
    public NotifyListItem(Context context) {
        super(context);
    }

    public NotifyListItem(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    
    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        mSubjectView = (TextView) findViewById(R.id.subject);
        mEnabledView = (CheckBox) findViewById(R.id.notify_enabled);
        mEnabledView.setOnCheckedChangeListener(mCheckedChangeListener);
    }
    
    public Notify getNotify() {
        return mNotify;
    }

    private void setNotify(Notify notify) {
    	mNotify = notify;
    }
    
    public final void bind(Context context, final Notify notify) {
    	setNotify(notify);
    	
    	StringBuilder subjectTextBuilder = new StringBuilder();
    	subjectTextBuilder.append(context.getString(R.string.notify_arrival_time,
  			  notify.getHour(), notify.getMinute()));
    	
    	subjectTextBuilder.append("\n");
    	subjectTextBuilder.append(notify.getMessage());
		switch(notify.getRepeatWay()) {
			case 0://once

				break;
			case 1://work day
				
				break;
			case 2://every day
				
				break;
		}
		
		mSubjectView.setText(subjectTextBuilder.toString());
		
		mEnabledView.setChecked(notify.getEnable());
    }
}
