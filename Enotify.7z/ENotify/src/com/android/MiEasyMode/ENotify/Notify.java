package com.android.MiEasyMode.ENotify;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import com.android.MiEasyMode.ENotify.R;

public class Notify {
    private static final String TAG = "Notify";
    
	public static final int COLUMN_ID = 0;
	public static final int COLUMN_YEAR = 1;
	public static final int COLUMN_MONTH = 2;
	public static final int COLUMN_DAY = 3;
	public static final int COLUMN_HOUR = 4;
	public static final int COLUMN_MINUTE = 5;
	public static final int COLUMN_ENABLED = 6;
	public static final int COLUMN_MESSAGE = 7;
	public static final int COLUMN_ALARM_TIME = 8;
	public static final int COLUMN_REPEAT_WAY = 9;

	public static final String COLUMN_ID_NAME = "_id";
	public static final String COLUMN_YEAR_NAME = "year";
	public static final String COLUMN_MONTH_NAME = "month";
	public static final String COLUMN_DAY_NAME = "day";
	public static final String COLUMN_HOUR_NAME = "hour";
	public static final String COLUMN_MINUTE_NAME = "minute";
	public static final String COLUMN_ENABLED_NAME = "enabled";
	public static final String COLUMN_MESSAGE_NAME = "message";
	public static final String COLUMN_ALARM_TIME_NAME = "alarmtime";
	public static final String COLUMN_REPEAT_WAY_NAME = "repeatway";
	
    private Context mContext;

    private long mNotifyId = -1;
    private long mYear = -1;
    private long mMonth = -1;
    private long mDay = -1;
    private int mHour = -1;
    private int mMinute = -1;
    private boolean mEnabled = true;
	private String mMessage = null;
    private long mAlarmTime = -1;
    private int mRepeatWay = -1;

	private static Notify sFakeNotify;
    
    public Notify() {
    }
    
    private Notify(Context context, Cursor cursor) {
        Log.e(TAG, "Notify constructor");
        mContext = context;
        fillFromCursor(context, this, cursor);
    }

    private static void fillFromCursor(Context context, Notify notify, Cursor cursor) {
    	notify.mNotifyId = cursor.getLong(cursor.getColumnIndexOrThrow(Notify.COLUMN_ID_NAME));
		//notify.mYear = cursor.getLong(COLUMN_YEAR);
    	//notify.mMonth = cursor.getLong(COLUMN_MONTH);
    	//notify.mDay = cursor.getLong(COLUMN_DAY);
    	notify.mHour = cursor.getInt(cursor.getColumnIndexOrThrow(Notify.COLUMN_HOUR_NAME));
    	notify.mMinute = cursor.getInt(cursor.getColumnIndexOrThrow(Notify.COLUMN_MINUTE_NAME));
    	notify.mEnabled = (cursor.getInt(cursor.getColumnIndexOrThrow(Notify.COLUMN_ENABLED_NAME)) != 0);
    	notify.mMessage = cursor.getString(cursor.getColumnIndexOrThrow(Notify.COLUMN_MESSAGE_NAME));
    	notify.mAlarmTime = cursor.getLong(cursor.getColumnIndexOrThrow(Notify.COLUMN_ALARM_TIME_NAME));
    	//notify.mRepeatWay = cursor.getInt(COLUMN_REPEAT_WAY);
	}

	public static Notify from(Context context, Cursor cursor) {
    	Notify conv = new Notify(context, cursor);
        return conv;
    }
	
    protected void copyFrom(Notify notify) {
    	mNotifyId = notify.mNotifyId;
    	mYear = notify.mYear;
    	mMonth = notify.mMonth;
    	mDay = notify.mDay;
    	mHour = notify.mHour;
    	mMinute = notify.mMinute;
    	mEnabled = notify.mEnabled;
    	mMessage = notify.mMessage;
    	mAlarmTime = notify.mAlarmTime;
    	mRepeatWay = notify.mRepeatWay;
    }
	
	public long getNotifyId() {
		return mNotifyId;
	}
	
	public long getYear() {
		return mYear;
	}
	public long getMonth() {
		return mMonth;
	}
	public long getDay() {
		return mDay;
	}
	public int getHour() {
		return mHour;
	}
	public int getMinute() {
		return mMinute;
	}
	
	public int getRepeatWay() {
		return mRepeatWay;
	}
	
	public boolean getEnable() {
		return mEnabled;
	}
	
	public String getMessage() {
		return mMessage;
	}
	
	public long getAlarmTime() {
		return mAlarmTime;
	}
	
	public void setHour(int hour) {
		mHour = hour;
	}
	
	public void setMinute(int minute) {
		mMinute = minute;
	}
	
	public void setMessage(String msg) {
		mMessage = msg;
	}
	
	public void setAlarmTime(long alarmTime) {
		mAlarmTime = alarmTime;
	}
	
    public static Notify getFakeNotify() {
    	if(sFakeNotify == null) {
    		sFakeNotify = new Notify();
    	}
    	return sFakeNotify;
    }
    
    public static void clearFakeNotify() {
    	sFakeNotify = null;
    }
	
	@Override
	public String toString() {
		return "mNotifyId: " + mNotifyId +
				"  mYear: " + mYear +
				"  mMonth: " + mMonth +
				"  mDay: " + mDay +
				"  mHour: " + mHour +
				"  mMinute: " + mMinute +
				"  mEnabled: " + mEnabled +
				"  mMessage: " + mMessage;
	}
}
