/** Automatically generated file. DO NOT MODIFY */
package com.android.MiEasyMode.ENotify;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}