package com.qidi.policeservice.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class JsonUtils {

	public static String getJsonString(InputStream input) {
		BufferedReader in = new BufferedReader(new InputStreamReader(input));
		StringBuffer buffer = new StringBuffer();
		String line = "";
		String ret = null;
		
		try {
			while ((line = in.readLine()) != null){
				buffer.append(line);
			}
			ret = buffer.toString();
			input.close();
		} catch (IOException e) {;
			e.printStackTrace();
		}
		
		return ret;
	}

}
