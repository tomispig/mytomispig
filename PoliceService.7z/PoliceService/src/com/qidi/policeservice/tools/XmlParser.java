package com.qidi.policeservice.tools;

import java.io.IOException;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import com.qidi.policeservice.datatype.Header;
import com.qidi.policeservice.datatype.SimpleHeader;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Xml;

public class XmlParser {
	
	public static void loadHeadersFromResource(Context context, int resid, ArrayList<ContentItem> target) {
        XmlResourceParser parser = null;
        Resources res = context.getResources();
        AttributeSet attrs;
        String nameSpace = "http://schemas.android.com/apk/res/android";
        
        try {
            parser = res.getXml(resid);

            int type;
            while ((type=parser.next()) != XmlPullParser.END_DOCUMENT
                    && type != XmlPullParser.START_TAG) {
            }

            String nodeName = parser.getName();
            if (!"sample-headers".equals(nodeName)) {
                return;
            }

            final int outerDepth = parser.getDepth();
            while ((type=parser.next()) != XmlPullParser.END_DOCUMENT
                   && (type != XmlPullParser.END_TAG || parser.getDepth() > outerDepth)) {
                if (type == XmlPullParser.END_TAG || type == XmlPullParser.TEXT) {
                    continue;
                }

                nodeName = parser.getName();
                if ("header".equals(nodeName)) {
                    Header header = new Header();
                    attrs = Xml.asAttributeSet(parser);

                    header.iconRes = attrs.getAttributeResourceValue(nameSpace, "icon", 0);
                    header.titleRes = attrs.getAttributeResourceValue(nameSpace, "title", 0);
                    header.summaryRes = attrs.getAttributeResourceValue(nameSpace, "summary", 0);

                    final int innerDepth = parser.getDepth();
                    while ((type=parser.next()) != XmlPullParser.END_DOCUMENT
                           && (type != XmlPullParser.END_TAG || parser.getDepth() > innerDepth)) {
                        if (type == XmlPullParser.END_TAG || type == XmlPullParser.TEXT) {
                            continue;
                        }

                        String innerNodeName = parser.getName();
                        if (innerNodeName.equals("intent")) {
                        	attrs = Xml.asAttributeSet(parser);
                            header.intent = Intent.parseIntent(context.getResources(), parser, attrs);
                        }
                    }

                    target.add(header);
                } else if ("simpleheader".equals(nodeName)) {
                    SimpleHeader header = new SimpleHeader();
                    attrs = Xml.asAttributeSet(parser);

                    //header.iconRes = attrs.getAttributeResourceValue(nameSpace, "icon", 0);
                    header.titleRes = attrs.getAttributeResourceValue(nameSpace, "title", 0);
                    //header.summaryRes = attrs.getAttributeResourceValue(nameSpace, "summary", 0);

                    final int innerDepth = parser.getDepth();
                    while ((type=parser.next()) != XmlPullParser.END_DOCUMENT
                           && (type != XmlPullParser.END_TAG || parser.getDepth() > innerDepth)) {
                        if (type == XmlPullParser.END_TAG || type == XmlPullParser.TEXT) {
                            continue;
                        }

                        String innerNodeName = parser.getName();
                        if (innerNodeName.equals("intent")) {
                        	attrs = Xml.asAttributeSet(parser);
                            header.intent = Intent.parseIntent(context.getResources(), parser, attrs);
                        }
                    }

                    target.add(header);
                } else {
                    skipCurrentTag(parser);
                }
            }
        } catch (IOException e) {
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		} finally {
            if (parser != null) parser.close();
        }

    }
	
	public static void skipCurrentTag(XmlPullParser parser)
            throws XmlPullParserException, IOException {
        int outerDepth = parser.getDepth();
        int type;
        while ((type=parser.next()) != XmlPullParser.END_DOCUMENT
               && (type != XmlPullParser.END_TAG
                       || parser.getDepth() > outerDepth)) {
        }
    }
}
