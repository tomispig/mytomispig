package com.qidi.policeservice.lbs;

public class CellLocationInfo {
	
	public double latitude = -1;
	public double longitude = -1;
	
	public int rssi = 0;
    /**
     * CID in 16 bits format in GSM. Return UNKNOWN_CID in UMTS and CMDA.
     */
	public int cid = 0;
    /**
     * LAC in 16 bits format in GSM. Return UNKNOWN_CID in UMTS and CMDA.
     */
	public int lac = 0;
    /**
     * Primary Scrambling Code in 9 bits format in UMTS
     * Return UNKNOWN_CID in GSM and CMDA.
     */
	public int psc = 0;
    /**
     * Radio network type, value is one of following
     * TelephonyManager.NETWORK_TYPE_XXXXXX.
     */
	public int networkType = -1;
	
	public String location = null;

	public CellLocationInfo() {
		// TODO Auto-generated constructor stub
	}

}
