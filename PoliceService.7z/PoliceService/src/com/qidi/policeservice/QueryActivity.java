package com.qidi.policeservice;

import java.io.InputStream;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.qidi.policeservice.datatype.DocumentItem;
import com.qidi.policeservice.datatype.MenuTag;
import com.qidi.policeservice.tools.JsonUtils;
import com.qidi.policeservice.ui.SampleAdapter;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.web.QueryTask;
import com.qidi.policeservice.web.QueryTask.QueryCallback;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

public class QueryActivity extends Activity implements QueryCallback {
	protected static final String TAG = "QueryActivity";
	private View queryView;
	private View answerView;
	private Boolean onAnswerView = false;
	
	private Spinner mSpinner;
	private EditText mEditText1;
	private EditText mEditText2;
	private Button mStartButton;
	private Button mBackButton;
	private ListView mListView;
	private SampleAdapter mAdapter;
	private ArrayList<ContentItem> mList = new ArrayList<ContentItem>();
	
	private String[] mCarTypeArray;
	private int mCarType = 0;
	private OnClickListener mOnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
				case R.id.start_query:
					startQuery();
					break;
				case R.id.answer_back:
					onBackPressed();
					break;
				default:
					break;
			}
		}	
	};
	private boolean queryLock = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.query_activity_layout);
		
		mCarTypeArray = getResources().getStringArray(R.array.car_type_array);
		
		initQueryViews();
		initAnswerViews();
	}
	
	@Override
	public void onBackPressed() {
		if (onAnswerView) {
			switchView(false);
		} else {
			super.onBackPressed();
		}
	}
	
	@Override
	public void onQueryCompleted(InputStream input) {
		String jsonString = JsonUtils.getJsonString(input);
		if (jsonString != null) {
			parseInfo(jsonString);
		}
		queryLock  = false;
		switchView(true);
	}
	
	private void switchView(Boolean answer) {
		onAnswerView = answer;
		if (answer) {
			queryView.setVisibility(View.GONE);
			answerView.setVisibility(View.VISIBLE);
		} else {
			answerView.setVisibility(View.GONE);
			queryView.setVisibility(View.VISIBLE);
		}
	}

	private void parseInfo(String jsonString) {
		mList.clear();
		mAdapter.notifyDataSetChanged();
		try {
			JSONArray array = new JSONArray(jsonString);
			int n = array.length();
			for(int i = 0; i < n; i++) {
				JSONObject ob = (JSONObject) array.get(i);
				
				int type = ob.optInt("type", -1);
				if (type == MenuTag.TYPE_RECORD) {
					DocumentItem item = new DocumentItem(this);
					
					item.type = type;
					item.id = ob.optInt("id", -1);
					item.title = ob.optString("title", null);
					item.pic = ob.optString("pic", null);
					item.content = ob.optString("content", null);
					
					mList.add(item);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		mAdapter.notifyDataSetChanged();
	}

	protected void startQuery() {
		if (!queryLock) {
			String[] array = new String[] {mCarTypeArray[mCarType], 
					mEditText1.getText().toString(), 
					mEditText2.getText().toString()};
			queryLock = true;
			new QueryTask(this, this).execute(array);
		}
	}

	private void initQueryViews() {
		queryView = findViewById(R.id.query_view);
		
		mSpinner = (Spinner) findViewById(R.id.query_spinner_1);
		mEditText1 = (EditText) findViewById(R.id.query_edit_1);
		mEditText2 = (EditText) findViewById(R.id.query_edit_2);
		mStartButton = (Button) findViewById(R.id.start_query);
		mStartButton.setOnClickListener(mOnClickListener);
		
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.car_type_array, android.R.layout.simple_spinner_item);
		mSpinner.setAdapter(adapter);
		mSpinner.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                	@Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                		mCarType = position;
                		Log.d(TAG, "ps log mCarType = " + mCarType);
                    }

                	@Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
	}
	
	private void initAnswerViews() {
		answerView = findViewById(R.id.answer_view);
		
		mBackButton = (Button) findViewById(R.id.answer_back);
		mBackButton.setOnClickListener(mOnClickListener);
		
		mListView = (ListView) findViewById(R.id.answer_listview);
		mAdapter = new SampleAdapter(mList, this);
		mListView.setAdapter(mAdapter);
		mListView.setDivider(null);
		mListView.setSelector(new ColorDrawable(Color.TRANSPARENT));
	}
}
