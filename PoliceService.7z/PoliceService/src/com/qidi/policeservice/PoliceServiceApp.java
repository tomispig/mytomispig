package com.qidi.policeservice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

public class PoliceServiceApp extends Application {
	private static final String TAG = "PoliceServiceApp";
	private static PoliceServiceApp mInstance;
	private static SharedPreferences mSP;
	private static File mSdCache = null;
	
	public void onCreate() {
		super.onCreate();
		mSP = getSharedPreferences("app_prefenrence", Context.MODE_PRIVATE);	
	}
	
	public PoliceServiceApp() {
		mInstance = this;
    }
	
	public static PoliceServiceApp getInstance() {
        return mInstance;
    }
	
	public static void alarmCall(String number) {
		Uri uri = Uri.parse("tel:" + number);
		Intent intent = new Intent(Intent.ACTION_DIAL, uri);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		getInstance().startActivity(intent); 
	}
	
	public static File getSdCache() {
		if (mSdCache == null) {
			if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED) {
				mSdCache = new File(Environment.getExternalStorageDirectory(), ".policeserv");
				mSdCache.mkdir();
			}
		}
		return mSdCache;
	}
	
	public static InputStream openCacheFileInput(String name) {
		InputStream ret = null;
		getSdCache();
		if (mSdCache != null) {
			try {
				File file = new File(mSdCache, name);
				if (file.exists()) {
					ret = new FileInputStream(file);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		return ret;
	}
	
	public static FileOutputStream openCacheFileOutput(String name, boolean append) {
		FileOutputStream ret = null;
		getSdCache();
		
		try {
			if (mSdCache != null) {
				ret = new FileOutputStream(new File(mSdCache, name), append);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return ret;
	}
	
	public static void checkUpdateVersionTable() {
		long last = mSP.getLong("last_update", 0);
		long current = System.currentTimeMillis();
		if (last == 0 || last > current) {
			mSP.edit().putLong("last_update", current).commit();
			updateVersionTable();
		} else if (current >= (last + 7* 24 * 3600 * 1000)) {
			updateVersionTable();
		}
	}
	
	private static void updateVersionTable() {
		
	}
	
	public static void saveUnitInfo(int id, String name, String tel1, String tel2) {
		Log.d(TAG, "ps log saveUnitInfo id:" + id + " name:" + name + " tel1:" + tel1 + " tel2:" + tel2);
		Editor e = mSP.edit();
		if (name != null && name.length() > 0) {
			e.putString("name" + id, name);
		}
		if (tel1 != null && tel1.length() > 0) {
			e.putString("tel1" + id, tel1);
		}
		if (tel2 != null && tel2.length() > 0) {
			e.putString("tel2" + id, tel2);
		}
		e.commit();
	}
	
	public static String getUnitName(int id) {
		return mSP.getString("name" + id, mInstance.getString(R.string.no_unit_name));
	}
	
	public static String getUnitTel1(int id) {
		return mSP.getString("tel1" + id, mInstance.getString(R.string.no_unit_tel1));
	}
	
	public static String getUnitTel2(int id) {
		return mSP.getString("tel2" + id, mInstance.getString(R.string.no_unit_tel2));
	}
}