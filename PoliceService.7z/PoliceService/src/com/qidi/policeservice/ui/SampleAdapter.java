package com.qidi.policeservice.ui;

import java.util.ArrayList;

import com.qidi.policeservice.datatype.MenuTag;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public class SampleAdapter extends BaseAdapter {
	private Context mContext;
	private ArrayList<ContentItem> mList;
	private LayoutInflater mInflater;
	
	public SampleAdapter(ArrayList<ContentItem> list, Context context) {
		mList = list;
		mContext = context;
		mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public Object getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ContentItem item = (ContentItem) getItem(position);
		Holder holder;
		
		if (convertView == null || item.holderMismatch((Holder) convertView.getTag())) {
			holder = item.getHolder();
			convertView = mInflater.inflate(item.getLayoutId(), parent, false);
			item.bindView(convertView, holder);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}
		
		item.updateView(holder);
		
		return convertView;
	}

	public interface Holder {
	}
	
	public interface ContentItem {
		public MenuTag getMenuTag();
		
		public int getLayoutId();
		
		public Holder getHolder();
		
		public boolean holderMismatch(Holder holder);
		
		public void bindView(View convertView, Holder holder);

		public void updateView(Holder holder);
	}
}
