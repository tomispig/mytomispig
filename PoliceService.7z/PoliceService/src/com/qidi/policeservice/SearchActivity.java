package com.qidi.policeservice;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Stack;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.qidi.policeservice.database.LoadCollectionsTask;
import com.qidi.policeservice.database.LoadCollectionsTask.LoadCollectionsCallback;
import com.qidi.policeservice.database.StaffDbHelper;
import com.qidi.policeservice.datatype.MenuItem;
import com.qidi.policeservice.datatype.MenuTag;
import com.qidi.policeservice.datatype.SearchRootItem;
import com.qidi.policeservice.datatype.StaffItem;
import com.qidi.policeservice.tools.JsonUtils;
import com.qidi.policeservice.ui.SampleAdapter;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.web.LbsQueryTask;

import com.qidi.policeservice.web.LoadFileTask.LoadFileCallback;
import com.qidi.policeservice.web.LoadFileTask;
import com.qidi.policeservice.web.NetworkUtils;
import com.qidi.policeservice.web.QueryMenuCallback;
import com.qidi.policeservice.web.QueryMenuTask;


import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

public class SearchActivity extends Activity implements QueryMenuCallback, LoadCollectionsCallback, LoadFileCallback {
	
	private static final String TAG = "SearchActivity";
	private ListView mListView;
	private SampleAdapter mAdapter;
	private ArrayList<ContentItem> mList = new ArrayList<ContentItem>();
	private TelephonyManager mTelephonyManager;
	
	private OnItemClickListener mListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			ContentItem item = (ContentItem) mAdapter.getItem(position);
			MenuTag tag = item.getMenuTag();
			
			if (tag.getType() == MenuTag.TYPE_SEARCH_POLICE && !queryLock) {
				switchViews((StaffItem) item);
				mMenuStack.push(tag);
			} else {
				queryMenu(tag);
			}
		}
	};
	
	/*Menu UI*/
	private Stack<MenuTag> mMenuStack = new Stack<MenuTag>();
	private Boolean queryLock = false;
	/*Menu UI end*/
	
	private Drawable divider = null;
	private Drawable selector = null;
	private ColorDrawable noSelector = new ColorDrawable(Color.TRANSPARENT);
	
	/*Person view*/
	private View mPersonView;
	private ImageView mPhoto;
	private TextView mName;
	private TextView mNumber;
	private TextView mUnit;
	private Button mFeedback;
	private Button mCall1;
	private Button mCall2;
	private Button mCall3;
	
	private CheckBox mCheckBox;
	
	private StaffItem mCurrentStaffItem;
	
	private StaffDbHelper mDBHelper;
	/*Person view end*/
	
	private OnClickListener mOnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()) {
				case R.id.person_feedback:
					break;
				case R.id.person_call1:
					PoliceServiceApp.alarmCall((String) mCall1.getText());
					break;
				case R.id.person_call2:
					PoliceServiceApp.alarmCall((String) mCall2.getText());
					break;
				case R.id.person_call3:
					PoliceServiceApp.alarmCall((String) mCall3.getText());
					break;
				default:
					break;
			}
		}
	};
	private OnCheckedChangeListener mOnCheckedListener = new OnCheckedChangeListener() {
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			if (isChecked && mCurrentStaffItem != null) {
				collectionAdd(mCurrentStaffItem);
			} else if (!isChecked) {
				collectionDelete(mCurrentStaffItem);
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search_activity_layout);
		
		mDBHelper = new StaffDbHelper(this);
		mTelephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		
		initListView();
		
		initPersonView();
		
		initMenu();
	}
	
	public void onDestroy() {
		super.onDestroy();
		mDBHelper.close();
	}
	
	private boolean collectionContains(StaffItem item) {
		Cursor cur =  mDBHelper.query(new String[] {"number"}, " number = ? ", new String[] {item.number}, null);
		Boolean ret = (cur.getCount() > 0);
		cur.close();
		return ret;
	}
	
	private void collectionDelete(StaffItem item) {
		mDBHelper.delete(" number = ? ", new String[] {item.number});
	}

	private void collectionAdd(StaffItem item) {
		if (collectionContains(item)) {
			return;
		}
		
		ContentValues cv = new ContentValues();
		cv.put("policeid", item.id);
		cv.put("name", item.name);
		cv.put("number", item.number);
		cv.put("unit", item.unit);
		cv.put("unitid", item.unitId);
		cv.put("phonenum1", item.phonenum1);
		cv.put("phonenum2", item.phonenum2);
		cv.put("phonenum3", item.phonenum3);
		cv.put("score1", item.score1);
		cv.put("score2", item.score2);
		cv.put("score3", item.score3);
		cv.put("photo", item.photo);
		
		mDBHelper.insert(cv);
	}

	private void initPersonView() {
		mPersonView = findViewById(R.id.person_view);
		mPhoto = (ImageView) findViewById(R.id.person_photo);
		mName = (TextView) findViewById(R.id.person_name);
		mNumber = (TextView) findViewById(R.id.person_number);
		mUnit = (TextView) findViewById(R.id.person_unit);
		mFeedback = (Button) findViewById(R.id.person_feedback);
		mCall1 = (Button) findViewById(R.id.person_call1);
		mCall2 = (Button) findViewById(R.id.person_call2);
		mCall3 = (Button) findViewById(R.id.person_call3);
		
		mFeedback.setOnClickListener(mOnClickListener);
		mCall1.setOnClickListener(mOnClickListener);
		mCall2.setOnClickListener(mOnClickListener);
		mCall3.setOnClickListener(mOnClickListener);
		
		mCheckBox = (CheckBox) findViewById(R.id.person_collect);
		mCheckBox.setOnCheckedChangeListener(mOnCheckedListener);
	}
	
	private void switchViews(StaffItem item) {
		if (item != null) {
			mListView.setVisibility(View.GONE);
			mPersonView.setVisibility(View.VISIBLE);
			
			mName.setText(item.name);
			mNumber.setText(getString(R.string.person_number, item.number));
			//mUnit.setText(getString(R.string.person_unit, item.unit));
			mUnit.setText(getString(R.string.person_unit, PoliceServiceApp.getUnitName(item.unitId)));
			mCall1.setText(item.phonenum1);
			//mCall2.setText(item.phonenum2);
			mCall2.setText(PoliceServiceApp.getUnitTel1(item.unitId));
			//mCall3.setText(item.phonenum3);
			mCall3.setText(PoliceServiceApp.getUnitTel2(item.unitId));
			
			if (item.photo != null) {
				new LoadFileTask(this, this).execute(item.photo);
			}
			
			mCurrentStaffItem = item;
			mCheckBox.setOnCheckedChangeListener(null);
			mCheckBox.setChecked(collectionContains(item));
			mCheckBox.setOnCheckedChangeListener(mOnCheckedListener);
		} else {
			mPhoto.setImageResource(R.drawable.no_photo);
			mPersonView.setVisibility(View.GONE);
			mListView.setVisibility(View.VISIBLE);
		}	
	}

	/*Menu UI*/
	private void queryMenu(MenuTag tag) {
		if (queryLock || tag.getType() == MenuTag.TYPE_SEARCH_POLICE) {
			Log.e(TAG, "ps log search queryMenu locked tag:" + tag);
			return;
		}
		
		queryLock = true;
		int type = tag.getType();
		
		switch (type) {
			case MenuTag.TYPE_SEARCH_ROOT:
			case MenuTag.TYPE_SEARCH_HEADER:
			case MenuTag.TYPE_HEADER:
			case MenuTag.TYPE_SEARCH_AREA:
			case MenuTag.TYPE_SEARCH_PROVINCE:
			case MenuTag.TYPE_SEARCH_CITY:
			case MenuTag.TYPE_SEARCH_DISTRICT:
			case MenuTag.TYPE_SEARCH_STATION:
				Log.e(TAG, "ps log search queryMenu tag:" + tag);
				new QueryMenuTask(this, this).execute(tag);
				break;
			case MenuTag.TYPE_SEARCH_LBS:
				Log.e(TAG, "ps log search queryMenu tag:" + tag);
				GsmCellLocation cl = (GsmCellLocation) mTelephonyManager.getCellLocation();
				//debug
				if (cl == null) {
					cl = new GsmCellLocation();
					cl.setLacAndCid(11, 22);
				}
				new QueryLocationTask(tag).execute(cl);
				break;
			case MenuTag.TYPE_SEARCH_COLLECTION:
				new LoadCollectionsTask(this, mList, this).execute(tag);
				break;
			default:
				queryLock = false;
				break;
		}
	}
	
	private void changeListView(Boolean simple) {
		if (simple) {
			mListView.setDivider(null);
			mListView.setSelector(noSelector);
		} else {
			mListView.setDivider(divider);
			mListView.setSelector(selector);
		}
	}
	
	private void initMenu() {
		queryMenu(new MenuTag(MenuTag.TYPE_SEARCH_ROOT, 0));
	}
	
	@Override
	public void onBackPressed() {
		if (mMenuStack.empty()) {
			super.onBackPressed();
			return;
		}
		MenuTag tag = mMenuStack.pop();
		if (MenuTag.TYPE_SEARCH_POLICE == tag.type) {
			switchViews(null);
		}
		if (mMenuStack.empty()) {
			super.onBackPressed();
		} else {
			queryMenu(mMenuStack.pop());
		}
	}
	
	@Override
	public void onLoadCollections(MenuTag tag) {
		mAdapter.notifyDataSetChanged();
		mMenuStack.push(tag);
		queryLock = false;
		changeListView(false);
	}

	@Override
	public void onQueryMenuCompleted(InputStream input, MenuTag tag) {
		if (input == null) {
			Log.e(TAG, "ps log search query menu failed");
		} else {
			Log.d(TAG, "ps log search query succeeded tag:" + tag);
			String jsonString = JsonUtils.getJsonString(input);
			if (jsonString != null) {
				parseMenuInfo(jsonString);
			}
			mMenuStack.push(tag);
		}
		queryLock = false;
	}
	
	@Override
	public void onLoadFileCompleted(InputStream input) {
		if (input != null) {
			Drawable drawable = Drawable.createFromStream(input, null);
			mPhoto.setImageDrawable(drawable);
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/*Menu UI end*/
	
	private class QueryLocationTask extends AsyncTask<GsmCellLocation, Void, String> {
		private MenuTag tag;

		public QueryLocationTask(MenuTag tag) {
			this.tag = tag;
		}

		@Override
		protected String doInBackground(GsmCellLocation... cl) {
			String url = getString(R.string.get_location_url, cl[0].getLac(), cl[0].getCid());
			return NetworkUtils.getLocation(url);
		}
		
		@Override
        protected void onPostExecute(String result) {
			queryLocation(result, tag);
		}
	}

	public void queryLocation(String result, MenuTag tag) {
		String latitude = null;
		String longitude = null;
		if (result != null) {
			String[] array = result.split(",", 3);
			if (array.length >= 2) {
				latitude = array[0];
				longitude = array[1];
				new LbsQueryTask(this, this, tag).execute(new String[] {latitude, longitude});
			}
		} 
		//debug
		else {
			new LbsQueryTask(this, this, tag).execute(new String[] {"aa", "bb"});
		}
	}
	
	private void parseMenuInfo(String jsonString) {
		mList.clear();
		mAdapter.notifyDataSetChanged();
		
		try {
			JSONObject mObj = new JSONObject(jsonString);
			if (mObj.optInt("QueryState", 0) == 1) {
				JSONArray array = mObj.optJSONArray("Data");
				if (array != null) {
					int n = array.length();
					for(int i = 0; i < n; i++) {
						JSONObject ob = (JSONObject) array.get(i);
						ContentItem item = parseItem(ob);
						if (item != null) {
							mList.add(item);
						}
					}
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		mAdapter.notifyDataSetChanged();
	}
	
	private ContentItem parseItem(JSONObject ob) {
		int type = ob.optInt("type", MenuTag.DEFAULT_TYPE);
		if (type == MenuTag.DEFAULT_TYPE) {
			if (ob.has("ProvinceName") && !ob.has("StationName")) {
				type = MenuTag.TYPE_SEARCH_PROVINCE;
			} else if (ob.has("ProvinceName") && !ob.has("StationName")) {
				type = MenuTag.TYPE_SEARCH_CITY;
			} else if (ob.has("DistrictName") && !ob.has("StationName")) {
				type = MenuTag.TYPE_SEARCH_DISTRICT;
			} else if (ob.has("StationName") && !ob.has("PoliceID")) {
				type = MenuTag.TYPE_SEARCH_STATION;
			} else if (ob.has("PoliceID")) {
				type = MenuTag.TYPE_SEARCH_POLICE;
			}
		}
		
		if (type == MenuTag.TYPE_SEARCH_HEADER) {
			MenuItem item = new MenuItem();
			item.type = type;
			item.id = ob.optInt("id", -1);
			item.title = ob.optString("title", null);
			changeListView(false);
			return item;
		} else if (type == MenuTag.TYPE_SEARCH_PROVINCE) {
			MenuItem item = new MenuItem();
			item.type = type;
			item.id = ob.optInt("ProvinceID", -1);
			item.title = ob.optString("ProvinceName", null);
			changeListView(false);
			return item;
		} else if (type == MenuTag.TYPE_SEARCH_CITY) {
			MenuItem item = new MenuItem();
			item.type = type;
			item.id = ob.optInt("CityID", -1);
			item.title = ob.optString("CityName", null);
			changeListView(false);
			return item;
		} else if (type == MenuTag.TYPE_SEARCH_DISTRICT) {
			MenuItem item = new MenuItem();
			item.type = type;
			item.id = ob.optInt("DistrictID", -1);
			item.title = ob.optString("DistrictName", null);
			changeListView(false);
			return item;
		} else if (type == MenuTag.TYPE_SEARCH_STATION) {
			MenuItem item = new MenuItem();
			item.type = type;
			item.id = ob.optInt("StationID", -1);
			item.title = ob.optString("StationName", null);
			
			PoliceServiceApp.saveUnitInfo(item.id, item.title, 
					ob.optString("Tel1", null), 
					ob.optString("Tel2", null));
			changeListView(false);
			return item;
		} else if (type == MenuTag.TYPE_SEARCH_AREA || 
				type == MenuTag.TYPE_SEARCH_COLLECTION || 
				type == MenuTag.TYPE_SEARCH_LBS) {
			SearchRootItem item = new SearchRootItem();
			
			item.type = type;
			item.id = ob.optInt("id", -1);
			
			changeListView(true);
			return item;
		} else if (type == MenuTag.TYPE_SEARCH_POLICE) {
			StaffItem item = new StaffItem();
			item.type = type;
			item.id = ob.optInt("PoliceID", -1);
			item.name = ob.optString("Name");
			item.number = ob.optString("PoliceNo");
			//item.unit = ob.optString("unit");
			item.unitId = ob.optInt("StationID", -1);
			item.phonenum1 = ob.optString("PTel1");
			item.phonenum2 = ob.optString("PTel2");
			//item.phonenum3 = ob.optString("phonenum3");
			item.photo = ob.optString("PhotoURL");
			
			changeListView(false);
			return item;
		}
		return null;
	}

	private void initListView() {
		mListView = (ListView) findViewById(R.id.sample_listview);
		mAdapter = new SampleAdapter(mList, this);
		mListView.setAdapter(mAdapter);
		
		mListView.setOnItemClickListener(mListener);
		
		divider = mListView.getDivider();
		selector = mListView.getSelector();
	}

}
