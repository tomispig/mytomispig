package com.qidi.policeservice;


import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.TextView;
import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Intent;

public class MainActivity extends ActivityGroup {
	private TabHost mTabHost;
	private ViewPager  mViewPager;
    private TabsAdapter mTabsAdapter;
    private LayoutInflater mLayoutInflater;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		mLayoutInflater = LayoutInflater.from(this);
		
		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();
		mTabHost.setup(getLocalActivityManager());
		
		mTabHost.addTab(createTabSpec("tab0", R.string.home_page, R.drawable.tab_home, new Intent(this, HomeActivityGroup.class))); 
		mTabHost.addTab(createTabSpec("tab1", R.string.search_police, R.drawable.tab_search, new Intent(this, SearchActivity.class))); 
		mTabHost.addTab(createTabSpec("tab2", R.string.service_guide, R.drawable.tab_guide, new Intent(this, GuideActivity.class))); 
		mTabHost.addTab(createTabSpec("tab3", R.string.guard_notice, R.drawable.tab_notice, new Intent(this, NoticeActivity.class))); 
		mTabHost.addTab(createTabSpec("tab4", R.string.query_records, R.drawable.tab_query, new Intent(this, QueryActivity.class)));
		
		//mTabHost.addTab(mTabHost.newTabSpec("xxx").setIndicator("xxx").setContent(new Intent(this, SearchActivity.class)));

        mTabHost.setCurrentTab(0);
	}
	
	protected void onNewIntent(Intent intent) {
		int tab = intent.getIntExtra("current_tab", 0);
		mTabHost.setCurrentTab(tab);
    }
	
	private TabSpec createTabSpec(String tag, int stringId, int drawableId, Intent intent) {
		TabWidget tabs = (TabWidget) findViewById(android.R.id.tabs);
		View tabView = mLayoutInflater.inflate(R.layout.tab_widget_indicator, tabs, false);
		((TextView) tabView.findViewById(R.id.tab_label)).setText(stringId);
		if (drawableId > 0) {
			((ImageView) tabView.findViewById(R.id.tab_icon)).setImageResource(drawableId);
		}
		TabSpec ts = mTabHost.newTabSpec(tag);
		ts.setIndicator(tabView);
		ts.setContent(intent);
		return ts;
	}

	private class TabsAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return false;
		}
		
	}

}
