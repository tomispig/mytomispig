package com.qidi.policeservice.web;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.qidi.policeservice.PoliceServiceApp;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

public class LoadFileTask extends AsyncTask<String, Void, InputStream> {
	private static final String TAG = "LoadFileTask";
	private Context mContext;
	private LoadFileCallback mCallback;

	public LoadFileTask(Context context, LoadFileCallback callback) {
		mContext = context;
		mCallback = callback;
	}

	@Override
	protected InputStream doInBackground(String... url) {
		String fielUrl = url[0];
		if (fielUrl == null || fielUrl.length() == 0) {
			return null;
		}
		InputStream input;
		input = getLocalData(getLocalName(fielUrl));
		if (input == null) {
			input = getWebData(fielUrl);
		}
		return input;
	}

	private InputStream getLocalData(String name) {
		Log.d(TAG, "ps log getLocalData file name:" + name);
		if (name == null) {
			return null;
		}
		return PoliceServiceApp.openCacheFileInput(name);
	}
	
	private InputStream getWebData(String url) {
		if (url == null) {
			return null;
		}
		InputStream input = NetworkUtils.getFileIS(url);
		Log.d(TAG, "ps log getWebData file url:" + url);
		if(input == null) {
			return null;
		}
		
		String name = getLocalName(url);
		try {	
			FileOutputStream os = PoliceServiceApp.openCacheFileOutput(name, true);
	        
			if (os != null) {
				byte[] buf = new byte[1024];
				int len;
				while((len = input.read(buf, 0, 1024)) != -1) {
					os.write(buf, 0, len);
				}
				os.flush();
				os.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return getLocalData(name);
	}
	
	private String getLocalName(String url) {
		if (url == null) {
			return null;
		}
		int separatorIndex = url.lastIndexOf("/");
        return (separatorIndex < 0) ? url : url.substring(separatorIndex + 1, url.length());
	}

	@Override
    protected void onPostExecute(InputStream result) {
		mCallback.onLoadFileCompleted(result);
	}

	public interface LoadFileCallback {
		void onLoadFileCompleted(InputStream input);
	}
}
