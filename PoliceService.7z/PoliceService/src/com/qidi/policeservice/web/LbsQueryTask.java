package com.qidi.policeservice.web;

import java.io.IOException;
import java.io.InputStream;

import com.qidi.policeservice.datatype.MenuTag;
import android.content.Context;
import android.os.AsyncTask;

public class LbsQueryTask extends AsyncTask<String, Void, InputStream> {
	private static final String TAG = "QueryMenuTask";
	private Context mContext;
	private QueryMenuCallback mCallback;
	private MenuTag mMenuTag;

	public LbsQueryTask(Context context,
			QueryMenuCallback callback, MenuTag tag) {
		mContext = context;
		mCallback = callback;
		mMenuTag = tag;
	}

	@Override
	protected InputStream doInBackground(String... params) {
		String latitude = params[0];
		String longitude = params[1];

		InputStream input;
		input = getLocalData(latitude, longitude);
		if (input == null) {
			input = getWebData(latitude, longitude);
		}
		return input;
	}
	
	@Override
    protected void onPostExecute(InputStream result) {
		mCallback.onQueryMenuCompleted(result, mMenuTag);
	}

	private InputStream getWebData(String latitude, String longitude) {
		return null;
	}

	private InputStream getLocalData(String latitude, String longitude) {
		InputStream input = null;
		try {
			input = mContext.getAssets().open("lbstest.json");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return input;
	}
}
