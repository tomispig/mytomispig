package com.qidi.policeservice.web;

import java.io.InputStream;

import com.qidi.policeservice.datatype.MenuTag;

public interface QueryMenuCallback {
	void onQueryMenuCompleted(InputStream input, MenuTag mMenuTag);
}
