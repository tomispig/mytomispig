package com.qidi.policeservice.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import android.util.Log;


public class NetworkUtils {
	private static final int CONNECTION_TIMEOUT_VALUE = 3000;
	private static final int SO_TIMEOUT_VALUE = 3000;
	
	private static final int CONNECTION_TIMEOUT_VALUE_FILE = 10000;
	private static final int SO_TIMEOUT_VALUE_FILE = 10000;

	public static String getLocation(String url) {
		String result= null;
		
		DefaultHttpClient client = new DefaultHttpClient();
		HttpGet get = new HttpGet(url);
		
        client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_VALUE);
        client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, SO_TIMEOUT_VALUE);
		
		HttpResponse resp = null;
		HttpEntity entity = null;
		BufferedReader br = null;
		
		try {
			resp = client.execute(get);
			entity = resp.getEntity();
			br = new BufferedReader(new InputStreamReader(entity.getContent()));
			result = br.readLine();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static InputStream getJsonIS(String url) {
		InputStream ret = null;
		if (url == null) {
			return ret;
		}

		try {
			DefaultHttpClient client = new DefaultHttpClient();
			HttpGet get = new HttpGet(url);
		
        	client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_VALUE);
        	client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, SO_TIMEOUT_VALUE);
		
			HttpResponse resp = null;
			HttpEntity entity = null;

			resp = client.execute(get);
			entity = resp.getEntity();
			ret = entity.getContent();
			Log.e("NetworkUtils", "ps log search 111");
		} catch (ClientProtocolException e) {
			Log.e("NetworkUtils", "ps log search ClientProtocolException:" + e);
			e.printStackTrace();
		} catch (IOException e) {
			Log.e("NetworkUtils", "ps log search IOException:" + e);
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			Log.e("NetworkUtils", "ps log search IllegalArgumentException:" + e);
			e.printStackTrace();
		}
		
		return ret;
	}
	
	public static InputStream getFileIS(String url) {
		InputStream ret = null;
		if (url == null) {
			return ret;
		}

		try {
			DefaultHttpClient client = new DefaultHttpClient();
			HttpGet get = new HttpGet(url);
		
        	client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_VALUE_FILE);
        	client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, SO_TIMEOUT_VALUE_FILE);
		
			HttpResponse resp = null;
			HttpEntity entity = null;

			resp = client.execute(get);
			entity = resp.getEntity();
			ret = entity.getContent();
			Log.e("NetworkUtils", "ps log search 111");
		} catch (ClientProtocolException e) {
			Log.e("NetworkUtils", "ps log search ClientProtocolException:" + e);
			e.printStackTrace();
		} catch (IOException e) {
			Log.e("NetworkUtils", "ps log search IOException:" + e);
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			Log.e("NetworkUtils", "ps log search IllegalArgumentException:" + e);
			e.printStackTrace();
		}
		
		return ret;
	}
}