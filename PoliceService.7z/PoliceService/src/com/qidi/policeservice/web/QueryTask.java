package com.qidi.policeservice.web;

import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

public class QueryTask extends AsyncTask<String, Void, InputStream> {
	private static final String TAG = "QueryTask";
	private Context mContext;
	private QueryCallback mCallback;
	
	public QueryTask(Context context, QueryCallback callback) {
		mContext = context;
		mCallback = callback;
	}
	
	@Override
	protected InputStream doInBackground(String... params) {
		InputStream input = getWebData(assemble(params));
		return input;
	}
	
	private InputStream getWebData(String url) {
		//debug
		String name = "querytest.json";
		InputStream input = null;
		try {
			input = mContext.getAssets().open(name);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return input;
	}

	private String assemble(String[] array) {
		//debug
		return null;
	}
	
	@Override
    protected void onPostExecute(InputStream result) {
		mCallback.onQueryCompleted(result);
	}

	public interface QueryCallback {
		void onQueryCompleted(InputStream input);
	}
}
