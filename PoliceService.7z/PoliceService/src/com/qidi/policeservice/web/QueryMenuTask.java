package com.qidi.policeservice.web;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.qidi.policeservice.datatype.MenuTag;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

public class QueryMenuTask extends AsyncTask<MenuTag, Void, InputStream> {
	private static final String TAG = "QueryMenuTask";
	private Context mContext;
	private QueryMenuCallback mCallback;
	private MenuTag mMenuTag;
	
	public QueryMenuTask(Context context,
			QueryMenuCallback callback) {
		mContext = context;
		mCallback = callback;
	}

	@Override
	protected InputStream doInBackground(MenuTag... arg0) {
		mMenuTag = arg0[0];
		
		if (isBaseMenu(mMenuTag)) {
			return getBaseData(mMenuTag);
		}
		
		InputStream input;
		input = getLocalData(mMenuTag);
		if (input == null) {
			input = getWebData(mMenuTag);
		}
		return input;
	}
	
	private boolean isBaseMenu(MenuTag tag) {
		if ((tag.type == MenuTag.TYPE_SEARCH_ROOT || 
				tag.type == MenuTag.TYPE_GUIDE_ROOT || 
				tag.type == MenuTag.TYPE_NOTICE_ROOT) && 
				tag.id == 0) {
			return true;
		}
		return false;
	}
	
	private InputStream getBaseData(MenuTag tag) {
		String name = "menu_base_" + tag.type + "_" + tag.id + ".json"; 
		Log.d(TAG, "ps log getBaseData name:" + name);
		InputStream input = null;
		try {
			input = mContext.getAssets().open(name);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return input;
	}

	private InputStream getLocalData(MenuTag tag) {
		String name = "menu_" + tag.type + "_" + tag.id + ".json";
		Log.d(TAG, "ps log getLocalData name:" + name);
		InputStream input = null;
		try {
			//input = mContext.getAssets().open(name);
			input = mContext.openFileInput(name);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return input;
	}
	
	private InputStream getWebData(MenuTag tag) {
		InputStream input = NetworkUtils.getJsonIS(tag.getUrl());
		Log.d(TAG, "ps log getWebData url:" + tag.getUrl());
		if(input == null) {
			return null;
		}
		String name = "menu_" + tag.type + "_" + tag.id + ".json";
		try {
			FileOutputStream os = mContext.openFileOutput(name, Context.MODE_PRIVATE | Context.MODE_APPEND);
			byte[] buf = new byte[1024];
			int len;
			while((len = input.read(buf, 0, 1024)) != -1) {
				os.write(buf, 0, len);
			}
			os.flush();
			os.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return getLocalData(tag);
	}

	@Override
    protected void onPostExecute(InputStream result) {
		mCallback.onQueryMenuCompleted(result, mMenuTag);
	}
	
}
