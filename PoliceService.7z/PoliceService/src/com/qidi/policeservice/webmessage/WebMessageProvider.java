package com.qidi.policeservice.webmessage;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import static com.qidi.policeservice.webmessage.WebMesageDatabaseHelper.CONVERSATIONS_TABLE_NAME;
import static com.qidi.policeservice.webmessage.WebMesageDatabaseHelper.CONVERSATION_MESSAGES_TABLE_NAME;
import static com.qidi.policeservice.webmessage.WebMesageDatabaseHelper.BULLETINS_TABLE_NAME;
import static com.qidi.policeservice.webmessage.WebMesageDatabaseHelper.BULLETIN_COMMENTS_TABLE_NAME;

public class WebMessageProvider extends ContentProvider {

    private static final String TAG = "WebMessageProvider";

    public static final String AUTHORITY = "webmessage";
    private static final String VND_ANDROID_DIR_WEB_MESSAGE =
            "vnd.android-dir/webmessage";
    
	private static final String DEFAULT_SORT_ORDER = "date DESC";

    private static final int CONVERSATIONS = 0;
    private static final int CONVERSATION_BY_ID = 1;
	private static final int MESSAGES = 2;
	private static final int MESSAGE_BY_ID = 3;
	private static final int BULLETINS = 4;
	private static final int BULLETINS_BY_ID = 5;
	private static final int COMMENTS = 6;
	private static final int COMMENT_BY_ID = 7;
	
    private static final UriMatcher sUriMatcher;

    private SQLiteOpenHelper mOpenHelper;

    @Override
    public boolean onCreate() {
        mOpenHelper = new WebMesageDatabaseHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        switch (sUriMatcher.match(uri)) {
	        case CONVERSATIONS:
	        	qb.setTables(CONVERSATIONS_TABLE_NAME);
	            break;
	
	        case CONVERSATION_BY_ID:
	    	    //Now not use
	            break;
	
	        case MESSAGES:
	        	qb.setTables(CONVERSATION_MESSAGES_TABLE_NAME);
	            break;
	
	        case MESSAGE_BY_ID:
	        	//Now not use
	            break;
	  
	        case BULLETINS:
	        	qb.setTables(BULLETINS_TABLE_NAME);
	            break;
	
	        case BULLETINS_BY_ID:
	        	//Now not use
	            break;
	
	        case COMMENTS:
	        	qb.setTables(BULLETIN_COMMENTS_TABLE_NAME);
	            break;
	
	        case COMMENT_BY_ID:
	        	//Now not use
	            break;
	            
	        default:
	            throw new IllegalArgumentException("Unknown URI " + uri);
        }

        // If no sort order is specified use the default
        String orderBy;
        if (TextUtils.isEmpty(sortOrder)) {
            orderBy = DEFAULT_SORT_ORDER;
        } else {
            orderBy = sortOrder;
        }

        // Get the database and run the query
        SQLiteDatabase db = mOpenHelper.getReadableDatabase();
        Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, orderBy);

        // Tell the cursor what uri to watch, so it knows when its source data changes
        c.setNotificationUri(getContext().getContentResolver(), uri);
        Log.e(TAG, "query cursor count " + c.getCount());
        return c;
    }

    @Override
    public String getType(Uri uri) {
        return VND_ANDROID_DIR_WEB_MESSAGE;
    }

    @Override
    public Uri insert(Uri uri, ContentValues initialValues) {
        ContentValues values;
        if (initialValues != null) {
            values = new ContentValues(initialValues);
        } else {
            values = new ContentValues();
        }
        
        String table = "";

        Long now = Long.valueOf(System.currentTimeMillis());
        // Make sure that the fields are all set
        if (values.containsKey(WebMessageColumns.DATE) == false) {
            values.put(WebMessageColumns.DATE, now);
        }

        switch (sUriMatcher.match(uri)) {
	        case CONVERSATIONS:
	        	table = CONVERSATIONS_TABLE_NAME;
	            break;
	
	        case MESSAGES:
	        	table = CONVERSATION_MESSAGES_TABLE_NAME;
	            break;
	  
	        case BULLETINS:
	        	table = BULLETINS_TABLE_NAME;
	            break;
	
	        case COMMENTS:
	        	table = BULLETIN_COMMENTS_TABLE_NAME;
	            break;
	
	        default:
	            Log.e(TAG, "Invalid request: " + uri);
	            return null;
        }

        
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();

		long rowId = db.insert(table, null, values);
        if (rowId > 0) {
            Uri retUri = ContentUris.withAppendedId(uri, rowId);
            getContext().getContentResolver().notifyChange(retUri, null);
            return retUri;
        } else {
            Log.e(TAG,"insert: failed! " + values.toString());
        }

        return null;
    }

    @Override
    public int delete(Uri uri, String where, String[] whereArgs) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int count = 0;
        String table = "";
        
        switch (sUriMatcher.match(uri)) {
	        case CONVERSATIONS:
	        	table = CONVERSATIONS_TABLE_NAME;
	            break;
	
	        case CONVERSATION_BY_ID:
	    	    //Now not use
	            break;
	
	        case MESSAGES:
	        	table = CONVERSATION_MESSAGES_TABLE_NAME;
	            break;
	
	        case MESSAGE_BY_ID:
	        	//Now not use
	            break;
	  
	        case BULLETINS:
	        	table = BULLETINS_TABLE_NAME;
	            break;
	
	        case BULLETINS_BY_ID:
	        	//Now not use
	            break;
	
	        case COMMENTS:
	        	table = BULLETIN_COMMENTS_TABLE_NAME;
	            break;
	
	        case COMMENT_BY_ID:
	        	//Now not use
	            break;
	
	        default:
	            throw new IllegalArgumentException("Unknown URI " + uri);
        }
        
        count = db.delete(table, where, whereArgs);
        if (count > 0) {
        	getContext().getContentResolver().notifyChange(uri, null);
        }

        return count;
    }

    @Override
    public int update(Uri uri, ContentValues values, String where, String[] whereArgs) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int count = 0;
        String table = "";
        
        switch (sUriMatcher.match(uri)) {
	        case CONVERSATIONS:
	        	table = CONVERSATIONS_TABLE_NAME;
	            break;
	
	        case CONVERSATION_BY_ID:
	    	    //Now not use
	            break;
	
	        case MESSAGES:
	        	table = CONVERSATION_MESSAGES_TABLE_NAME;
	            break;
	
	        case MESSAGE_BY_ID:
	        	//Now not use
	            break;
	  
	        case BULLETINS:
	        	table = BULLETINS_TABLE_NAME;
	            break;
	
	        case BULLETINS_BY_ID:
	        	//Now not use
	            break;
	
	        case COMMENTS:
	        	table = BULLETIN_COMMENTS_TABLE_NAME;
	            break;
	
	        case COMMENT_BY_ID:
	        	//Now not use
	            break;

	        default:
	            throw new IllegalArgumentException("Unknown URI " + uri);
        }

        count = db.update(table, values, where, whereArgs);
        if (count > 0) {
        	getContext().getContentResolver().notifyChange(uri, null);
        }

        return count;
    }

    static {
        sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        sUriMatcher.addURI(AUTHORITY, "conversations", CONVERSATIONS);
        sUriMatcher.addURI(AUTHORITY, "conversations/#", CONVERSATION_BY_ID);

        sUriMatcher.addURI(AUTHORITY, "messages", MESSAGES);
        sUriMatcher.addURI(AUTHORITY, "messages/#", MESSAGE_BY_ID);
        
        sUriMatcher.addURI(AUTHORITY, "bulletins", BULLETINS);
        sUriMatcher.addURI(AUTHORITY, "bulletins", BULLETINS_BY_ID);
        
        sUriMatcher.addURI(AUTHORITY, "comments", COMMENTS);
        sUriMatcher.addURI(AUTHORITY, "comments/#", COMMENT_BY_ID);
    }
}