package com.qidi.policeservice.webmessage;

import com.qidi.policeservice.HomeActivityGroup;
import com.qidi.policeservice.R;
import com.qidi.policeservice.webmessage.WebMessageColumns.BulletinsColumns;
import com.qidi.policeservice.webmessage.WebMessageColumns.ConversationsColumns;

import android.net.Uri;
import android.os.Bundle;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ListView;

public class ConversationList extends ListActivity {
	private static final String TAG = "ConversationList";
	 private static final boolean DEBUG = true;
	
    private static final int CONVERSATION_LIST_QUERY_TOKEN       = 1701;
    public static final int DELETE_CONVERSATION_TOKEN      = 1801;
    private static final int DELETE_OBSOLETE_THREADS_TOKEN = 1802;
    
    private static final int BULLETINS_LIST_QUERY_TOKEN =2001;
    public static final int DELETE_BULLETIN_TOKEN      = 2002;
    private static final int DELETE_OBSOLETE_BULLETINS_TOKEN = 2003;
    
    private static final Uri sAllThreadsUri = Uri.parse(
            "content://webmessage/conversations");
    private static final String[] ALL_THREADS_PROJECTION = {
        "_id", "date", "recipient_ids", "body"
    };

    private static final Uri sAllBulletinsUri = Uri.parse(
            "content://webmessage/conversations");
    private static final String[] ALL_BULLETIN_PROJECTION = {
        "_id", "date", "remote_id", "body"
    };
    
    /**
     * The default sort order for conversation list
     */
    public static final String DEFAULT_SORT_ORDER = "date DESC";

	private static final String MODE_NAME = "current_mode";

    private CursorAdapter mListAdapter;
    private AsyncQueryHandler mQueryHandler;

    private CharSequence mTitle;

	private int mCurrentMode = 0;
	private boolean mIsNeedQuery = true;
	
	/*neuron add, 2013-4-7*/
	private Button mButton;
	/*end neuron add, 2013-4-7*/
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.conversation_list);
       
        ListView listView = getListView();
        
        // Tell the list view which view to display when the list is empty
        View emptyView = findViewById(R.id.empty);
        listView.setEmptyView(emptyView);
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        Log.e(TAG, "IMSI = " + tm.getSubscriberId());
        
    	/*neuron modify, 2013-4-6*/
    	/*
    	 * SharedPreferences settings = getPreferences(MODE_PRIVATE);
    	 * mCurrentMode = settings.getInt(MODE_NAME, 0);
    	*/
    	mCurrentMode = getIntent().getIntExtra(MODE_NAME, 0);
    	/*end neuron modify, 2013-4-6*/
    	
    	/*neuron add, 2013-4-7*/
    	mButton = (Button) findViewById(R.id.select_contact_button);
    	mButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new AlertDialog.Builder(getParent())
			    .setTitle(R.string.select_contact)
			    .setItems(R.array.select_contact_items, new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) {
			            /* User clicked so do some stuff */
			        	String[] items = getResources().getStringArray(R.array.select_contact_items);
			        	openConversation(items[which]);
			        }
			    })
			    .show();
			}
    	});
    	if (mCurrentMode == 0) {
    		mButton.setVisibility(View.VISIBLE);
    	} else {
    		mButton.setVisibility(View.GONE);
    	}
    	/*end neuron add, 2013-4-7*/
    	
    	Log.e(TAG, "ps log ConversationList onCreate");
    	initList(mCurrentMode);
        
        mTitle = getString(R.string.app_name);
    }
    
    @Override
    public void onResume() {
    	super.onResume();
    	Log.d(TAG, "ps log ConversationList onResume");
    	initList(mCurrentMode);
    }

    private void initList(int mode) {
    	if(mode == 0) {
            mQueryHandler = new ConversationListQueryHandler(getContentResolver());
	        mListAdapter = new ConversationListAdapter(this, null);
	        //mListAdapter.setOnContentChangedListener(mContentChangedListener);
	        //getListView().setRecyclerListener(mListAdapter);
    	} else {
            mQueryHandler = new BulletinListQueryHandler(getContentResolver());
	        mListAdapter = new BulletinListAdapter(this, null);
	        //mListAdapter.setOnContentChangedListener(mContentChangedListener);
	        //getListView().setRecyclerListener(mListAdapter);
    	}

    	setListAdapter(mListAdapter);
        startAsyncQuery();
    }

    private void switchMode() {
    	SharedPreferences settings = getPreferences(MODE_PRIVATE);
    	SharedPreferences.Editor editor = settings.edit();
    	Log.e(TAG, "before currentMode =" + mCurrentMode);
    	if (mCurrentMode == 0) {
    		editor.putInt(MODE_NAME, 1);
    	} else {
    		editor.putInt(MODE_NAME, 0);
    	}
    	editor.commit();
    	mCurrentMode = settings.getInt(MODE_NAME, 0);
    	Log.e(TAG, "after currentMode =" + mCurrentMode);
    	
    	mListAdapter.changeCursor(null);
    	initList(mCurrentMode); 
    }
    
    private final class ConversationListQueryHandler extends AsyncQueryHandler {
        public ConversationListQueryHandler(ContentResolver contentResolver) {
            super(contentResolver);
        }

        @Override
        protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
            switch (token) {
            case CONVERSATION_LIST_QUERY_TOKEN:
                mListAdapter.changeCursor(cursor);
                setTitle(mTitle);
                setProgressBarIndeterminateVisibility(false);
                break;

            default:
                Log.e(TAG, "onQueryComplete called with unknown token " + token);
            }
        }

        @Override
        protected void onDeleteComplete(int token, Object cookie, int result) {
            switch (token) {
            case DELETE_CONVERSATION_TOKEN:

                startAsyncQuery();
                break;

            case DELETE_OBSOLETE_THREADS_TOKEN:
                // Nothing to do here.
                break;
            }
        }
    }

    private final class BulletinListQueryHandler extends AsyncQueryHandler {
        public BulletinListQueryHandler(ContentResolver contentResolver) {
            super(contentResolver);
        }

        @Override
        public void onQueryComplete(int token, Object cookie, Cursor cursor) {
            switch (token) {
            case BULLETINS_LIST_QUERY_TOKEN:
                mListAdapter.changeCursor(cursor);
                setTitle(mTitle);
                setProgressBarIndeterminateVisibility(false);
                break;

            default:
                Log.e(TAG, "onQueryComplete called with unknown token " + token);
            }
        }

        @Override
        protected void onDeleteComplete(int token, Object cookie, int result) {
            switch (token) {
            case DELETE_BULLETIN_TOKEN:

                startAsyncQuery();
                break;

            case DELETE_OBSOLETE_BULLETINS_TOKEN:
                // Nothing to do here.
                break;
            }
        }
    }
    
    private void bulletinQuery() {
		if(mIsNeedQuery) {
			String[] bulletinItems = getResources().getStringArray(R.array.bulletin_body_items);
			int len = bulletinItems.length;
			MatrixCursor translated = new MatrixCursor(ALL_BULLETIN_PROJECTION, len);
			Object[] row = new Object[ALL_BULLETIN_PROJECTION.length];
			for(int i = 0; i<len; i++) {
				row[0] = Integer.valueOf(i+1);
				row[1] = Long.valueOf(System.currentTimeMillis() - 86400000*(len - i));//(len-i) day before current time 
				row[2] = String.valueOf(i+1);
				row[3] = bulletinItems[i];
				
				translated.addRow(row);
			}
			
			((BulletinListQueryHandler)mQueryHandler).onQueryComplete(BULLETINS_LIST_QUERY_TOKEN, null, translated);
		}
	}
    
    private void startAsyncQuery() {
        setTitle(getString(R.string.refreshing));
        setProgressBarIndeterminateVisibility(true);

        if(mCurrentMode == 0) {
	        mQueryHandler.startQuery(CONVERSATION_LIST_QUERY_TOKEN, null, sAllThreadsUri,
	                ALL_THREADS_PROJECTION, null, null, DEFAULT_SORT_ORDER);
        } else {
        	bulletinQuery();
	        //mQueryHandler.startQuery(BULLETINS_LIST_QUERY_TOKEN, null, sAllBulletinsUri,
	        //        ALL_BULLETIN_PROJECTION, null, null, DEFAULT_SORT_ORDER);
        }
    }

	@Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        // Note: don't read the thread id data from the ConversationListItem view passed in.
        // It's unreliable to read the cached data stored in the view because the ListItem
        // can be recycled, and the same view could be assigned to a different position
        // if you click the list item fast enough. Instead, get the cursor at the position
        // clicked and load the data from the cursor.
        // (ConversationListAdapter extends CursorAdapter, so getItemAtPosition() should
        // return the cursor object, which is moved to the position passed in)
    	Cursor cursor  = (Cursor) getListView().getItemAtPosition(position);
    	if(mCurrentMode == 0) {
	        String recipient_id = cursor.getString(2);
	
	        if (DEBUG) {
	            Log.d(TAG, "onListItemClick: pos=" + position + ", view=" + v + ", recipient_id=" + recipient_id);
	        }
	
	        openConversation(recipient_id);
    	} else {
            
            if (DEBUG) {
                Log.d(TAG, "onListItemClick: pos=" + position + ", view=" + v);
            }

            openBulletin(cursor);
    	}
    }
    
    private void openConversation(String recipient_id) {
    	Intent intent = new Intent(this, ComposeMessageActivity.class);
    	intent.putExtra(ConversationsColumns.RECIPIENT_IDS, recipient_id);
    	//startActivity(intent);
    	HomeActivityGroup.mGroup.start("ComposeMessageActivity" + recipient_id, intent);
	}

    private void openBulletin(Cursor cursor) {
    	Intent intent = new Intent(this, ComposeCommentActivity.class);
    	String id = cursor.getString(2);
    	intent.putExtra(BulletinsColumns.REMOTE_ID, cursor.getString(2));
    	intent.putExtra("bulletin_body", cursor.getString(3));
    	intent.putExtra("bulletin_date", cursor.getLong(1));
    	//startActivity(intent);
    	HomeActivityGroup.mGroup.start("ComposeCommentActivity" + id, intent);
	}
    
	@Override
    protected void onStart() {
        super.onStart();
        startAsyncQuery();
    }

	@Override
    protected void onStop() {
        super.onStop();

        // Simply setting the choice mode causes the previous choice mode to finish and we exit
        // multi-select mode (if we're in it) and remove all the selections.
        //getListView().setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);

        mListAdapter.changeCursor(null);
    }

    private void sendMessageto() {
	    new AlertDialog.Builder(ConversationList.this)
	    .setTitle(R.string.select_contact)
	    .setItems(R.array.select_contact_items, new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) {
	            /* User clicked so do some stuff */
	        	String[] items = getResources().getStringArray(R.array.select_contact_items);
	        	openConversation(items[which]);
	        }
	    })
	    .show();
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        
        MenuItem item = menu.findItem(R.id.action_select_contacte);
        item.setVisible(mCurrentMode == 0);
        
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.action_swtich_mode:
            	switchMode();
                break;
            case R.id.action_select_contacte:
            	sendMessageto();
	            break;
            default:
                return true;
        }
        return false;
    }*/
    
    @Override
	public void onBackPressed() {
		HomeActivityGroup.mGroup.onBackPressed();
	}
}
