package com.qidi.policeservice.webmessage;

import com.qidi.policeservice.R;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

public class MessagesListAdapter extends CursorAdapter {
    private static final String TAG = "MessagesListAdapter";
    private static final boolean DEBUG = true;
    
    public static final int INCOMING_ITEM_TYPE = 0;
    public static final int OUTGOING_ITEM_TYPE = 1;
    
    private final LayoutInflater mFactory;

	public MessagesListAdapter(Context context, Cursor c) {
		super(context, c, true /* auto-requery */);
		mFactory = LayoutInflater.from(context);
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
        if (!(view instanceof MessageListItem)) {
            Log.e(TAG, "Unexpected bound view: " + view);
            return;
        }

        MessageListItem headerView = (MessageListItem) view;
        //Conversation conv = Conversation.from(context, cursor);
        headerView.bind(cursor);
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
        if (DEBUG) Log.v(TAG, "inflating new view");
        return mFactory.inflate(isRecvMessage(cursor) ?
                R.layout.message_list_item_recv : R.layout.message_list_item_send,
                parent, false);
	}

    private boolean isRecvMessage(Cursor cursor) {
    	//Column 5 is message type
        int type = cursor.getInt(5);

        //type 0 present incoming message
        return type == 0;
    }
    
    @Override
    public int getViewTypeCount() {
        return 2;   // Incoming and outgoing messages
    }
    
    @Override
    public int getItemViewType(int position) {
        Cursor cursor = (Cursor)getItem(position);
        return getItemViewType(cursor);
    }

    private int getItemViewType(Cursor cursor) {
        //type 0 present incoming message
        return isRecvMessage(cursor) ? INCOMING_ITEM_TYPE : OUTGOING_ITEM_TYPE;
    }
}
