package com.qidi.policeservice.webmessage;

import com.qidi.policeservice.R;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

public class BulletinListAdapter extends CursorAdapter {
    private static final String TAG = "BulletinListAdapter";
    private static final boolean DEBUG = true;
    
    private final LayoutInflater mFactory;
    
	public BulletinListAdapter(Context context, Cursor c) {
		super(context, c, true /* auto-requery */);
		mFactory = LayoutInflater.from(context);
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
        if (!(view instanceof BulletinListItem)) {
            Log.e(TAG, "Unexpected bound view: " + view);
            return;
        }

        BulletinListItem headerView = (BulletinListItem) view;
        //Conversation conv = Conversation.from(context, cursor);
        headerView.bind(cursor);
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
        if (DEBUG) Log.v(TAG, "inflating new view");
        return mFactory.inflate(R.layout.bulletin_list_item, parent, false);
	}

}
