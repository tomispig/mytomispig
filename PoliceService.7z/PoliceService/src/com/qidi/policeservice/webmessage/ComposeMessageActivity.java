package com.qidi.policeservice.webmessage;

import com.qidi.policeservice.HomeActivityGroup;
import com.qidi.policeservice.R;
import com.qidi.policeservice.webmessage.WebMessageColumns.ConversationsColumns;

import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.app.ListActivity;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class ComposeMessageActivity extends ListActivity implements View.OnClickListener {
	private static final String TAG = "ComposeMessageActivity";
    private static final boolean DEBUG = true;
	
    private static final int MESSAGE_LIST_QUERY_TOKEN       = 1701;
    private static final int MESSAGE_LIST_INSERT_TOKEN      = 1702;
    public static final int DELETE_MESSAGE_TOKEN            = 1703;
    
    private static final Uri sMessagesUri = Uri.parse(
            "content://webmessage/messages");
    private static final String[] MESSAGES_PROJECTION = {
        "_id", "date", "recipient_ids", 
        "body", "read", "type"
    };

	private TextWatcher mTextEditorWatcher= new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            updateSendButtonState();
        }

		@Override
		public void afterTextChanged(Editable s) {
			// TODO Auto-generated method stub
			
		}
    };
    
    /**
     * The default sort order for conversation list
     */
    public static final String DEFAULT_SORT_ORDER = "date ASC";

    private CursorAdapter mListAdapter;
    private AsyncQueryHandler mQueryHandler;

    private CharSequence mTitle;

	private String mRecipientId;

	private Button mSendButton;

	private EditText mTextEditor;
   
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.compose_message_activity);
       
        ListView listView = getListView();
        
        // Tell the list view which view to display when the list is empty
        View emptyView = findViewById(R.id.empty);
        listView.setEmptyView(emptyView);
        
        mQueryHandler = new MessagesListQueryHandler(getContentResolver());
        
        initRes();
        
    	initList();

    	//Set in ConversationList
    	Intent intent = getIntent();
    	mTitle = mRecipientId = intent.getStringExtra(ConversationsColumns.RECIPIENT_IDS);
    	
    	updateSendButtonState();
    }

    private void initRes() {
    	mTextEditor = (EditText) findViewById(R.id.embedded_text_editor);
    	mTextEditor.addTextChangedListener(mTextEditorWatcher);
    	
    	mSendButton = (Button) findViewById(R.id.send_button);
    	mSendButton.setOnClickListener(this);

	}

	@Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.e(TAG, "onNewIntent call");
    }
    
    private void initList() {
        mListAdapter = new MessagesListAdapter(this, null);
    	setListAdapter(mListAdapter);
    	
        startAsyncQuery();
    }
    
    private final class MessagesListQueryHandler extends AsyncQueryHandler {
        public MessagesListQueryHandler(ContentResolver contentResolver) {
            super(contentResolver);
        }

        @Override
        protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
            switch (token) {
	            case MESSAGE_LIST_QUERY_TOKEN:
	                mListAdapter.changeCursor(cursor);
	                setTitle(mTitle);
	                setProgressBarIndeterminateVisibility(false);
	                break;
	
	            default:
	                Log.e(TAG, "onQueryComplete called with unknown token " + token);
            }
        }

        @Override
        protected void onInsertComplete(int token, Object cookie, Uri uri) {
            switch (token) {
	            case MESSAGE_LIST_INSERT_TOKEN:
	            	Log.e(TAG, "onInsertComplete with uri:  " + uri);
	                break;
	
	            default:
	                Log.e(TAG, "onInsertComplete called with unknown token " + token);
            }
        }
        
        @Override
        protected void onDeleteComplete(int token, Object cookie, int result) {
            switch (token) {
	            case DELETE_MESSAGE_TOKEN:
	                startAsyncQuery();
	                break;
            }
        }
    }
    
    private void startAsyncQuery() {
        setTitle(getString(R.string.refreshing));
        setProgressBarIndeterminateVisibility(true);

        String selection = "recipient_ids='" + mRecipientId + "'";
        mQueryHandler.startQuery(MESSAGE_LIST_QUERY_TOKEN, null, sMessagesUri,
                MESSAGES_PROJECTION, selection, null, DEFAULT_SORT_ORDER);
    }
    
    @Override
    protected void onStart() {
        super.onStart();
        startAsyncQuery();
    }

	@Override
    protected void onStop() {
        super.onStop();

        // Simply setting the choice mode causes the previous choice mode to finish and we exit
        // multi-select mode (if we're in it) and remove all the selections.
        //getListView().setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);

        mListAdapter.changeCursor(null);
    }

	@Override
	public void onClick(View v) {
        if (v == mSendButton) {
            SendMessage();
        }
	}

    private long getOrCreateConversationId() {
    	ContentResolver cr = getContentResolver();
        Uri conversationUri = Uri.parse(
                "content://webmessage/conversations");
    	
    	String[] projection = {"_id"};
    	String selection = "recipient_ids='" + mRecipientId + "'";
        Cursor cursor = cr.query(conversationUri, projection, selection, null, null);
        if (cursor != null
        	&& cursor.getCount() > 0) {
        	Log.e(TAG, "getCount = " + cursor.getCount());
            try {
                if (cursor.moveToFirst()) {
                    return cursor.getLong(0);
                }
            } finally {
                cursor.close();
            }
        }

        ContentValues values = new ContentValues(1);
        values.put(ConversationsColumns.RECIPIENT_IDS, mRecipientId);
        Uri retUri = cr.insert(conversationUri, values);
        Log.e(TAG, "retUri = " + retUri);
        return Integer.valueOf(retUri.getLastPathSegment());
    }
	
	private void SendMessage() {
		long conversationId = getOrCreateConversationId();
		if(DEBUG) {
			Log.e(TAG, "conversationId = " + conversationId);
		}
		
		String msg = mTextEditor.getText().toString();
		saveSendingMessage(msg);
		
		//After send, clear edit text
		mTextEditor.getText().clear();
		
        new Thread(new Runnable() {
            public void run() {
            	SystemClock.sleep(5000);
            	simulateRecvMsg();
            }
        }, "simulateRecvMsg").start();
	}

	private void simulateRecvMsg() {
		String[] simulateStrItems = getResources().getStringArray(R.array.simulate_str_array);
		int randomInt =  Math.abs((int)(System.currentTimeMillis()%3));
        ContentValues values = new ContentValues(7);

        values.put("recipient_ids", mRecipientId);
        values.put("body", simulateStrItems[randomInt]);
        values.put("type", 0);//0 presents received
        mQueryHandler.startInsert(MESSAGE_LIST_INSERT_TOKEN, null, sMessagesUri, values);
	}

	private void saveSendingMessage(String msg) {
        ContentValues values = new ContentValues(7);

        values.put("recipient_ids", mRecipientId);
        values.put("body", msg);
        values.put("type", 2);//2 presents sending
        mQueryHandler.startInsert(MESSAGE_LIST_INSERT_TOKEN, null, sMessagesUri, values);
	}
	
	private void updateSendButtonState() {
		//Edit text has typed at least one char.
		mSendButton.setEnabled(mTextEditor.length() > 0);
	}
	
	@Override
	public void onBackPressed() {
		HomeActivityGroup.mGroup.onBackPressed();
	}
}
