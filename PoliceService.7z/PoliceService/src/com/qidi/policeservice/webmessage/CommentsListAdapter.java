package com.qidi.policeservice.webmessage;

import com.qidi.policeservice.R;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

public class CommentsListAdapter extends CursorAdapter {
    private static final String TAG = "CommentsListAdapter";
    private static final boolean DEBUG = true;
    
    private final LayoutInflater mFactory;

	public CommentsListAdapter(Context context, Cursor c) {
		super(context, c, true /* auto-requery */);
		mFactory = LayoutInflater.from(context);
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
        if (!(view instanceof CommentListItem)) {
            Log.e(TAG, "Unexpected bound view: " + view);
            return;
        }

        CommentListItem headerView = (CommentListItem) view;
        //Conversation conv = Conversation.from(context, cursor);
        headerView.bind(cursor);
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
        if (DEBUG) Log.v(TAG, "inflating new view");
        return mFactory.inflate(R.layout.comment_list_item,
                parent, false);
	}
}
