package com.qidi.policeservice.webmessage;

import android.provider.BaseColumns;

public interface WebMessageColumns extends BaseColumns {
    public static final String DATE = "date";
    public static final String BODY = "body";

    public static interface ConversationsColumns extends WebMessageColumns {
    	public static final String RECIPIENT_IDS = "recipient_ids";
    	public static final String SNIPPET_CHARSET = "snippet_cs";
    	public static final String READ = "read";
    }
    
    public static interface MessagesColumns extends WebMessageColumns {
    	public static final String CONVERSATION_ID = "conversation_id";
    	public static final String READ = "read";
    	public static final String TYPE = "type";
    }
    
    public static interface BulletinsColumns extends WebMessageColumns {
    	public static final String REMOTE_ID = "remote_id";
    }
    
    public static interface CommentsColumns extends WebMessageColumns {
    	public static final String REMOTE_ID = "remote_id";
    }
}
