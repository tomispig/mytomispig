package com.qidi.policeservice.webmessage;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.qidi.policeservice.webmessage.WebMessageColumns.ConversationsColumns;
import com.qidi.policeservice.webmessage.WebMessageColumns.MessagesColumns;
import com.qidi.policeservice.webmessage.WebMessageColumns.BulletinsColumns;
import com.qidi.policeservice.webmessage.WebMessageColumns.CommentsColumns;

public class WebMesageDatabaseHelper extends SQLiteOpenHelper {
    static final String DATABASE_NAME = "webmessage.db";
    static final int DATABASE_VERSION = 2;
    static final String CONVERSATIONS_TABLE_NAME = "conversations";
    static final String CONVERSATION_MESSAGES_TABLE_NAME = "messages";
    static final String BULLETINS_TABLE_NAME = "bulletins";
    static final String BULLETIN_COMMENTS_TABLE_NAME = "comments";

	private Context mContext;
    
	public WebMesageDatabaseHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		mContext = context;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		createConversationsTables(db);
		createMessagesTables(db);
		createBulletinsTables(db);
		createCommentsTables(db);
	}

	private void createConversationsTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + CONVERSATIONS_TABLE_NAME + " ("
                + ConversationsColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + ConversationsColumns.DATE + " INTEGER DEFAULT 0,"
                + ConversationsColumns.RECIPIENT_IDS + " TEXT,"
                + ConversationsColumns.BODY + " TEXT,"
                + ConversationsColumns.SNIPPET_CHARSET + " INTEGER DEFAULT 0,"
                + ConversationsColumns.READ + " INTEGER DEFAULT 1"
                + ");");		
	}

	private void createMessagesTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + CONVERSATION_MESSAGES_TABLE_NAME + " ("
                + MessagesColumns._ID + " INTEGER PRIMARY KEY,"
                + MessagesColumns.DATE + " INTEGER DEFAULT 0,"
                + MessagesColumns.CONVERSATION_ID + " INTEGER,"
                + ConversationsColumns.RECIPIENT_IDS + " TEXT,"
                + MessagesColumns.BODY + " TEXT,"
                + MessagesColumns.READ + " INTEGER DEFAULT 1,"
                + MessagesColumns.TYPE + " INTEGER"
                + ");");	
	}
	
	private void createBulletinsTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + BULLETINS_TABLE_NAME + " ("
                + BulletinsColumns._ID + " INTEGER PRIMARY KEY,"
                + BulletinsColumns.REMOTE_ID + " TEXT,"//Determined by webservice return value
                + BulletinsColumns.DATE + " INTEGER DEFAULT 0,"
                + BulletinsColumns.BODY + " TEXT"
                + ");");
	}

	private void createCommentsTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + BULLETIN_COMMENTS_TABLE_NAME + " ("
                + CommentsColumns._ID + " INTEGER PRIMARY KEY,"
                + CommentsColumns.REMOTE_ID + " TEXT,"//Determined by webservice return value
                + CommentsColumns.DATE + " INTEGER DEFAULT 0,"
                + CommentsColumns.BODY + " TEXT"
                + ");");
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}

}
