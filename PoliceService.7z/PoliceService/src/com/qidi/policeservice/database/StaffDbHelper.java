package com.qidi.policeservice.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StaffDbHelper extends SQLiteOpenHelper {
	private static final String DATABASE_NAME = "staff.db";
    private static final int DATABASE_VERSION = 1;
    private static final Object dbLock = new Object();
    
    private static final String STAFF_TABLE_CREATE = "CREATE TABLE staff (" +
            "_id INTEGER PRIMARY KEY," +
    		"policeid INTEGER, " +
            "name TEXT, " +
            "number TEXT, " +
            "unit TEXT, " +
            "unitid INTEGER, " +
            "phonenum1 TEXT, " +
            "phonenum2 TEXT, " +
            "phonenum3 TEXT, " +
            "score1 TEXT, " +
            "score2 TEXT, " +
            "score3 TEXT, " +
            "photo TEXT);";

	public StaffDbHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(STAFF_TABLE_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS alarms");
        onCreate(db);
	}
	
	public long insert(ContentValues values) {
		return insert("staff", null, values);
	}

	public long insert(String table, String nullColumnHack, ContentValues values) {
		synchronized(dbLock) {
			return getWritableDatabase().insert(table, nullColumnHack, values);
		}
	}
	
	public int delete(String whereClause, String[] whereArgs) {
		return delete("staff", whereClause, whereArgs);
	}
	
	public int delete(String table, String whereClause, String[] whereArgs) {
		synchronized(dbLock) {
			return getWritableDatabase().delete(table, whereClause, whereArgs);
		}
	}
	
	public Cursor query(String[] columns, String selection, String[] selectionArgs, String orderBy) {
		return query("staff", columns, selection, selectionArgs, null, null, orderBy, null);
	}
	
	public Cursor query(String table, String[] columns, String selection, String[] selectionArgs, 
			String groupBy, String having, String orderBy, String limit) {
		synchronized(dbLock) {
			return getReadableDatabase().query(table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
		}
	}
}
