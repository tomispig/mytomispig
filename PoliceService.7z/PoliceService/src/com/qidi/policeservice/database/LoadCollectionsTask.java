package com.qidi.policeservice.database;

import java.util.ArrayList;

import com.qidi.policeservice.datatype.MenuTag;
import com.qidi.policeservice.datatype.StaffItem;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;

import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;

public class LoadCollectionsTask extends AsyncTask<MenuTag, Void, Boolean> {
	Context mContext;
	ArrayList<ContentItem> list;
	LoadCollectionsCallback mCallback;
	MenuTag mTag;

	public LoadCollectionsTask(Context context, ArrayList<ContentItem> list, LoadCollectionsCallback callback) {
		mContext = context;
		this.list = list;
		mCallback = callback;
	}

	@Override
	protected Boolean doInBackground(MenuTag... arg0) {
		mTag = arg0[0];
		list.clear();
		StaffDbHelper helper = new StaffDbHelper(mContext);
		Cursor cur = helper.query(null, null, null, "name");
		if (!cur.moveToFirst()) {
			cur.close();
			return false;
		}
		do {
			StaffItem item = new StaffItem();
			
			item.type = MenuTag.TYPE_SEARCH_POLICE;
			item.id = cur.getInt(cur.getColumnIndex("policeid"));
			item.name = cur.getString(cur.getColumnIndex("name"));
			item.number = cur.getString(cur.getColumnIndex("number"));
			item.unit = cur.getString(cur.getColumnIndex("unit"));
			item.unitId = cur.getInt(cur.getColumnIndex("unitid"));
			item.phonenum1 = cur.getString(cur.getColumnIndex("phonenum1"));
			item.phonenum2 = cur.getString(cur.getColumnIndex("phonenum2"));
			item.phonenum3 = cur.getString(cur.getColumnIndex("phonenum3"));
			item.photo = cur.getString(cur.getColumnIndex("photo"));
			
			int score = -1;
			score = cur.getInt(cur.getColumnIndex("score1"));
			if (score >=0 && score <=5) {
				item.score1 = score;
			}
			score = cur.getInt(cur.getColumnIndex("score2"));
			if (score >=0 && score <=5) {
				item.score2 = score;
			}
			score = cur.getInt(cur.getColumnIndex("score3"));
			if (score >=0 && score <=5) {
				item.score3 = score;
			}
			
			list.add(item);
		} while (cur.moveToNext());
		
		cur.close();
		return true;
	}
	
	@Override
    protected void onPostExecute(Boolean result) {
		mCallback.onLoadCollections(mTag);
	}
	
	public interface LoadCollectionsCallback {
		void onLoadCollections(MenuTag tag);
	}
}
