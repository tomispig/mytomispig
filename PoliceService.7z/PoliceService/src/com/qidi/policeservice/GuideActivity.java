package com.qidi.policeservice;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Stack;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.qidi.policeservice.R;
import com.qidi.policeservice.datatype.DocumentItem;
import com.qidi.policeservice.datatype.MenuItem;
import com.qidi.policeservice.datatype.MenuTag;
import com.qidi.policeservice.tools.JsonUtils;
import com.qidi.policeservice.ui.SampleAdapter;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.web.QueryMenuCallback;
import com.qidi.policeservice.web.QueryMenuTask;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class GuideActivity extends Activity implements QueryMenuCallback {
	private static final String TAG = "GuideActivity";
	
	private ListView mListView;
	private SampleAdapter mAdapter;
	private ArrayList<ContentItem> mList = new ArrayList<ContentItem>();
	private Drawable divider = null;
	private Drawable selector = null;
	private ColorDrawable noSelector = new ColorDrawable(Color.TRANSPARENT);
	
	/*Menu UI*/
	private Stack<MenuTag> mMenuStack = new Stack<MenuTag>();
	private static Boolean queryLock = false;
	/*Menu UI end*/

	private OnItemClickListener mListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			ContentItem contentItem = (ContentItem) mAdapter.getItem(position);
			MenuTag tag = contentItem.getMenuTag();
			if (tag.getType() == MenuTag.TYPE_HEADER) {
				queryMenu(tag);
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_page_layout);

		initListView();
		
		initMenu();
	}

	
	/*Menu UI*/
	private void queryMenu(MenuTag tag) {
		if (!queryLock) {
			queryLock = true;
			new QueryMenuTask(this, this).execute(tag);
		}
	}
	
	private void initMenu() {
		queryMenu(new MenuTag(MenuTag.TYPE_GUIDE_ROOT, 0));
	}
	
	@Override
	public void onBackPressed() {
		if (mMenuStack.empty()) {
			super.onBackPressed();
		}
		mMenuStack.pop();
		if (mMenuStack.empty()) {
			super.onBackPressed();
		} else {
			queryMenu(mMenuStack.pop());
		}
	}

	@Override
	public void onQueryMenuCompleted(InputStream input, MenuTag tag) {
		if (input == null) {
			Log.e(TAG, "ps log query menu failed");
		} else {
			String jsonString = JsonUtils.getJsonString(input);
			if (jsonString != null) {
				parseMenuInfo(jsonString);
			}
			mMenuStack.push(tag);
		}
		queryLock = false;
	}
	/*Menu UI end*/
	
	private void parseMenuInfo(String jsonString) {
		mList.clear();
		mAdapter.notifyDataSetChanged();
		try {
			JSONArray array = new JSONArray(jsonString);
			int n = array.length();
			for(int i = 0; i < n; i++) {
				JSONObject ob = (JSONObject) array.get(i);
				
				int type = ob.optInt("type", -1);
				if (type == MenuTag.TYPE_HEADER) {
					MenuItem item = new MenuItem();
					
					item.type = type;
					item.id = ob.optInt("id", -1);
					item.title = ob.optString("title", null);
					
					mList.add(item);
					mListView.setDivider(divider);
					mListView.setSelector(selector);
				} else if (type == MenuTag.TYPE_DOCUMENT) {
					DocumentItem item = new DocumentItem(this);
					
					item.type = type;
					item.id = ob.optInt("id", -1);
					item.title = ob.optString("title", null);
					item.pic = ob.optString("pic", null);
					item.content = ob.optString("content", null);
					
					mList.add(item);
					mListView.setDivider(null);
					mListView.setSelector(noSelector);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		mAdapter.notifyDataSetChanged();
	}

	private void initListView() {
		mListView = (ListView) findViewById(R.id.sample_listview);
		mAdapter = new SampleAdapter(mList, this);
		mListView.setAdapter(mAdapter);
		mListView.setOnItemClickListener(mListener );
		divider = mListView.getDivider();
		selector = mListView.getSelector();
	}
}
