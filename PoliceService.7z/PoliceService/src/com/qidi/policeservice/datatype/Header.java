package com.qidi.policeservice.datatype;

import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qidi.policeservice.R;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.ui.SampleAdapter.Holder;

public class Header implements ContentItem {
	public int id = MenuTag.DEFAULT_ID;
	public int type = MenuTag.DEFAULT_TYPE;
	
    public int titleRes = 0;
    public int summaryRes = 0;
    public int iconRes = 0;
    public Intent intent;

	@Override
	public int getLayoutId() {
		return R.layout.header_item_layout;
	}

	@Override
	public Holder getHolder() {
		return new HeaderHolder();
	}

	@Override
	public void bindView(View convertView, Holder holder) {
		HeaderHolder h = (HeaderHolder) holder;
		h.icon = (ImageView) convertView.findViewById(R.id.header_icon);
		h.title = (TextView) convertView.findViewById(R.id.header_title);
		h.summary = (TextView) convertView.findViewById(R.id.header_summary);
	}

	@Override
	public void updateView(Holder holder) {
		HeaderHolder h = (HeaderHolder) holder;
		if (iconRes != 0) {
			h.icon.setImageResource(iconRes);
		}
		if (titleRes != 0) {
			h.title.setText(titleRes);
		}
		if (summaryRes != 0) {
			h.summary.setText(summaryRes);
		}
	}
	
	public static class HeaderHolder implements Holder{
		ImageView icon;
		TextView title;
		TextView summary;
	}

	@Override
	public boolean holderMismatch(Holder holder) {
		return !(holder instanceof HeaderHolder);
	}

	@Override
	public MenuTag getMenuTag() {
		return new MenuTag(type, id);
	}

}
