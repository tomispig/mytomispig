package com.qidi.policeservice.datatype;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.qidi.policeservice.PoliceServiceApp;
import com.qidi.policeservice.R;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.ui.SampleAdapter.Holder;

public class StaffItem implements ContentItem {
	public int id = MenuTag.DEFAULT_ID;
	public int type = MenuTag.DEFAULT_TYPE;
	
	public String name = null;
	public String number = null;
	public String unit = null;
	public int unitId = -1;
	public String phonenum1 = null;
	public String phonenum2 = null;
	public String phonenum3 = null;
	public int score1 = -1;
	public int score2 = -1;
	public int score3 = -1;
	public String photo = null;
	
    public Intent intent;

	@Override
	public int getLayoutId() {
		return R.layout.search_item_layout;
	}

	@Override
	public Holder getHolder() {
		return new StaffHolder();
	}

	@Override
	public void bindView(View convertView, Holder holder) {
		StaffHolder h = (StaffHolder) holder;
		h.title = (TextView) convertView.findViewById(R.id.search_header_title);
	}

	@Override
	public void updateView(Holder holder) {
		StaffHolder h = (StaffHolder) holder;
		if (name != null) {
			h.title.setText(name + " (" + PoliceServiceApp.getUnitName(unitId) + ")");
		}
	}
	
	public static class StaffHolder implements Holder{
		TextView title;
	}

	@Override
	public boolean holderMismatch(Holder holder) {
		return !(holder instanceof StaffHolder);
	}

	@Override
	public MenuTag getMenuTag() {
		return new MenuTag(type, id);
	}

}
