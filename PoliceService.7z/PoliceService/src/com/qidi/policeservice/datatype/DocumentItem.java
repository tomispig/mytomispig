package com.qidi.policeservice.datatype;

import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.qidi.policeservice.R;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.ui.SampleAdapter.Holder;
import com.qidi.policeservice.web.LoadFileTask;
import com.qidi.policeservice.web.LoadFileTask.LoadFileCallback;

public class DocumentItem implements ContentItem, LoadFileCallback {
	
	public int id = MenuTag.DEFAULT_ID;
	public int type = MenuTag.DEFAULT_TYPE;
	
	public String title = null;
	public String pic = null;
	public String content = null;
	
	private Context mContext;
	private DocumentHolder mHolder;
	private Drawable mDrawable;
	
	public DocumentItem(Context context) {
		mContext = context;
	}

	@Override
	public int getLayoutId() {
		return R.layout.document_item_layout;
	}

	@Override
	public Holder getHolder() {
		return new DocumentHolder();
	}

	@Override
	public void bindView(View convertView, Holder holder) {
		DocumentHolder h = (DocumentHolder) holder;
		h.title = (TextView) convertView.findViewById(R.id.document_title);
		h.pic = (ImageView) convertView.findViewById(R.id.document_pic);
		h.content = (TextView) convertView.findViewById(R.id.document_content);
	}

	@Override
	public void updateView(Holder holder) {
		DocumentHolder h = (DocumentHolder) holder;
		mHolder = h;
		if (title == null) {
			h.title.setVisibility(View.GONE);
		} else {
			h.title.setText(title);
		}
		h.content.setText(content);
		h.pic.setVisibility(View.GONE);
		queryPicture(pic, holder);
	}
	
	private void queryPicture(String pic, Holder holder) {
		if (pic != null) {
			new LoadFileTask(mContext, this).execute(pic);
		}
	}

	public static class DocumentHolder implements Holder{
		TextView title;
		ImageView pic;
		TextView content;
	}

	@Override
	public boolean holderMismatch(Holder holder) {
		return !(holder instanceof DocumentHolder);
	}

	@Override
	public void onLoadFileCompleted(InputStream input) {
		if (input != null) {
			mDrawable = Drawable.createFromStream(input, null);
			mHolder.pic.setVisibility(View.VISIBLE);
			mHolder.pic.setImageDrawable(mDrawable);
			
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public MenuTag getMenuTag() {
		return new MenuTag(type, id);
	}

}
