package com.qidi.policeservice.datatype;


import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.qidi.policeservice.R;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.ui.SampleAdapter.Holder;

public class SimpleHeader implements ContentItem {
	public int id = MenuTag.DEFAULT_ID;
	public int type = MenuTag.DEFAULT_TYPE;
	
	public int titleRes = 0;
	public int summaryRes = 0;
    public int iconRes = 0;
    public Intent intent;

	@Override
	public int getLayoutId() {
		return R.layout.simple_header_item_layout;
	}

	@Override
	public Holder getHolder() {
		return new SimpleHeaderHolder();
	}

	@Override
	public void bindView(View convertView, Holder holder) {
		SimpleHeaderHolder h = (SimpleHeaderHolder) holder;
		h.title = (TextView) convertView.findViewById(R.id.simple_header_title);
	}

	@Override
	public void updateView(Holder holder) {
		SimpleHeaderHolder h = (SimpleHeaderHolder) holder;
		if (titleRes != 0) {
			h.title.setText(titleRes);
		}
	}
	
	public static class SimpleHeaderHolder implements Holder{
		TextView title;
	}

	@Override
	public boolean holderMismatch(Holder holder) {
		return !(holder instanceof SimpleHeaderHolder);
	}

	@Override
	public MenuTag getMenuTag() {
		return new MenuTag(type, id);
	}

}
