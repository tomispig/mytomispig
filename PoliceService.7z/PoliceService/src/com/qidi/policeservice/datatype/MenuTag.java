package com.qidi.policeservice.datatype;

public class MenuTag {
	public static final int DEFAULT_ID = -1;
	public static final int DEFAULT_TYPE = -1;
	
	public static final int TYPE_HEADER = 0;
	
	public static final int TYPE_SEARCH_ROOT = 1;
	public static final int TYPE_SEARCH_AREA = 2;	
	public static final int TYPE_SEARCH_LBS = 3;
	public static final int TYPE_SEARCH_COLLECTION = 4;
	public static final int TYPE_SEARCH_HEADER = 5;
	public static final int TYPE_GUIDE_ROOT = 6;
	public static final int TYPE_NOTICE_ROOT = 7;
	public static final int TYPE_DOCUMENT = 21;
	public static final int TYPE_STAFF = 22;
	public static final int TYPE_RECORD = 23;

	public static final int TYPE_SEARCH_PROVINCE = 30;
	public static final int TYPE_SEARCH_CITY = 31;
	public static final int TYPE_SEARCH_DISTRICT = 32;
	public static final int TYPE_SEARCH_STATION = 33;
	public static final int TYPE_SEARCH_POLICE = 34;
	
	//city id
	public static final int ID_CHENGDU = 235;
	
	public int type = DEFAULT_TYPE;
	public int id = DEFAULT_ID;
	
	public MenuTag(int type, int id) {
		this.type = type;
		this.id = id;
	}
	
	public int getType() {
		return type;
	}
	
	public int getId() {
		return id;
	}
	
	public String getUrl() {
		String ret = null;
		switch (type) {
			case TYPE_SEARCH_PROVINCE:
				ret = "http://police.cdqidi.cn/Cloud/CloudHandler.ashx?method=GetCities&ProvinceID=" + id;
				break;
			case TYPE_SEARCH_CITY:
				ret = "http://police.cdqidi.cn/Cloud/CloudHandler.ashx?method=GetDistricts&CityID=" + id;
				break;
			case TYPE_SEARCH_DISTRICT:
				ret = "http://police.cdqidi.cn/Cloud/CloudHandler.ashx?method=GetPoliceStations&DistrictID=" + id;
				break;
			case TYPE_SEARCH_STATION:
				ret = "http://police.cdqidi.cn/Cloud/CloudHandler.ashx?method=GetStationPoliceList&StationID=" + id;
				break;
			case TYPE_SEARCH_AREA:
				ret = "http://police.cdqidi.cn/Cloud/CloudHandler.ashx?method=GetDistricts&CityID=" + ID_CHENGDU;
				break;
			default:
				break;
		}
		return ret;
	}
	
	public String toString() {
		return "type:" + type + " id:" + id;
	}
	
	/*public static int getNextLevelType(int type) {
		int ret = DEFAULT_TYPE;
		switch (type) {
			case TYPE_SEARCH_PROVINCE:
				ret = TYPE_SEARCH_CITY;
				break;
			case TYPE_SEARCH_CITY:
				ret = TYPE_SEARCH_DISTRICT;
				break;
			case TYPE_SEARCH_DISTRICT:
				ret = TYPE_SEARCH_STATION;
				break;
			case TYPE_SEARCH_STATION:
				ret = TYPE_SEARCH_POLICE;
				break;
			case TYPE_SEARCH_AREA:
				ret = TYPE_SEARCH_DISTRICT;
				break;
			case TYPE_SEARCH_LBS:
				ret = TYPE_SEARCH_STATION;
				break;
			case TYPE_SEARCH_COLLECTION:
				ret = TYPE_SEARCH_POLICE;
				break;
			default:
				break;
		}
		return ret;
	}*/
	
}
