package com.qidi.policeservice.datatype;

import android.view.View;
import android.widget.TextView;

import com.qidi.policeservice.R;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.ui.SampleAdapter.Holder;

public class SearchRootItem implements ContentItem {
	public int id = MenuTag.DEFAULT_ID;
	public int type = MenuTag.DEFAULT_TYPE;
	
	public String title = null;

	@Override
	public int getLayoutId() {
		return R.layout.search_root_item_layout;
	}

	@Override
	public Holder getHolder() {
		return new SearchRootHolder();
	}

	@Override
	public boolean holderMismatch(Holder holder) {
		return !(holder instanceof SearchRootHolder);
	}

	@Override
	public void bindView(View convertView, Holder holder) {
		SearchRootHolder h = (SearchRootHolder) holder;
		h.title = (TextView) convertView.findViewById(R.id.search_header_title);
	}

	@Override
	public void updateView(Holder holder) {
		SearchRootHolder h = (SearchRootHolder) holder;
		switch (type) {
			case MenuTag.TYPE_SEARCH_COLLECTION:
				h.title.setText(R.string.collection);
				break;
			case MenuTag.TYPE_SEARCH_LBS:
				h.title.setText(R.string.search_lbs);
				break;
			case MenuTag.TYPE_SEARCH_AREA:
				h.title.setText(R.string.search_area);
				break;
			default:
				break;
		}
	}
	
	public static class SearchRootHolder implements Holder{
		TextView title;
	}

	@Override
	public MenuTag getMenuTag() {
		return new MenuTag(type, id);
	}

}
