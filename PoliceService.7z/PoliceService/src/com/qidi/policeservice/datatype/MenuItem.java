package com.qidi.policeservice.datatype;

import android.view.View;
import android.widget.TextView;

import com.qidi.policeservice.R;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.ui.SampleAdapter.Holder;

public class MenuItem implements ContentItem {
	public int id = MenuTag.DEFAULT_ID;
	public int type = MenuTag.DEFAULT_TYPE;
	
	public String title = null;

    @Override
	public int getLayoutId() {
		return R.layout.simple_header_item_layout;
	}

	@Override
	public Holder getHolder() {
		return new MenuItemHolder();
	}

	@Override
	public void bindView(View convertView, Holder holder) {
		MenuItemHolder h = (MenuItemHolder) holder;
		h.title = (TextView) convertView.findViewById(R.id.simple_header_title);
	}

	@Override
	public void updateView(Holder holder) {
		MenuItemHolder h = (MenuItemHolder) holder;
		if (title != null) {
			h.title.setText(title);
		}
	}
	
	public static class MenuItemHolder implements Holder{
		TextView title;
	}

	@Override
	public boolean holderMismatch(Holder holder) {
		return !(holder instanceof MenuItemHolder);
	}

	@Override
	public MenuTag getMenuTag() {
		return new MenuTag(type, id);
	}

}
