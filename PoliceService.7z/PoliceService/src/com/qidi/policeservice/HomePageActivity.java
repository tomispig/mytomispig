package com.qidi.policeservice;

import java.util.ArrayList;

import com.qidi.policeservice.R;
import com.qidi.policeservice.tools.XmlParser;
import com.qidi.policeservice.ui.SampleAdapter;
import com.qidi.policeservice.ui.SampleAdapter.ContentItem;
import com.qidi.policeservice.webmessage.ConversationList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class HomePageActivity extends Activity {
	private ListView mListView;
	private SampleAdapter mAdapter;
	private ArrayList<ContentItem> mList = new ArrayList<ContentItem>();
	private OnItemClickListener mListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			Intent intent = new Intent("com.qidi.policeservice.MainActivity");
			intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			switch (position) {
				case 0:
					PoliceServiceApp.alarmCall("123456");
					break;
				case 1:
					//intent.putExtra("current_tab", 2);
					//startActivity(intent);
					Intent intentMode0 = new Intent(HomePageActivity.this, ConversationList.class);
					intentMode0.putExtra("current_mode", 0);

					HomeActivityGroup.mGroup.start("ConversationList0", intentMode0);
					break;
				case 2:
					//intent.putExtra("current_tab", 3);
					//startActivity(intent);
					Intent intentMode1 = new Intent(HomePageActivity.this, ConversationList.class);
					intentMode1.putExtra("current_mode", 1);

					HomeActivityGroup.mGroup.start("ConversationList1", intentMode1);
					break;
				case 3:
					intent.putExtra("current_tab", 4);
					startActivity(intent);
					break;
				default:
					break;
			}			
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_page_layout);
		
		XmlParser.loadHeadersFromResource(this, R.xml.home_page_headers, mList);
		
		mListView = (ListView) findViewById(R.id.sample_listview);
		mAdapter = new SampleAdapter(mList, this);
		mListView.setAdapter(mAdapter);
		
		mListView.setOnItemClickListener(mListener);
	}
}
