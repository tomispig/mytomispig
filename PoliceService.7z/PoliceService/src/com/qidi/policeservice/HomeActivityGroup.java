package com.qidi.policeservice;

import java.util.Stack;

import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

@SuppressWarnings("deprecation")
public class HomeActivityGroup extends ActivityGroup {
	public static HomeActivityGroup mGroup;
	//private ArrayList<View> history = new ArrayList<View>();
	private static LocalActivityManager mManager;
	
	private static Stack<String> mIdStack = new Stack<String>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mGroup = this;
		mManager = getLocalActivityManager();

		start("HomePageActivity", new Intent(this, HomePageActivity.class));
	}

	public void start(String id, Intent intent) {
		View view = mManager.startActivity(id, intent).getDecorView();
		Log.d("HomeActivityGroup", "ps log start:" + id);
		mIdStack.push(id);
		setContentView(view);
	}
	
	@Override
	public void onBackPressed() {
		Log.d("HomeActivityGroup", "ps log onBackPressed");
		if (mIdStack.empty()) {
			super.onBackPressed();
			return;
		}
		String id = mIdStack.pop();
		mManager.destroyActivity(id, true);
		if (mIdStack.empty()) {
			super.onBackPressed();
		} else {
			id = mIdStack.pop();
			Intent intent = new Intent(this, mManager.getActivity(id).getClass());
			start(id, intent);
		}
	}
}
